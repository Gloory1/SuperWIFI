# SuperWiFi v5 — System Architecture

> A zero-dependency, enterprise-grade captive portal and bandwidth management system built natively for OpenWrt.

---

## 1. Executive Summary

SuperWiFi replaces the entire RADIUS + MySQL + C-daemon stack with:

| Layer | Technology | Size |
|-------|-----------|------|
| Logic | POSIX Shell Scripts | ~80 KB |
| State | SQLite 3 (WAL mode) | Embedded |
| Firewall | nftables (native fw4) | Built-in |
| QoS | tc HTB + SFQ | Built-in |
| Init | procd (OpenWrt native) | Built-in |

**Total footprint:** < 500 KB · **RAM usage:** ~2 MB · **Dependencies:** `sqlite3-cli`, `tc-full`, `kmod-sched`

---

## 2. System Overview

```mermaid
flowchart TD
    Client([Client Device]) -->|WiFi| AP[WiFi AP / br-lan]
    AP --> NFT{nftables forward chain\npolicy DROP}

    NFT -->|MAC in quarantined set| DROP1[DROP + Log]
    NFT -->|MAC in bypass_macs| INET[Internet]
    NFT -->|MAC.IP in authenticated set| TC[tc HTB Shaping\n1:CLASS_ID]
    NFT -->|No match| REDIRECT[prerouting redirect\nHTTP to Portal\nHTTPS TCP Reset]
    TC --> INET

    REDIRECT --> PORTAL[login.html + auth.sh CGI]
    PORTAL -->|POST voucher| AUTH[auth.sh: validate, ARP lookup\nDB check, first_punch, class_id]
    AUTH -->|nft add element + tc class add| NFT

    ACCT[sw-acct.sh daemon every 60s] -->|tc -s class show| TC
    ACCT -->|delta bytes| DB[(SQLite WAL)]
    DB -->|trg_quota_check trigger| DEAUTH[Deauth on quota]
    ACCT -->|expiry check| DEAUTH
    DEAUTH -->|nft delete + tc del + conntrack| NFT

    SENTINEL[sentinel 8-phase] -->|compare| NFT
    SENTINEL -->|compare| DB
    SENTINEL -->|self-heal| NFT
```

---

## 3. Component Architecture

### 3.1 Shell Library Stack

```mermaid
graph BT
    ACCT[sw-acct.sh Accounting Daemon] --> CORE
    SW[sw CLI Tool] --> CORE
    AUTH[auth.sh CGI] --> CORE
    SENTINEL[sw-sentinel.sh] --> CORE
    RESTORE[fw-restore.sh] --> CORE

    CORE[core.sh: Config, Validation, Logging, ARP]
    CORE --> DB[db.sh: SQLite Abstraction]
    CORE --> FW[fw.sh: nftables ops]
    CORE --> TC[tc.sh: HTB QoS]
    DB --> QUERIES[db-queries.sh: 575 lines, 13 sections]
```

### 3.2 Library Reference

| File | Lines | Size | Purpose |
|------|-------|------|---------|
| `core.sh` | 151 | 5.1 KB | UCI config, MAC/IP/voucher validation, syslog, ARP lookup, ARP hardening |
| `db.sh` | 43 | 1.2 KB | `db_escape()`, `db_query()` (3s timeout + FK), `db_exec_batch()`, `sw_db_init()` |
| `db-queries.sh` | 575 | 23.8 KB | All SQL: Voucher CRUD, Sessions, TC class_id, Accounting, Rollback, Quarantine, Anti-spam, Packages, Maintenance, Sync, CLI, History, Diagnostics |
| `fw.sh` | 102 | 2.9 KB | `sw_fw_auth()`, `sw_fw_deauth()`, `sw_fw_block/unblock_mac()`, `sw_calc_timeout()` |
| `tc.sh` | 80 | 2.8 KB | HTB root qdisc, per-session class + SFQ leaf, u32 filters |
| `sw-sentinel.sh` | 143 | 6.3 KB | 8-phase self-healing reconciliation |
| `fw-restore.sh` | 73 | 2.1 KB | Session restore after reboot/fw4 reload |

---

## 4. Authentication Flow

```mermaid
sequenceDiagram
    participant C as Client
    participant NFT as nftables
    participant CGI as auth.sh
    participant DB as SQLite
    participant TC as tc HTB

    C->>NFT: HTTP GET example.com
    NFT->>C: 302 redirect to login.html
    C->>CGI: GET login.html
    CGI->>C: HTML glass-morphism UI

    C->>CGI: POST voucher=XXXXXX
    CGI->>CGI: validate format
    CGI->>CGI: ARP lookup for client MAC
    CGI->>NFT: quarantine set check
    CGI->>DB: spam block check
    CGI->>DB: db_get_voucher_info(code)

    alt First use
        CGI->>DB: db_first_punch_session() atomic
        CGI->>DB: db_assign_class_id() BEGIN IMMEDIATE
        CGI->>NFT: nft add element authenticated
        CGI->>TC: tc class add 1:CLASS_ID
    else Re-auth same MAC
        CGI->>DB: db_reauth_session() update IP
        CGI->>NFT: reapply with new timeout
    end

    CGI->>C: 200 JSON with remaining_bytes, rates, capport_url
    C->>CGI: poll GET action=capport for live status
```

---

## 5. Database Architecture

### 5.1 Tables

| Table | PK | Key Columns | Purpose |
|-------|----|-------------|---------|
| `packages` | `package_id` AUTO | `name` UNIQUE, rates, `data_limit_bytes`, `duration_min`, price | Plan templates |
| `vouchers_info` | `voucher_code` TEXT | bound_mac/ip, rates, limits, `cumulative_usage_bytes`, `season_usage_bytes`, `first_punched_at`, `class_id` UNIQUE (25+ cols) | Master session state |
| `accounting_log` | `id` AUTO | voucher_code FK, mac, `delta_bytes`, cycle_start/end | Per-cycle audit trail |
| `quarantine_log` | `id` AUTO | mac, voucher, reason, `delta_bytes`, `threshold_bytes` | Anomaly events |
| `login_attempts` | *(none)* | mac_address, attempt_time (epoch) | Brute-force tracking |
| `blocks` | `mac_address` TEXT | `block_until` (epoch), reason | Temporary MAC bans |

### 5.2 Views

| View | Filter | Computed Columns |
|------|--------|-----------------|
| `active_sessions` | `is_active=1, is_quarantined=0`, time not expired | — |
| `acct_targets` | `is_active=1, is_quarantined=0` | `abs_expired` (bool), `dur_expired` (bool) |
| `quota_remaining` | `is_active=1, is_quarantined=0` | `remaining_bytes` (-1=unlimited), `usage_pct` |
| `near_quota` | `usage_pct >= 90.0` | Inherits quota_remaining |

### 5.3 Trigger

```sql
-- Automatic sub-second quota cutoff
CREATE TRIGGER trg_quota_check
AFTER UPDATE OF cumulative_usage_bytes ON vouchers_info
WHEN NEW.data_limit_bytes > 0 AND NEW.cumulative_usage_bytes >= NEW.data_limit_bytes
BEGIN
    UPDATE vouchers_info SET is_active = 0 WHERE voucher_code = NEW.voucher_code;
END;
```

### 5.4 Indexes (9 total)

| Index | Column(s) | Notes |
|-------|-----------|-------|
| `idx_vouchers_class_id` | `class_id` | UNIQUE |
| `idx_vouchers_mac` | `bound_mac` | — |
| `idx_vouchers_active` | `(is_active, is_quarantined)` | Composite |
| `idx_acct_voucher` | `accounting_log.voucher_code` | — |
| `idx_acct_mac` | `accounting_log.mac` | — |
| `idx_acct_log_cycle` | `accounting_log.cycle_start` | — |
| `idx_login_attempts_time` | `attempt_time` | — |
| `idx_blocks_expiry` | `block_until` | — |
| `idx_quarantine_detected` | `detected_at` | — |

### 5.5 Design Decisions

- **WAL mode**: Concurrent reads during accounting writes
- **All units in bytes**: Zero KB/MB conversion bugs; pure integer arithmetic
- **`season_usage_bytes`**: TC counter snapshot from last cycle — delta without extra state table
- **`class_id` gap-finding**: Allocates lowest available ID ≥ 1000 using self-join; `BEGIN IMMEDIATE` prevents concurrent collision

---

## 6. Firewall Architecture (nftables)

### 6.1 Sets

| Set | Type | Flags | Purpose |
|-----|------|-------|---------|
| `authenticated` | `ether_addr . ipv5_addr` | dynamic, timeout 24h, counter | Active sessions (MAC+IP tuples) |
| `bypass_macs` | `ether_addr` | interval | Staff/printer MACs — skip portal |
| `quarantined` | `ether_addr` | dynamic | Anomaly-blocked MACs |

### 6.2 Forward Chain (filter, priority -1, policy DROP)

| # | Rule | Purpose |
|---|------|---------|
| 1 | Accept established/related (iifname ≠ LAN) | Return traffic from internet |
| 2 | Accept ICMPv6 ND from LAN | IPv6 neighbor discovery |
| 3 | **DROP all other IPv6 from LAN** | Prevents IPv6 portal bypass |
| 4 | Drop `quarantined` MACs + log prefix | Block bad actors |
| 5 | Accept `bypass_macs` | Staff/printer free access |
| 6 | Drop LAN→LAN (same iface) | Inter-client isolation |
| 7 | Accept `authenticated` MAC.IP pairs | Active sessions pass |
| 8 | Accept DNS(53/UDP) + HTTP(80) + HTTPS(443) → portal IP | Portal access for unauthenticated |
| 9 | Default DROP (policy) | Deny all else |

### 6.3 Prerouting Chain (nat, dstnat)

| Protocol | Rule | Reason |
|----------|------|--------|
| HTTP port 80 | Redirect → portal IP:80 | Captive portal redirect |
| HTTPS port 443 | `reject with tcp reset` | Triggers fast OS captive portal detection (iOS, Android, Windows) |

---

## 7. Traffic Control (tc HTB)

```
br-lan
└── qdisc htb 1:0   (root, default class 9999)
    ├── class htb 1:9999   (default — uncapped traffic)
    ├── class htb 1:1000   (session A: rate=ceil=rate_down_kbps)
    │   └── qdisc sfq      (stochastic fairness, perturb 10s)
    ├── class htb 1:1001   (session B)
    │   └── qdisc sfq
    └── ...

u32 Filters per session:
  match ip dst CLIENT_IP → flowid 1:CLASS_ID   (download shaping)
  match ip src CLIENT_IP → flowid 1:CLASS_ID   (upload tracking)
```

---

## 8. Accounting Engine

```mermaid
flowchart TD
    START([Every 60 seconds]) --> LOCK{flock -n 9 available?}
    LOCK -->|No| SKIP([Skip cycle])
    LOCK -->|Yes| TC[tc -s class show\nawk: class_id|bytes_sent]
    TC --> LOOP[For each row in acct_targets view]
    LOOP --> CURR[curr_bytes = TC stats for class_id]
    CURR --> DELTA{curr vs season_usage_bytes}
    DELTA -->|curr greater| D1[delta = curr - season: normal]
    DELTA -->|curr less| D2[delta = curr: TC reset detected]
    DELTA -->|curr equal| D3[delta = 0: no traffic]
    D1 & D2 & D3 --> ANOMALY{delta exceeds rate threshold?}
    ANOMALY -->|Yes| QUARANTINE[QUARANTINE action]
    ANOMALY -->|No| EXPIRY{abs or dur expired?}
    EXPIRY -->|Yes| DEAUTH[DEAUTH action]
    EXPIRY -->|No| QUOTA{new cumulative >= data_limit?}
    QUOTA -->|Yes| DEAUTH
    QUOTA -->|No| SQL[Write UPDATE SQL to batch file]
    SQL --> BATCH[BEGIN TRANSACTION N updates COMMIT]
    BATCH --> ACTIONS[Process DEAUTH/QUARANTINE]
    ACTIONS --> SENTINEL[Run sw_sentinel_reconcile]
    SENTINEL --> START
```

**Anomaly threshold:** `rate_down_kbps × 125 × interval_sec × anomaly_multiplier`
(125 = 1000/8, converts kbps to bytes/sec)

---

## 9. Self-Healing Sentinel (8 Phases)

| Phase | Name | Detection | Action |
|-------|------|-----------|--------|
| 1 | Collect nft state | Parse `nft list set inet superwifi authenticated` | Build MAC\|IP pairs |
| 2 | Collect DB state | `db_get_all_active_sessions` | Build MAC\|IP\|rates\|class_id |
| 3 | Ghost detection | MAC in nft, NOT in DB | Mark for removal |
| 4 | Stale-IP detection | MAC in both, but IP differs | Mark for IP update |
| 5 | Missing detection | MAC in DB, NOT in nft | Mark for restore |
| 6a | Ghost removal | — | `nft delete element` + `conntrack -D` |
| 6b | Stale-IP fix | — | Delete old nft element + flush old conntrack |
| 6c | Missing restore | — | Batch `nft add element` + `sw_tc_apply()` with correct timeouts |
| 7 | TC orphan cleanup | class_id ≥ 1000 not in DB | `tc class del` |
| 8 | Summary log | — | Log ghost/stale/restore/orphan counts + timing |

> **Rate limit:** 10 remediations per cycle. If nftables is completely empty (post-reboot), limit is removed for full restore.

---

## 10. Security Layers

| Layer | Mechanism | Protection |
|-------|-----------|-----------|
| Default-deny firewall | nftables `policy DROP` | No traffic without explicit allow |
| IPv6 blocking | Drop all non-ND IPv6 from LAN | Prevents IPv6 portal bypass |
| MAC+IP binding | `authenticated` set requires both | Spoofed MAC useless without matching IP |
| ARP hardening | `arp_ignore=1`, `arp_announce=2` | Prevents ARP spoofing attacks |
| Rate anomaly detection | delta > rate × 125 × interval × multiplier | Auto-quarantine on bandwidth theft |
| Quarantine system | Automatic (anomaly) + manual (`sw quarantine`) | Blocks device and voucher together |
| Anti-brute-force | `login_attempts` + `blocks` table | Temporary ban after N failures |
| Conntrack flush | `conntrack -D` on every deauth | Guarantees session termination |
| Inter-client isolation | Drop LAN→LAN (same iface in/out) | Prevents client-to-client attacks |
| Time-block restrictions | `time_block_start/end` per voucher | Restrict usage to configured hours |
| Rollback on auth failure | `db_rollback_first_punch()` | No ghost sessions if fw/TC apply fails |

---

## 11. Service Lifecycle

```
/etc/init.d/superwifi start
  ├── sw_validate_config()         Verify binaries, interfaces, settings
  ├── sw_db_init()                 Create/migrate SQLite DB
  ├── sw_apply_arp_harden()        Set arp_ignore + arp_announce
  ├── Render superwifi.nft.tpl     Fill LAN_IFACE, PORTAL_IP, BYPASS_MACS
  ├── nft -f /tmp/superwifi.nft    Load all firewall rules
  ├── sw_tc_rebuild_filters()      Rebuild u32 filters from DB
  ├── fw_restore_sessions()        Re-add active sessions to nft + TC
  └── procd: spawn sw-acct.sh      Managed process with auto-respawn

/etc/init.d/superwifi stop
  ├── nft delete table inet superwifi
  ├── tc qdisc del dev br-lan root
  └── rm -f /tmp/superwifi/*.tmp
```

---

## 12. File Map

| Path | Lines | Size | Purpose |
|------|-------|------|---------|
| `etc/config/superwifi` | 64 | 2.1 KB | UCI configuration |
| `etc/dnsmasq.d/superwifi.conf` | 15 | 587 B | DHCP Option 114 (RFC 8910) |
| `etc/init.d/superwifi` | 137 | 5.1 KB | procd init script |
| `etc/superwifi/schema.sql` | 136 | 5.3 KB | SQLite DDL |
| `etc/superwifi/superwifi.nft.tpl` | 74 | 3.0 KB | nftables template |
| `etc/superwifi/vouchers_seed.csv` | 9 | 287 B | Sample vouchers |
| `usr/lib/superwifi/core.sh` | 151 | 5.1 KB | Shared foundation library |
| `usr/lib/superwifi/db.sh` | 43 | 1.2 KB | SQLite abstraction |
| `usr/lib/superwifi/db-queries.sh` | 575 | 23.8 KB | All SQL queries (13 sections) |
| `usr/lib/superwifi/fw.sh` | 102 | 2.9 KB | nftables operations |
| `usr/lib/superwifi/fw-restore.sh` | 73 | 2.1 KB | Session restore |
| `usr/lib/superwifi/sw-sentinel.sh` | 143 | 6.3 KB | 8-phase self-healing |
| `usr/lib/superwifi/tc.sh` | 80 | 2.8 KB | Traffic control (HTB) |
| `usr/sbin/sw` | 478 | 19.7 KB | CLI management tool |
| `usr/sbin/sw-acct.sh` | 146 | 5.3 KB | Accounting daemon |
| `usr/sbin/sw-sync.sh` | 87 | 3.3 KB | Supabase cloud sync |
| `www/cgi-bin/auth.sh` | 335 | 13.4 KB | Authentication CGI |
| `www/cgi-bin/capport-api.sh` | 12 | 269 B | RFC 8908 capport API |
| `www/superwifi/login.html` | ~280 | 10.6 KB | Captive portal HTML |
| `www/superwifi/js/main.js` | — | 21.1 KB | Portal JS |
| `www/superwifi/css/style.css` | — | 16.0 KB | Portal styles |

---

## 13. Cloud Sync Architecture (v5)

```
OpenWrt Gateway                    Supabase Cloud
────────────────                   ──────────────
sw-sync.sh (every 5 min)
  ├── GET  action_queue             Remote commands: disconnect_mac, change_config...
  ├── POST active_sessions          Upload live session data
  └── POST vouchers (sync_status)   Sync voucher states

Flutter App (iOS / Android)
  ├── Gateways management (multi-site)
  ├── Packages and Batches
  ├── Voucher generation (create_batch RPC)
  ├── Active sessions + disconnect
  ├── Analytics and Financial Reports
  ├── User management (RBAC: admin/manager/viewer)
  └── Action Queue monitoring (enqueueAction pattern)
```

The `enqueueAction()` pattern allows the Flutter app to send commands to offline gateways.
Commands are stored in Supabase and executed on the next sync cycle.
