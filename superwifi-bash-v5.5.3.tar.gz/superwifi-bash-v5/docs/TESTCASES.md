# SuperWiFi v5 — Test Cases

> **Version:** v5.2  
> **Last Updated:** 2026-07-13  
> **Coverage:** Authentication, Billing, Firewall, Rate Limiting, Security, Edge Cases

---

## 📋 Test Environment Setup

```sh
# Run all automated tests
sh test_v5_full_lifecycle.sh

# Manual tests require SSH access to router
SSH_HOST="root@192.168.10.1"
DB="/etc/superwifi/superwifi.db"

# Helper: create a test voucher
create_voucher() {
    sqlite3 $DB "INSERT INTO voucher (code, package_id, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, valid_until)
    VALUES ('TEST001', 1, 2048, 1024, 1073741824, 1440, 0);"
}

# Helper: reset test state
reset_test() {
    sqlite3 $DB "DELETE FROM session WHERE voucher_code LIKE 'TEST%';"
    sqlite3 $DB "DELETE FROM voucher WHERE code LIKE 'TEST%';"
    sqlite3 $DB "DELETE FROM rate_limit WHERE bound_mac LIKE 'aa:%';"
}
```

---

## 🔐 Section 1 — Authentication (auth.sh)

### TC-AUTH-01: First Punch — Valid Voucher, New Device
**What it tests:** Normal first-time activation  
**Steps:**
```sh
create_voucher
# POST from a device not yet in DB
curl -s -X POST "http://192.168.10.1/cgi-bin/auth.sh" -d "voucher=TEST001"
```
**Expected:**
- Response: `{"status":"ok","message":"Connected successfully",...}`
- `session` table has new active row for TEST001
- `nft get element inet superwifi authenticated` shows the MAC+IP pair
- `tc class show dev br-lan` shows htb class with rate 2048kbit

---

### TC-AUTH-02: Re-Auth — Same Voucher, Same Device, New IP
**What it tests:** IP change after DHCP renew  
**Precondition:** TC-AUTH-01 done, session active  
**Steps:**
```sh
# Simulate IP change then re-auth
curl -s -X POST "http://192.168.10.1/cgi-bin/auth.sh" -d "voucher=TEST001"
```
**Expected:**
- Response: `{"status":"ok",...}`
- `session.bound_ip` updated
- Old tc class removed, new one created (counters reset to 0)
- `season_usage_bytes = 0` in DB

---

### TC-AUTH-03: MAC Mismatch — Voucher Belongs to Different Device
**What it tests:** Prevents voucher sharing between devices  
**Steps:**
```sh
# After TEST001 bound to DeviceA, try same voucher from DeviceB
curl -s -X POST "http://192.168.10.1/cgi-bin/auth.sh" -d "voucher=TEST001"
# (from device with different MAC)
```
**Expected:**
- Response: `{"status":"error","code":"MAC_MISMATCH","message":"This voucher is already in use by another device."}`
- Session not modified

---

### TC-AUTH-04: Expired Voucher (Absolute Expiry Before First Punch)
**What it tests:** Rejects vouchers past their valid_until date  
**Steps:**
```sh
PAST=$(( $(date +%s) - 3600 ))
sqlite3 $DB "INSERT INTO voucher (code,package_id,rate_down_kbps,rate_up_kbps,data_limit_bytes,duration_min,valid_until) VALUES ('TESTEXP',1,2048,1024,0,60,$PAST);"
curl -s -X POST "http://192.168.10.1/cgi-bin/auth.sh" -d "voucher=TESTEXP"
```
**Expected:**
- Response: `{"status":"error","code":"VOUCHER_EXHAUSTED","message":"This voucher has expired."}`
- No session created

---

### TC-AUTH-05: Quota Exhausted Voucher
**What it tests:** Rejects vouchers that have used all their data  
**Steps:**
```sh
sqlite3 $DB "INSERT INTO voucher (code,package_id,rate_down_kbps,rate_up_kbps,data_limit_bytes,duration_min,valid_until) VALUES ('TESTQUOTA',1,2048,1024,1073741824,1440,0);"
sqlite3 $DB "INSERT INTO session (voucher_code,bound_mac,bound_ip,status,rate_down_kbps,rate_up_kbps,data_limit_bytes,cumulative_usage_bytes,first_punch_at,expires_at) VALUES ('TESTQUOTA','aa:bb:cc:dd:ee:ff','192.168.10.50','active',2048,1024,1073741824,1073741824,strftime('%s','now'),0);"
curl -s -X POST "http://192.168.10.1/cgi-bin/auth.sh" -d "voucher=TESTQUOTA"
```
**Expected:**
- Response: `{"status":"error","code":"VOUCHER_EXHAUSTED","message":"Voucher expired or quota exhausted."}`
- Session status updated to `expired` in DB

---

### TC-AUTH-06: Invalid / Non-Existent Voucher Code
**What it tests:** Returns proper error and increments fail counter  
**Steps:**
```sh
curl -s -X POST "http://192.168.10.1/cgi-bin/auth.sh" -d "voucher=NONEXISTENT"
```
**Expected:**
- Response: `{"status":"error","code":"VOUCHER_NOT_FOUND","message":"Invalid code. 4 attempts remaining."}`
- `rate_limit` table shows `fail_count=1` for this MAC

---

### TC-AUTH-07: Rate Limiting — Max Failed Attempts
**What it tests:** Blocks MAC after 5 consecutive failures  
**Steps:**
```sh
for i in 1 2 3 4 5; do
    curl -s -X POST "http://192.168.10.1/cgi-bin/auth.sh" -d "voucher=WRONG$i"
done
```
**Expected:**
- First 4 responses: `VOUCHER_NOT_FOUND` with decreasing remaining count
- 5th response: `{"status":"error","code":"SPAM_BLOCKED","message":"Blocked for 15 minutes..."}`
- `nft get element inet superwifi quarantined` shows this MAC with timeout
- `rate_limit` table shows `blocked_until > now()`

---

### TC-AUTH-08: [FIX H2] Rate Limit NOT Bypassed via Expired Voucher
**What it tests:** Security fix — expired voucher cannot reset fail counter  
**Steps:**
```sh
# Create expired voucher
sqlite3 $DB "INSERT INTO voucher (code,package_id,rate_down_kbps,rate_up_kbps,data_limit_bytes,duration_min,valid_until) VALUES ('TESTOLD',1,2048,1024,0,60,1000);"
# Try 4 wrong codes, then the expired voucher, then one more wrong
curl -X POST -d "voucher=WRONG1" http://192.168.10.1/cgi-bin/auth.sh
curl -X POST -d "voucher=WRONG2" http://192.168.10.1/cgi-bin/auth.sh
curl -X POST -d "voucher=WRONG3" http://192.168.10.1/cgi-bin/auth.sh
curl -X POST -d "voucher=WRONG4" http://192.168.10.1/cgi-bin/auth.sh
curl -X POST -d "voucher=TESTOLD" http://192.168.10.1/cgi-bin/auth.sh  # expired!
curl -X POST -d "voucher=WRONG5" http://192.168.10.1/cgi-bin/auth.sh  # must block
```
**Expected:**
- After `TESTOLD`: `VOUCHER_EXHAUSTED` — fail_count stays at 4 (NOT reset)
- After `WRONG5`: `SPAM_BLOCKED` — correctly reaches max at 5

---

### TC-AUTH-09: [FIX H1] Quarantined MAC Cannot Rebind via Capport
**What it tests:** Banned devices cannot regain access through auto-rebind  
**Steps:**
```sh
# After session active, ban the MAC
nft add element inet superwifi quarantined '{ aa:bb:cc:dd:ee:01 timeout 60m }'
# Simulate capport rebind attempt (device got new IP)
curl -s "http://192.168.10.1/cgi-bin/auth.sh?action=capport" \
  -H "REMOTE_ADDR: 192.168.10.55"
```
**Expected:**
- Capport response: `{"captive":true,...}` (not auto-rebound)
- Log: `CAPPORT REBIND BLOCKED: MAC ... is quarantined.`
- Device cannot access internet

---

### TC-AUTH-10: Time Block Enforcement
**What it tests:** Access denied during restricted hours  
**Steps:**
```sh
NOW_HM=$(date +"%H%M")
START=$(( NOW_HM - 10 < 0 ? 0 : NOW_HM - 10 ))
END=$(( NOW_HM + 10 > 2359 ? 2359 : NOW_HM + 10 ))
sqlite3 $DB "UPDATE voucher SET time_block_start=$START, time_block_end=$END WHERE code='TEST001';"
curl -s -X POST "http://192.168.10.1/cgi-bin/auth.sh" -d "voucher=TEST001"
```
**Expected:**
- Response: `{"status":"error","code":"TIME_BLOCKED","message":"Access is restricted between..."}`

---

## 💰 Section 2 — Billing & Accounting (sw-acct.sh)

### TC-ACCT-01: Basic Byte Counting
**What it tests:** Accounting daemon correctly accumulates traffic  
**Steps (on router):**
```sh
# Verify after one accounting cycle
sqlite3 $DB "SELECT season_usage_bytes, cumulative_usage_bytes FROM session WHERE voucher_code='TEST001';"
```
**Expected:** Both increase by the bytes transferred in the last 60 seconds

---

### TC-ACCT-02: Data Quota Expiry via Accounting
**What it tests:** Session expires when cumulative_usage >= data_limit  
**Steps:**
```sh
# Set quota very close to limit
sqlite3 $DB "UPDATE session SET data_limit_bytes=52428800, cumulative_usage_bytes=51380224 WHERE voucher_code='TEST001';"
# Wait for next accounting cycle (up to 60s)
sleep 65
sqlite3 $DB "SELECT status FROM session WHERE voucher_code='TEST001';"
```
**Expected:** `status = 'expired'`; device deauthenticated from nft

---

### TC-ACCT-03: Time-Based Session Expiry
**What it tests:** Session expires when expires_at is in the past  
**Steps:**
```sh
PAST=$(( $(date +%s) - 60 ))
sqlite3 $DB "UPDATE session SET expires_at=$PAST WHERE voucher_code='TEST001';"
sleep 65
sqlite3 $DB "SELECT status FROM session WHERE voucher_code='TEST001';"
```
**Expected:** `status = 'expired'`; firewall rule removed

---

### TC-ACCT-04: [FIX C1] No Double-Counting on Re-Auth
**What it tests:** Traffic not counted twice when user reconnects  
**Steps:**
```sh
# Note cumulative_usage_bytes before re-auth
BEFORE=$(sqlite3 $DB "SELECT cumulative_usage_bytes FROM session WHERE voucher_code='TEST001';")
# Re-auth (reconnect device)
curl -s -X POST "http://192.168.10.1/cgi-bin/auth.sh" -d "voucher=TEST001"
# Wait for two accounting cycles
sleep 130
AFTER=$(sqlite3 $DB "SELECT cumulative_usage_bytes FROM session WHERE voucher_code='TEST001';")
# Delta should match actual traffic, not include ghost bytes from pre-reconnect tc counter
echo "Delta: $(( AFTER - BEFORE ))"
```
**Expected:** Delta is proportional to actual traffic only (not doubled)

---

### TC-ACCT-05: [FIX H4] Expired Session NOT Restored After Reboot
**What it tests:** Expired sessions don't come back after router restart  
**Steps:**
```sh
# Check v_restore for a known expired session
PAST=$(( $(date +%s) - 3600 ))
sqlite3 $DB "INSERT INTO session (..., status='active', expires_at=$PAST, ...) ..."
sqlite3 $DB "SELECT bound_mac FROM v_restore;" | grep 'TESTEXP'
```
**Expected:** Empty result — expired sessions excluded from v_restore

---

### TC-ACCT-06: Unlimited Session (No Quota, No Expiry)
**What it tests:** Unlimited vouchers run indefinitely  
**Steps:**
```sh
# Create unlimited voucher and let it run
sqlite3 $DB "INSERT INTO voucher (code,package_id,rate_down_kbps,rate_up_kbps,data_limit_bytes,duration_min,valid_until) VALUES ('TESTUNLIM',1,2048,1024,0,0,0);"
```
**Expected:**
- Session never auto-expires
- Portal shows "غير محدود" / "Unlimited" for both data and time

---

## 🛡️ Section 3 — Firewall & TC (fw.sh / tc.sh)

### TC-FW-01: Firewall Auth Adds MAC+IP to nft Set
```sh
. /usr/lib/superwifi/fw.sh
sw_fw_auth "aa:bb:cc:dd:ee:01" "192.168.10.50" "86400"
nft get element inet superwifi authenticated '{ aa:bb:cc:dd:ee:01 . 192.168.10.50 }'
```
**Expected:** Exit code 0 (element found)

---

### TC-FW-02: Firewall Deauth Removes MAC+IP
```sh
sw_fw_deauth "aa:bb:cc:dd:ee:01" "192.168.10.50"
nft get element inet superwifi authenticated '{ aa:bb:cc:dd:ee:01 . 192.168.10.50 }'
```
**Expected:** Exit code non-zero (element not found)

---

### TC-FW-03: TC Rate Limiting Applied Correctly
```sh
. /usr/lib/superwifi/tc.sh
sw_tc_apply "aa:bb:cc:dd:ee:01" "192.168.10.50" "2048" "1024" "1001"
tc class show dev br-lan classid 1:1001
```
**Expected:** HTB class with `rate 2048Kbit ceil 2048Kbit`; u32 filter for IP

---

### TC-FW-04: [FIX M1] Expired Session Gets 1s Timeout
```sh
PAST=$(( $(date +%s) - 3600 ))
. /usr/lib/superwifi/fw.sh
result=$(sw_calc_timeout "$PAST")
echo "Result: $result"
```
**Expected:** `1` (not 60)

---

### TC-FW-05: Boot Restore — Active Valid Sessions Re-Added
```sh
FUTURE=$(( $(date +%s) + 3600 ))
sqlite3 $DB "UPDATE session SET expires_at=$FUTURE WHERE voucher_code='TEST001';"
sh /usr/lib/superwifi/fw-restore.sh
nft get element inet superwifi authenticated '{ MAC . IP }'
```
**Expected:** Session is back in nft set

---

## 🔒 Section 4 — Security Tests

### TC-SEC-01: SQL Injection via Voucher Code
```sh
curl -s -X POST "http://192.168.10.1/cgi-bin/auth.sh" -d "voucher='; DROP TABLE voucher; --"
curl -s -X POST "http://192.168.10.1/cgi-bin/auth.sh" -d "voucher=NORMAL' OR '1'='1"
sqlite3 $DB "SELECT COUNT(*) FROM voucher;"
```
**Expected:** Both return `VOUCHER_NOT_FOUND`; voucher table still intact

---

### TC-SEC-02: [FIX M12] BLOCK_DUR Sanitization
```sh
# Verify sanitization in auth.sh at startup
grep 'tr -dc.*0-9.*BLOCK_DUR\|BLOCK_DUR.*tr -dc' /www/cgi-bin/auth.sh
```
**Expected:** Line found confirming sanitization is in place

---

### TC-SEC-03: [FIX M4] Epoch SQL Injection in Sync
```sh
. /usr/lib/superwifi/db-queries.sh
db_supabase_mark_all_synced "0; DROP TABLE session; --"
sqlite3 $DB "SELECT COUNT(*) FROM session;"
```
**Expected:** Function returns error; session table intact with all rows

---

### TC-SEC-04: Concurrent First-Punch Race Condition
```sh
# Reset
reset_test && create_voucher
# Launch two simultaneous auth attempts
curl -s -X POST "http://192.168.10.1/cgi-bin/auth.sh" -d "voucher=TEST001" &
curl -s -X POST "http://192.168.10.1/cgi-bin/auth.sh" -d "voucher=TEST001" &
wait
sqlite3 $DB "SELECT COUNT(*) FROM session WHERE voucher_code='TEST001';"
```
**Expected:** Exactly `1` session (NOT EXISTS guard works)

---

### TC-SEC-05: Quarantined Device Cannot Use Any Voucher
```sh
nft add element inet superwifi quarantined '{ aa:bb:cc:dd:ee:ff timeout 60m }'
curl -s -X POST "http://192.168.10.1/cgi-bin/auth.sh" -d "voucher=TEST001"
```
**Expected:** `MAC_BANNED` error; no session created

---

## 📡 Section 5 — Portal UI

### TC-UI-01: Capport — Unauthenticated Device
```sh
curl -s "http://192.168.10.1/cgi-bin/auth.sh?action=capport"
```
**Expected:** `{"captive":true,"user-portal-url":"http://192.168.10.1/superwifi/login.html"}`

---

### TC-UI-02: Capport — Authenticated Device Shows Session Metrics
**Precondition:** Device authenticated  
**Expected:**
```json
{"captive":false,"bytes-remaining":900000000,"rate_down_kbps":2048,"rate_up_kbps":1024,"remaining_min":1435}
```

---

### TC-UI-03: Auto-Reconnect Flow (Active Session)
**Steps:**
1. Device has an active session in DB
2. Open any HTTP URL to trigger captive portal
3. Portal page loads and detects active session in background
**Expected:** Browser auto-redirected within 3 seconds without manual code entry

---

### TC-UI-04: Duration Display (Max 2 Units)
**Steps:** Connect with a voucher that has ~2 months remaining  
**Expected:**
- Shows `"2 شهر, 5 يوم"` (Arabic) or `"2 mo, 5 d"` (English)
- Never shows more than 2 time units
- Never shows raw epoch/date string

---

### TC-UI-05: Arabic Units for Speed and Data
**Steps:** Switch portal to العربية then connect  
**Expected:**
- Download: `"2 ميجا"` (not `"2 Mbps"`)
- Data remaining: `"849.2 ميجا"` (not `"849.2 MB"`)
- Storage: `"1.5 جيجا"` (not `"1.5 GB"`)

---

## 🔄 Section 6 — Sentinel & Recovery (sw-sentinel.sh)

### TC-SENT-01: Ghost Firewall Entry Cleanup
```sh
# Add orphan entry manually
nft add element inet superwifi authenticated '{ aa:11:22:33:44:55 . 192.168.10.200 }'
# Run sentinel
sh /usr/lib/superwifi/sw-sentinel.sh
# Verify removed
nft get element inet superwifi authenticated '{ aa:11:22:33:44:55 . 192.168.10.200 }' 2>&1
```
**Expected:** Non-zero exit (element removed)

---

### TC-SENT-02: Missing FW Entry Restored
```sh
# Remove entry from nft but keep in DB
sw_fw_deauth "$MAC" "$IP"
sh /usr/lib/superwifi/sw-sentinel.sh
nft get element inet superwifi authenticated "{ $MAC . $IP }"
```
**Expected:** Entry re-added by sentinel

---

## ⚡ Section 7 — Edge Cases

### TC-EDGE-01: Unlimited Data Voucher
```sh
sqlite3 $DB "INSERT INTO voucher (..., data_limit_bytes=0, ...) ..."
curl -s "http://192.168.10.1/cgi-bin/auth.sh?action=capport"
```
**Expected:** `"bytes-remaining"` not present or shown as unlimited; no quota expiry

---

### TC-EDGE-02: Unlimited Time Voucher
```sh
sqlite3 $DB "INSERT INTO voucher (..., duration_min=0, valid_until=0) ..."
```
**Expected:** Portal shows unlimited time; session never expires by time

---

### TC-EDGE-03: Very Large Quota (1 TB)
```sh
sqlite3 $DB "INSERT INTO voucher (..., data_limit_bytes=1099511627776) ..."
```
**Expected:**
- Arithmetic in accounting doesn't overflow
- Portal displays `"1024 جيجا"` or similar correctly

---

### TC-EDGE-04: Time Block Midnight Wrap-Around
```sh
sqlite3 $DB "UPDATE voucher SET time_block_start=2200, time_block_end=0600 WHERE code='TEST001';"
# Manually test with NOW_HM set to 2330 (should block) and 0700 (should allow)
```
**Expected:**
- At 23:30 → `TIME_BLOCKED`
- At 07:00 → auth succeeds

---

### TC-EDGE-05: Concurrent Accounting + Auth (DB Lock Test)
```sh
# Start accounting cycle in background
sh /usr/sbin/sw-acct.sh &
# Immediately auth
curl -X POST -d "voucher=TEST001" "http://192.168.10.1/cgi-bin/auth.sh"
wait
```
**Expected:** Both complete; no SQLITE_BUSY errors logged; DB consistent

---

## ✅ Test Results Tracking

| Test ID | Description | Status | Notes |
|---------|-------------|--------|-------|
| TC-AUTH-01 | First punch valid voucher | ⬜ | |
| TC-AUTH-02 | Re-auth IP change | ⬜ | |
| TC-AUTH-03 | MAC mismatch | ⬜ | |
| TC-AUTH-04 | Expired voucher pre-punch | ⬜ | |
| TC-AUTH-05 | Quota exhausted | ⬜ | |
| TC-AUTH-06 | Invalid code error | ⬜ | |
| TC-AUTH-07 | Rate limiting max fails | ⬜ | |
| TC-AUTH-08 | Rate limit bypass fix (H2) | ⬜ | |
| TC-AUTH-09 | Quarantine rebind fix (H1) | ⬜ | |
| TC-AUTH-10 | Time block enforcement | ⬜ | |
| TC-ACCT-01 | Byte counting | ⬜ | |
| TC-ACCT-02 | Quota expiry | ⬜ | |
| TC-ACCT-03 | Time expiry | ⬜ | |
| TC-ACCT-04 | No double-count on reauth (C1) | ⬜ | |
| TC-ACCT-05 | No expired restore (H4) | ⬜ | |
| TC-ACCT-06 | Unlimited session | ⬜ | |
| TC-FW-01 | Auth adds to nft | ⬜ | |
| TC-FW-02 | Deauth removes from nft | ⬜ | |
| TC-FW-03 | TC rate limiting correct | ⬜ | |
| TC-FW-04 | Expired = 1s timeout (M1) | ⬜ | |
| TC-FW-05 | Boot restore active sessions | ⬜ | |
| TC-SEC-01 | SQL injection voucher | ⬜ | |
| TC-SEC-02 | BLOCK_DUR sanitize (M12) | ⬜ | |
| TC-SEC-03 | Epoch SQL inject (M4) | ⬜ | |
| TC-SEC-04 | Concurrent first-punch race | ⬜ | |
| TC-SEC-05 | Quarantined device blocked | ⬜ | |
| TC-UI-01 | Capport unauthenticated | ⬜ | |
| TC-UI-02 | Capport authenticated metrics | ⬜ | |
| TC-UI-03 | Auto-reconnect flow | ⬜ | |
| TC-UI-04 | Duration display max 2 units | ⬜ | |
| TC-UI-05 | Arabic units speed/data | ⬜ | |
| TC-SENT-01 | Ghost cleanup | ⬜ | |
| TC-SENT-02 | Missing session restore | ⬜ | |
| TC-EDGE-01 | Unlimited data | ⬜ | |
| TC-EDGE-02 | Unlimited time | ⬜ | |
| TC-EDGE-03 | 1TB quota | ⬜ | |
| TC-EDGE-04 | Midnight time block | ⬜ | |
| TC-EDGE-05 | Concurrent DB access | ⬜ | |

> **Legend:** ⬜ Not tested &nbsp;|&nbsp; ✅ Pass &nbsp;|&nbsp; ❌ Fail &nbsp;|&nbsp; ⚠️ Partial

---

## 📝 Design Decisions & Constraints
* **Quota Management (Download Only):** Due to performance implications of `ifb` interfaces on OpenWrt, the system explicitly accounts for **Download (Egress)** traffic only in `tc_stats`. Upload traffic is unmetered. This should be communicated to the end users as a "Download Quota".
