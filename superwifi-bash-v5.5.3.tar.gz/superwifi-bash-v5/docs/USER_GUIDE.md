# 📡 SuperWiFi v5 — User Guide & CLI Reference

> **Version:** 4.0 &nbsp;|&nbsp; **Platform:** OpenWrt 23.x+ &nbsp;|&nbsp; **License:** Proprietary
>
> Enterprise-grade captive portal, voucher management, and bandwidth shaping for OpenWrt routers.

---

## 📑 Table of Contents

| # | Section | Description |
|---|---------|-------------|
| 1 | [Quick Start](#-1-quick-start) | Fresh install in under 5 minutes |
| 2 | [Configuration](#-2-configuration) | All UCI options explained |
| 3 | [Package Management](#-3-package-management) | Create & manage service tiers |
| 4 | [Voucher Management](#-4-voucher-management) | Generate, import & administer vouchers |
| 5 | [Session Management](#-5-session-management) | Monitor & control active sessions |
| 6 | [Security Operations](#-6-security-operations) | Quarantine, bypass & threat response |
| 7 | [Monitoring & Diagnostics](#-7-monitoring--diagnostics) | Health checks & live monitoring |
| 8 | [Service Control](#-8-service-control) | Start, stop & manage the daemon |
| 9 | [Database Path Trade-offs](#-9-database-path-trade-offs) | RAM vs Flash storage decisions |
| 10 | [Troubleshooting](#-10-troubleshooting) | Common issues & solutions |

---

## 🚀 1. Quick Start

Get SuperWiFi running on a fresh OpenWrt installation in four steps.

### Prerequisites

| Requirement | Minimum | Recommended |
|-------------|---------|-------------|
| OpenWrt | 23.05 | 23.05.5+ |
| RAM | 64 MB | 128 MB+ |
| Flash | 16 MB | 32 MB+ |
| CPU | MIPS 24Kc | ARM Cortex-A7+ |

### Step-by-Step Installation

```bash
# Step 1 — Install system dependencies
opkg update && opkg install sqlite3-cli tc-full kmod-sched-core kmod-sched

# Step 2 — Deploy SuperWiFi files to the system
cp -r superwifi-bash-v5/src/* /
chmod +x /usr/sbin/sw /usr/sbin/sw-acct.sh /etc/init.d/superwifi

# Step 3 — Enable and start the service
/etc/init.d/superwifi enable
/etc/init.d/superwifi start

# Step 4 — Verify that everything is running
sw status
```

> [!TIP]
> Run `sw config-check` after installation to validate your UCI configuration before starting the service.

**Expected output from `sw status`:**

```
SuperWiFi v5.0 — Status
━━━━━━━━━━━━━━━━━━━━━━━
Service     : running
Database    : /tmp/superwifi/superwifi.db
Active      : 0 sessions
Uptime      : 0h 0m
Sentinel    : enabled
```

---

## ⚙️ 2. Configuration

All configuration is managed through UCI at `/etc/config/superwifi`. Edit with `uci` commands or directly modify the file.

### Section: `core` — 17 Options

The primary configuration section controlling all runtime behavior.

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `db_path` | string | `/tmp/superwifi/superwifi.db` | SQLite database file path |
| `lan_iface` | string | `br-lan` | LAN bridge interface name |
| `wan_iface` | string | `wan` | WAN interface name |
| `portal_ip` | string | `192.168.10.1` | Captive portal IP address |
| `portal_port` | int | `80` | Portal HTTP listening port |
| `portal_url` | string | `http://192.168.10.1/superwifi/login.html` | Full login page URL |
| `capport_api_url` | string | `http://192.168.10.1/api/capport` | RFC 8908 Captive Portal API URL |
| `custom_theme` | bool | `0` | Enable custom branded portal theme |
| `check_interval_sec` | int | `60` | Accounting cycle interval in seconds |
| `tc_burst_kb` | int | `64` | TC HTB burst size in kilobytes |
| `anomaly_multiplier` | float | `1.2` | Rate anomaly detection threshold (`1.0` = disabled) |
| `mac_rebind_enabled` | bool | `0` | Allow a voucher to rebind to a new MAC |
| `enable_sync` | bool | `0` | Enable cloud synchronization |
| `sync_interval` | int | `5` | Cloud sync interval in minutes |
| `max_failed_attempts` | int | `10` | Failed login attempts before auto-block |
| `block_duration_min` | int | `15` | Auto-block duration in minutes |
| `sentinel_enabled` | bool | `1` | Enable self-healing session reconciliation |
| `rate_limit` | int | `30` | Maximum authentication requests per minute |

```bash
# Example: Change the accounting interval to 30 seconds
uci set superwifi.core.check_interval_sec=30
uci commit superwifi
/etc/init.d/superwifi restart
```

### Section: `gateway` — Cloud Gateway Identity

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `gateway_id` | string | `''` | Unique gateway identifier for cloud sync |
| `gateway_password` | string | `''` | Gateway authentication password |

```bash
# Example: Register a gateway for cloud sync
uci set superwifi.gateway.gateway_id="GW-CAFE-001"
uci set superwifi.gateway.gateway_password="s3cur3P@ss!"
uci commit superwifi
```

### Section: `credentials` — Supabase Cloud Keys

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `supabase_url` | string | `''` | Supabase project URL |
| `supabase_key` | string | `''` | Supabase anonymous (public) key |

> [!WARNING]
> Never expose your `supabase_key` in public repositories. Restrict RLS policies to prevent unauthorized data access.

### Section: `bypass` — MAC Bypass List

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `list mac` | list | *(empty)* | MAC addresses that skip the captive portal entirely |

```bash
# Example: Add bypass entries for staff devices
uci add_list superwifi.bypass.mac="AA:BB:CC:DD:EE:01"
uci add_list superwifi.bypass.mac="AA:BB:CC:DD:EE:02"
uci commit superwifi
/etc/init.d/superwifi restart
```

---

## 📦 3. Package Management

Packages define service tiers — each with speed limits, data caps, and duration.

### Package Parameters

| Parameter | Unit | `0` Means |
|-----------|------|-----------|
| `download_kbps` | kilobits/sec | No shaping |
| `upload_kbps` | kilobits/sec | No shaping |
| `data_limit_bytes` | bytes | ♾️ Unlimited data |
| `duration_min` | minutes | ♾️ No time limit |
| `price_cents` | cents | Free |

### Creating Packages

```bash
# Syntax: sw add-package "<name>" <download_kbps> <upload_kbps> <data_limit_bytes> <duration_min> <price_cents>

# 50MB daily package — 4 Mbps down, 2 Mbps up, 50MB cap, 24h, $5.00
sw add-package "50MB Daily" 4096 2048 52428800 1440 500

# Unlimited staff package — 10 Mbps symmetric, no data cap, no expiry, free
sw add-package "Unlimited Staff" 10240 10240 0 0 0

# Budget hourly — 1 Mbps down, 512 Kbps up, 25MB cap, 1 hour, $1.00
sw add-package "Budget Hour" 1024 512 26214400 60 100
```

### Listing & Deleting Packages

```bash
# List all defined packages
sw list-packages

# Delete package by ID
sw delete-package 3
```

**Example `sw list-packages` output:**

```
ID  Name              Down(kb)  Up(kb)   Data(B)       Dur(m)  Price(c)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1   50MB Daily         4096      2048     52428800      1440    500
2   Unlimited Staff    10240     10240    0             0       0
3   Budget Hour        1024      512      26214400      60      100
```

---

## 🎟️ 4. Voucher Management

### 4.1 Generate Vouchers

Bulk-generate voucher codes with full control over format, limits, and export.

#### Generation Flags

| Flag | Long Form | Default | Description |
|------|-----------|---------|-------------|
| `-c` | `--count` | `1` | Number of vouchers to generate |
| `-p` | `--package` | *(none)* | Package ID to inherit settings from |
| `-t` | `--type` | `alphanum` | Code type: `digits`, `hex`, `alphanum` |
| `-l` | `--length` | `6` | Code character length |
| | `--prefix` | `''` | Code prefix (e.g. `CAFE-`) |
| `-v` | `--valid` | `30` | Validity window in days |
| `-u` | `--rate-up` | *(pkg)* | Override upload rate in kbps |
| `-d` | `--rate-down` | *(pkg)* | Override download rate in kbps |
| | `--data-limit` | *(pkg)* | Override data limit in MB |
| `-m` | `--duration` | *(pkg)* | Override duration in minutes |
| | `--price` | *(pkg)* | Override price in cents |
| `-o` | `--output` | *(none)* | Export generated codes to CSV file |

#### Generation Examples

```bash
# Generate 100 vouchers from package 1 (inherits all settings)
sw generate -c 100 -p 1

# Generate 50 digit-only 8-char codes with prefix
sw generate -c 50 -p 2 -t digits -l 8 --prefix "CAFE-"

# Generate 10 standalone vouchers with custom limits (no package)
sw generate -c 10 --rate-down 4096 --rate-up 2048 --data-limit 100 -m 60

# Generate 200 vouchers and export to CSV for printing
sw generate -c 200 -p 1 -o /tmp/vouchers.csv
```

> [!TIP]
> Use `--prefix` with a location code (e.g., `LOBBY-`, `POOL-`) to visually identify where vouchers are distributed.

### 4.2 Manual Voucher Creation

Create individual vouchers with a specific code.

```bash
# Create a voucher inheriting settings from package 1
sw add-voucher MYCODE123 --pkg 1

# Create a standalone voucher with explicit parameters
# Syntax: sw add-voucher <code> <down_kbps> <up_kbps> <data_limit_bytes> <duration_min> <price_cents>
sw add-voucher CUSTOM01 4096 2048 104857600 120 0
```

### 4.3 Bulk Import from CSV

Import pre-generated voucher codes from a CSV file, linked to an existing package.

```bash
# Import codes from CSV and assign to package 1
sw import-vouchers /tmp/codes.csv 1
```

**CSV format** — one code per line:

```csv
CODE001
CODE002
CODE003
```

---

## 🖥️ 5. Session Management

### 5.1 View Active Sessions

```bash
# Human-readable table output
sw list

# Machine-readable JSON for scripting
sw list-json
```

**Example `sw list` output:**

```
MAC               IP             Voucher    DL(kb)  UL(kb)  Used(MB)  Rem(MB)  Class   Expiry
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
00:11:22:33:44:55 192.168.10.101 ABC123     4096    2048    12.5      37.5     1:10    2026-07-06 14:30
AA:BB:CC:DD:EE:FF 192.168.10.102 XYZ789     10240   10240   245.8     ∞        1:20    never
```

#### Column Reference

| Column | Description |
|--------|-------------|
| **MAC** | Client device MAC address |
| **IP** | Assigned LAN IP address |
| **Voucher** | Active voucher code |
| **DL(kb)** | Download rate limit in kbps |
| **UL(kb)** | Upload rate limit in kbps |
| **Used(MB)** | Data consumed in megabytes |
| **Rem(MB)** | Remaining data (`∞` = unlimited) |
| **Class** | TC traffic class identifier (`major:minor`) |
| **Expiry** | Session expiration timestamp (`never` = no limit) |

### 5.2 Force Auth / Deauth

Manually authenticate or disconnect a device by MAC address.

```bash
# Force-authenticate a device (bypass voucher check)
sw auth 00:11:22:33:44:55

# Force-deauthenticate a device (disconnect immediately)
sw deauth 00:11:22:33:44:55
```

> [!IMPORTANT]
> `sw auth` grants access without a voucher — use only for diagnostics or emergency access.

### 5.3 Voucher Operations

Manage individual voucher lifecycle and state.

```bash
# Revoke a voucher — marks it as used, disconnects the active session
sw revoke VOUCHER123

# Disconnect the session but keep the voucher valid for re-use
sw disconnect-voucher CODE1

# Reset MAC binding so the voucher can be used on a different device
sw reset-voucher-mac CODE1

# Block a voucher permanently (abuse prevention)
sw block-voucher BADCODE

# Unblock a previously blocked voucher
sw unblock-voucher BADCODE
```

| Command | Disconnects? | Voucher Reusable? | Use Case |
|---------|:------------:|:-----------------:|----------|
| `revoke` | ✅ | ❌ | End a session permanently |
| `disconnect-voucher` | ✅ | ✅ | Temporary disconnect |
| `reset-voucher-mac` | ❌ | ✅ (new MAC) | Device change |
| `block-voucher` | ✅ | ❌ | Abuse prevention |
| `unblock-voucher` | ❌ | ✅ | Restore access |

---

## 🛡️ 6. Security Operations

### 6.1 Quarantine

Isolate suspicious devices — blocks all internet access while keeping them on the network for investigation.

```bash
# Quarantine a suspicious device
sw quarantine 00:11:22:33:44:55

# Release a device from quarantine
sw unquarantine 00:11:22:33:44:55
```

> [!CAUTION]
> Quarantined devices remain connected to the LAN but cannot reach the WAN. Use this for investigating abuse before deciding to permanently block.

### 6.2 MAC Bypass Configuration

Devices in the bypass list are never redirected to the captive portal — ideal for staff laptops, POS terminals, and infrastructure.

```bash
# Add a MAC to the bypass list via UCI
uci add_list superwifi.bypass.mac="AA:BB:CC:DD:EE:01"
uci add_list superwifi.bypass.mac="AA:BB:CC:DD:EE:02"
uci commit superwifi

# Restart to apply changes
/etc/init.d/superwifi restart
```

**Or edit `/etc/config/superwifi` directly:**

```
config bypass
    list mac 'AA:BB:CC:DD:EE:01'
    list mac 'AA:BB:CC:DD:EE:02'
```

### 6.3 Rate Limiting & Brute-Force Protection

SuperWiFi automatically enforces login rate limits:

| Setting | Default | Effect |
|---------|---------|--------|
| `rate_limit` | 30/min | Rejects excess auth requests |
| `max_failed_attempts` | 10 | Triggers auto-block after N failures |
| `block_duration_min` | 15 | Duration of auto-block in minutes |

---

## 📊 7. Monitoring & Diagnostics

### `sw status` — System Overview

Displays daemon state, database path, active session count, uptime, and sentinel status.

```bash
sw status
```

```
SuperWiFi v5.0 — Status
━━━━━━━━━━━━━━━━━━━━━━━
Service     : running
Database    : /tmp/superwifi/superwifi.db
Active      : 12 sessions
Uptime      : 3h 42m
Sentinel    : enabled
Rate Limit  : 30 req/min
```

### `sw monitor` — Live Dashboard

Real-time view of sessions, bandwidth usage, and events. Press `Ctrl+C` to exit.

```bash
sw monitor
```

```
╔══════════════════════════════════════════════════════════════╗
║  SuperWiFi Monitor — Live                  12 active users  ║
╠══════════════════════════════════════════════════════════════╣
║  Total ↓  48.2 Mbps   Total ↑  12.7 Mbps                   ║
║  Events   3 auths | 1 deauth | 0 anomalies (last 60s)      ║
╚══════════════════════════════════════════════════════════════╝
```

### `sw log` — Recent Activity Log

View the last N log entries (default: 50).

```bash
# Show last 50 log entries
sw log

# Show last 100 entries
sw log 100
```

### `sw config-check` — Configuration Validator

Validates all UCI settings and reports warnings or errors.

```bash
sw config-check
```

```
SuperWiFi Config Check
━━━━━━━━━━━━━━━━━━━━━━
[✔] db_path         : /tmp/superwifi/superwifi.db
[✔] lan_iface       : br-lan (exists)
[✔] wan_iface       : wan (exists)
[✔] portal_ip       : 192.168.10.1
[✔] portal_port     : 80
[✔] sentinel        : enabled
[⚠] enable_sync     : disabled (cloud sync off)
━━━━━━━━━━━━━━━━━━━━━━
Result: 6 OK, 1 Warning, 0 Errors
```

---

## 🔄 8. Service Control

| Command | Description |
|---------|-------------|
| `/etc/init.d/superwifi start` | Start the SuperWiFi daemon |
| `/etc/init.d/superwifi stop` | Stop the daemon gracefully |
| `/etc/init.d/superwifi restart` | Restart (stop + start) |
| `/etc/init.d/superwifi enable` | Auto-start on boot |
| `/etc/init.d/superwifi disable` | Disable auto-start |
| `sw version` | Print version and build info |

```bash
# Full restart cycle
/etc/init.d/superwifi stop
/etc/init.d/superwifi start

# Quick version check
sw version
# Output: SuperWiFi v5.0 (build 2026.07)
```

---

## 💾 9. Database Path Trade-offs

SuperWiFi stores session and voucher data in an SQLite database. The `db_path` setting determines storage location.

| Location | Speed | Persistence | Flash Wear | Best For |
|----------|:-----:|:-----------:|:----------:|----------|
| `/tmp/superwifi/` (RAM) | ⚡ Fast | ❌ Lost on reboot | ✅ None | High-traffic venues, kiosks |
| `/usr/lib/superwifi/` (Flash) | 🐢 Slower | ✅ Survives reboot | ⚠️ Wear concern | Low-traffic, persistent data |

### RAM Path — `/tmp/` (Default)

- **Pros:** Fastest I/O, no flash degradation, ideal for high-throughput environments.
- **Cons:** Database is lost on reboot or power failure.
- **Mitigation:** Sentinel mode (`sentinel_enabled=1`) automatically reconciles sessions on restart by re-scanning connected clients and restoring firewall/TC rules.

### Flash Path — `/usr/lib/`

- **Pros:** Voucher and session data survives reboots.
- **Cons:** Slower writes, contributes to NAND/NOR flash wear over time.
- **Recommendation:** Use only on devices with ample flash (32MB+) in low-traffic deployments.

```bash
# Switch to persistent flash storage
uci set superwifi.core.db_path="/usr/lib/superwifi/superwifi.db"
uci commit superwifi
mkdir -p /usr/lib/superwifi
/etc/init.d/superwifi restart
```

---

## 🔧 10. Troubleshooting

### Common Issues

| # | Symptom | Cause | Solution |
|---|---------|-------|----------|
| 1 | 🔴 `sw status` shows "not running" | Service crashed or was never started | Run `/etc/init.d/superwifi start` and check `logread` for errors |
| 2 | 🔴 Clients not redirected to portal | iptables rules missing or `portal_ip` misconfigured | Run `sw config-check`; verify `lan_iface` matches your bridge |
| 3 | 🟡 Voucher accepted but no internet | TC shaping rules not applied; `tc-full` not installed | Install: `opkg install tc-full kmod-sched-core kmod-sched` |
| 4 | 🟡 "Database locked" errors in log | Concurrent writes from accounting + auth | Increase `check_interval_sec` to reduce contention; ensure single instance |
| 5 | 🔴 Bandwidth not shaped correctly | `tc_burst_kb` too low for high-speed plans | Increase `tc_burst_kb` (e.g., `128` for plans above 10 Mbps) |
| 6 | 🟡 Sessions lost after reboot | `db_path` set to `/tmp/` (RAM) | Enable `sentinel_enabled=1` for auto-recovery, or move DB to flash |
| 7 | 🔴 Rate anomaly false positives | `anomaly_multiplier` too aggressive | Increase to `1.5` or set `1.0` to disable anomaly detection |
| 8 | 🟡 Cloud sync not working | Missing `supabase_url` or `supabase_key` | Set credentials via `uci`; ensure `enable_sync=1` and check connectivity |
| 9 | 🔴 Login page not loading | uhttpd not serving portal files | Verify portal files exist at `/www/superwifi/` and uhttpd is running |
| 10 | 🟡 MAC rebind denied | `mac_rebind_enabled=0` (default) | Set `uci set superwifi.core.mac_rebind_enabled=1` if rebind is desired |

### Diagnostic Checklist

```bash
# 1. Check service status
sw status

# 2. Validate configuration
sw config-check

# 3. Review recent logs
sw log 100

# 4. Inspect iptables rules
iptables -t nat -L SUPERWIFI_PORTAL -n -v

# 5. Verify TC shaping classes
tc class show dev br-lan

# 6. Check database integrity
sqlite3 /tmp/superwifi/superwifi.db "PRAGMA integrity_check;"

# 7. Test captive portal redirect
curl -I http://detectportal.firefox.com
```

---

> **📖 Need help?** Run `sw --help` for a complete command listing, or visit the project repository for updates and community support.
>
> **SuperWiFi v5** — *Enterprise captive portal, simplified.*
