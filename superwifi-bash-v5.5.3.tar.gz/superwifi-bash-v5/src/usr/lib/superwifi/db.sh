#!/bin/sh
# /usr/lib/superwifi/db.sh
# SuperWiFi v5 — Database Abstraction Layer
# Handles connection setup, PRAGMA tuning, and core query helpers.
# All business-logic queries live in db-queries.sh.

. /usr/lib/superwifi/core.sh

# -- Sanitization -----------------------------------------------------------
# Escapes single quotes for safe SQL string interpolation.
# All user-supplied values MUST pass through this before reaching SQL.
db_escape() {
    # Remove null bytes, $, backticks, and backslashes to prevent shell/command injection. Then escape single quotes for SQL.
    printf "%s" "$1" | tr -d '\000$`\\' | sed "s/'/''/g"
}

# ------------------------------------------------------------------------------
# Core Query Function
# ------------------------------------------------------------------------------
# All database interactions MUST go through this function to ensure
# proper pragmas, timeouts, and WAL mode concurrency.
db_query() {
    # WARNING: Do NOT use -cmd "PRAGMA journal_mode=WAL;" here as it prints 'wal' to stdout
    # and corrupts the output of SELECT statements. WAL mode is persistent and is set in sw_db_init.
    sqlite3 \
        -cmd ".timeout 5000" \
        -cmd "PRAGMA synchronous=NORMAL;" \
        -cmd "PRAGMA foreign_keys=ON;" \
        -cmd "PRAGMA cache_size=-2000;" \
        -cmd "PRAGMA temp_store=MEMORY;" \
        "$DB_PATH" "$1" 2>/dev/null
}

# Batch execution from a SQL file (used by sw-acct.sh for bulk updates).
# Skips per-query PRAGMAs — the batch file handles its own transaction.
# journal_mode=WAL is persistent (set once, stored in DB header).
db_exec_batch() {
    local file="$1"
    sqlite3 \
        -cmd ".timeout 5000" \
        -cmd "PRAGMA synchronous=NORMAL;" \
        -cmd "PRAGMA foreign_keys=ON;" \
        -cmd "PRAGMA cache_size=-2000;" \
        -cmd "PRAGMA temp_store=MEMORY;" \
        "$DB_PATH" < "$file" 2>/dev/null
}

# -- Database Initialization ------------------------------------------------
sw_db_init() {
    local db_dir
    db_dir=$(dirname "$DB_PATH")
    mkdir -p "$db_dir" || {
        sw_log "FATAL" "cannot create DB dir $db_dir"
        return 1
    }
    mkdir -p /tmp/superwifi 2>/dev/null

    if [ ! -f "$DB_PATH" ]; then
        # First-time initialization: set page_size BEFORE creating tables.
        # page_size can only be set on a new, empty database.
        sqlite3 "$DB_PATH" <<-'EOINIT'
            PRAGMA page_size = 4096;
            PRAGMA journal_mode = WAL;
            PRAGMA auto_vacuum = INCREMENTAL;
EOINIT
        db_query ".read /etc/superwifi/schema.sql" || {
            sw_log "FATAL" "schema init failed for $DB_PATH"
            return 1
        }
        sw_log "INFO" "DB initialized at $DB_PATH (v5 schema)"
    fi

    # Ensure WAL mode is active (idempotent — no-op if already set).
    # WAL mode is persistent: stored in the DB header, survives restarts.
    db_query "PRAGMA journal_mode = WAL;" >/dev/null

    # Database Migrations (v5.5.3)
    db_query "
        CREATE TABLE IF NOT EXISTS system_config (
            key             TEXT PRIMARY KEY,
            value           TEXT NOT NULL,
            updated_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
        );
        INSERT OR IGNORE INTO system_config (key, value) VALUES ('firmware_version', '5.5.3');
    " >/dev/null
    
    # Apply schema migrations automatically for existing DBs
    db_query "ALTER TABLE session ADD COLUMN last_sync_at INTEGER;" >/dev/null 2>&1
    db_query "DROP TRIGGER IF EXISTS trg_quota_enforce;" >/dev/null 2>&1

    return 0
}

# -- Maintenance Helpers ----------------------------------------------------
# Manual WAL checkpoint — called from the 10-minute maintenance cycle.
# PASSIVE mode: checkpoint only pages that don't require blocking writers.
# This is flash-friendly: batches dirty pages into a single write operation.
db_checkpoint() {
    db_query "PRAGMA wal_checkpoint(PASSIVE);" >/dev/null
}

# Full checkpoint + truncate — called on service stop or before backup.
# Writes all WAL pages back to the main DB file and truncates the WAL.
db_checkpoint_full() {
    db_query "PRAGMA wal_checkpoint(TRUNCATE);" >/dev/null
}

# Incremental auto-vacuum — reclaims free pages without full VACUUM.
# Much cheaper than VACUUM on flash storage: rewrites only freed pages.
db_incremental_vacuum() {
    db_query "PRAGMA incremental_vacuum(50);" >/dev/null
}
