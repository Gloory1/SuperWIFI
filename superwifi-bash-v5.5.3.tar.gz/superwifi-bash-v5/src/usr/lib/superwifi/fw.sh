#!/bin/sh
# /usr/lib/superwifi/fw.sh
# Firewall management — MAC-centric with dynamic timeout

. /usr/lib/superwifi/core.sh
. /usr/lib/superwifi/db-queries.sh
. /usr/lib/superwifi/tc.sh

sw_fw_auth() {
    local mac="$1"
    local ip="$2"
    local timeout_sec="${3:-86400}"

    validate_mac "$mac" || return 1
    validate_ip "$ip" || return 1

    nft add element inet superwifi authenticated \
        "{ ${mac} . ${ip} timeout ${timeout_sec}s }" 2>/dev/null || return 1
    
    # Flush existing connections so active captive portal streams are reset and immediately get internet
    conntrack -D -s "$ip" 2>/dev/null || true
    return 0
}

sw_fw_cleanup_only() {
    local mac="$1"
    local ip="$2"
    local cid="$3"

    validate_mac "$mac" || return 1
    validate_ip "$ip" || { [ -z "$ip" ] && return 0; }

    nft delete element inet superwifi authenticated \
        "{ ${mac} . ${ip} }" 2>/dev/null || true
    conntrack -D -s "$ip" 2>/dev/null || true
    sw_tc_remove "$cid" 2>/dev/null || true
}

sw_fw_deauth() {
    local mac="$1"
    local ip="$2"
    local voucher="$3"
    local reason="$4"
    local passed_cid="$5"

    validate_mac "$mac" || { sw_log "ERROR" "deauth: invalid MAC '$mac'"; return 1; }

    nft delete element inet superwifi authenticated \
        "{ ${mac} . ${ip} }" 2>/dev/null || true

    conntrack -D -s "$ip" 2>/dev/null || true

    local cid="${passed_cid}"
    if [ -z "$cid" ]; then
        cid=$(db_get_class_id_by_voucher "$voucher")
    fi
    sw_tc_remove_by_ip "$ip" 2>/dev/null || true
    sw_tc_remove "$cid"

    if [ "$reason" != "cloud_reset_mac" ] && [ "$reason" != "mac_reset" ] && [ "$reason" != "time_blocked" ]; then
        db_deactivate_voucher_by_code "$voucher"
    fi

    sw_log "INFO" "DEAUTH: mac=$mac ip=$ip voucher=$voucher reason=$reason"
}

sw_fw_block_mac() {
    local mac="$1"
    validate_mac "$mac" || return 1
    nft add element inet superwifi quarantined "{ ${mac} }" 2>/dev/null || true
}

sw_fw_unblock_mac() {
    local mac="$1"
    validate_mac "$mac" || return 1
    nft delete element inet superwifi quarantined "{ ${mac} }" 2>/dev/null || true
}

sw_calc_timeout() {
    local expires_at="${1:-0}"
    local now_epoch timeout_sec
    now_epoch=$(date    +%s)
    if [ "$expires_at" -gt 0 ]; then
        timeout_sec=$(( expires_at - now_epoch ))
        # [FIX M1] Use 1s (not 60s) for already-expired sessions so nft expires them immediately
        [ "$timeout_sec" -le 0 ] && timeout_sec=1
    else
        timeout_sec=86400
    fi
    printf '%s' "$timeout_sec"
}
