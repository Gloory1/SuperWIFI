#!/bin/sh
# /www/cgi-bin/redirect.sh
# SuperWiFi Captive Portal Redirect Handler
# Triggered by uhttpd error_page 404 to catch Android/iOS captive probes.

PORTAL_URL=$(uci get superwifi.core.portal_url 2>/dev/null || echo "http://10.0.0.1/superwifi/login.html")

case "$PORTAL_URL" in
    *\?*) PORTAL_URL="${PORTAL_URL}&cp=1" ;;
    *)    PORTAL_URL="${PORTAL_URL}?cp=1" ;;
esac

printf "Status: 302 Found\r\n"
printf "Location: %s\r\n" "$PORTAL_URL"
printf "Connection: close\r\n\r\n"
