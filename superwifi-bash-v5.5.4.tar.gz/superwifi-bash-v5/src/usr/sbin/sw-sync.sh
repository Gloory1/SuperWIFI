#!/bin/sh
# /usr/sbin/sw-sync.sh
# SuperWiFi Cloud Sync (V5 Native JSON - Consolidated)

. /usr/lib/superwifi/core.sh
. /usr/lib/superwifi/db-queries.sh
. /usr/lib/superwifi/fw.sh

ENABLE_SYNC=$(uci get superwifi.core.enable_sync 2>/dev/null || echo "0")
[ "$ENABLE_SYNC" != "1" ] && exit 0

SP_URL=$(uci get superwifi.credentials.supabase_url 2>/dev/null)
SP_KEY=$(uci get superwifi.credentials.supabase_key 2>/dev/null)
GW_ID=$(uci get superwifi.gateway.gateway_id 2>/dev/null)
GW_PASS=$(uci get superwifi.gateway.gateway_password 2>/dev/null)

if [ -z "$SP_URL" ] || [ -z "$SP_KEY" ] || [ -z "$GW_ID" ]; then
    sw_log "WARN" "sw-sync: credentials empty, disabling sync"
    uci set superwifi.core.enable_sync='0'
    uci commit superwifi 2>/dev/null || true
    exit 0
fi

SYNC_LOCK="/tmp/superwifi/sw-sync.lock"
exec 8>"$SYNC_LOCK"
if ! flock -n 8; then
    sw_log "WARN" "sw-sync: already running, skipping."
    exit 0
fi

sw_db_init || exit 1

if ! command -v curl >/dev/null 2>&1; then
    sw_log "ERROR" "sw-sync: curl not found"
    exit 1
fi

sw_log "INFO" "Cloud Sync started (V5)"

NOW_TS=$(date    +%s)

# Read Firmware Version
FIRMWARE_VERSION=$(db_get_firmware_version)
if [ -z "$FIRMWARE_VERSION" ]; then
    FIRMWARE_VERSION="5.5.4"
fi

# ==============================================================================
# 1. PREPARE PAYLOAD
# ==============================================================================
VOUCHERS_JSON=$(db_supabase_get_sync_vouchers_json)
SESSIONS_JSON=$(db_supabase_get_sync_sessions_json)

# Handle empty JSON array edge cases from sqlite
[ "$VOUCHERS_JSON" = "" ] && VOUCHERS_JSON="[]"
[ "$SESSIONS_JSON" = "" ] && SESSIONS_JSON="[]"

PACKAGES_JSON=$(db_supabase_get_sync_packages_json)
[ "$PACKAGES_JSON" = "" ] && PACKAGES_JSON="[]"

payload=$(jq -n \
    --arg gw_id "$GW_ID" \
    --arg gw_pass "$GW_PASS" \
    --argjson sess "$SESSIONS_JSON" \
    --argjson vouch "$VOUCHERS_JSON" \
    --argjson pkgs "$PACKAGES_JSON" \
    --arg fw "$FIRMWARE_VERSION" \
    '{
        p_gateway_id: $gw_id,
        p_password: $gw_pass,
        p_sessions: $sess,
        p_vouchers: $vouch,
        p_packages: $pkgs,
        p_firmware_version: $fw
    }')

# ==============================================================================
# 2. EXECUTE CONSOLIDATED SYNC
# ==============================================================================
# Write curl headers to a temp config file so they don't appear in 'ps'
CURL_CFG=$(mktemp -p /tmp/superwifi 2>/dev/null || mktemp)
chmod 600 "$CURL_CFG"
printf 'header = "apikey: %s"\nheader = "Authorization: Bearer %s"\nheader = "Content-Type: application/json"\n' \
    "$SP_KEY" "$SP_KEY" > "$CURL_CFG"

SYNC_RESPONSE=$(curl -s -X POST \
    --config "$CURL_CFG" \
    -d "$payload" \
    "${SP_URL}/rest/v1/rpc/v5_sync" 2>/dev/null) || SYNC_RESPONSE=""
rm -f "$CURL_CFG"

if [ -z "$SYNC_RESPONSE" ] || [ "$SYNC_RESPONSE" = "null" ]; then
    sw_log "WARN" "sw-sync: failed to communicate with Supabase"
    exit 1
fi

# Check for unauthorized or error
error_msg=$(printf '%s' "$SYNC_RESPONSE" | jq -r '.message' 2>/dev/null)
if [ "$error_msg" != "null" ] && [ -n "$error_msg" ]; then
    sw_log "ERROR" "sw-sync: Server returned error: $error_msg"
    exit 1
fi

# ==============================================================================
# 3. PROCESS RESPONSE
# ==============================================================================

# 3A. Actions
actions_json=$(printf '%s' "$SYNC_RESPONSE" | jq -c '.actions' 2>/dev/null)
if [ "$actions_json" != "null" ] && [ "$actions_json" != "[]" ]; then
    printf '%s' "$actions_json" | jq -r '.[] | "\(.action)\t\(.voucher_code)\t\(.bound_mac)\t\(.reason)\t\(.payload | tostring)"' 2>/dev/null | \
    while IFS=$(printf '\t') read -r action_code v_code v_mac reason payload_json; do
        case "$action_code" in
            deauth)
                if [ -n "$v_code" ] && [ "$v_code" != "null" ]; then
                    mac=$(db_get_session_mac_by_voucher "$v_code")
                    ip=$(db_get_session_ip_by_voucher "$v_code")
                    if [ -n "$mac" ]; then
                        sw_fw_deauth "$mac" "$ip" "$v_code" "cloud_deauth"
                        sw_log "INFO" "sw-sync: remote deauth for $v_code"
                    fi
                fi
                ;;
            quarantine)
                if [ -n "$v_mac" ] && [ "$v_mac" != "null" ]; then
                    db_quarantine_mac "$v_mac" "cloud_quarantine"
                    sw_fw_block_mac "$v_mac"
                    sw_log "INFO" "sw-sync: remote quarantine for $v_mac"
                fi
                ;;
            unquarantine)
                if [ -n "$v_mac" ] && [ "$v_mac" != "null" ]; then
                    db_unquarantine_mac "$v_mac" "cloud_unquarantine"
                    sw_fw_unblock_mac "$v_mac"
                    sw_log "INFO" "sw-sync: remote unquarantine for $v_mac"
                fi
                ;;
            reset_mac)
                if [ -n "$v_code" ] && [ "$v_code" != "null" ]; then
                    mac=$(db_get_session_mac_by_voucher "$v_code")
                    ip=$(db_get_session_ip_by_voucher "$v_code")
                    if [ -n "$mac" ]; then
                        sw_fw_deauth "$mac" "$ip" "$v_code" "cloud_reset_mac"
                    fi
                    db_reset_voucher_mac "$v_code"
                    sw_log "INFO" "sw-sync: remote reset_mac for $v_code (old mac: $mac)"
                fi
                ;;
            apply_theme)
                script_url=$(printf '%s' "$payload_json" | jq -r '.script_url // empty' 2>/dev/null)
                if [ -n "$script_url" ] && [ "$script_url" != "null" ]; then
                    sw_log "INFO" "sw-sync: downloading theme script from $script_url"
                    theme_script=$(mktemp "/tmp/superwifi/theme_install.XXXXXX")
                    if curl -s -o "$theme_script" "$script_url"; then
                        chmod +x "$theme_script"
                        sw_log "INFO" "sw-sync: executing theme installation script"
                        
                        # Backup existing theme
                        tar -czf /tmp/superwifi/theme_backup.tar.gz -C / www/superwifi 2>/dev/null || true
                        
                        # Execute in foreground so we can verify
                        "$theme_script" >/dev/null 2>&1
                        
                        # Watchdog check
                        if [ ! -f "/www/superwifi/login.html" ]; then
                            sw_log "ERROR" "sw-sync: Theme installation corrupted login.html. Rolling back."
                            rm -rf /www/superwifi
                            tar -xzf /tmp/superwifi/theme_backup.tar.gz -C / 2>/dev/null || true
                        else
                            sw_log "INFO" "sw-sync: Theme applied successfully."
                        fi
                        rm -f /tmp/superwifi/theme_backup.tar.gz
                    else
                        sw_log "ERROR" "sw-sync: failed to download theme script from $script_url"
                    fi
                    rm -f "$theme_script"
                fi
                ;;
            change_config)
                conf_key=$(printf '%s' "$payload_json" | jq -r '.config // empty' 2>/dev/null)
                conf_val=$(printf '%s' "$payload_json" | jq -r '.value // empty' 2>/dev/null)
                if [ -n "$conf_key" ] && [ "$conf_key" != "null" ] && [ -n "$conf_val" ]; then
                    uci set superwifi."$conf_key"="$conf_val"
                    uci commit superwifi
                    sw_log "INFO" "sw-sync: updated config superwifi.$conf_key to $conf_val"
                fi
                ;;
        esac
    done
fi

# 3B. Packages
packages_json=$(printf '%s' "$SYNC_RESPONSE" | jq -c '.packages' 2>/dev/null)
if [ "$packages_json" != "null" ] && [ "$packages_json" != "[]" ]; then
    printf '%s' "$packages_json" | jq -r '.[] | "\(.id)\t\(.name)\t\(.rate_down_kbps)\t\(.rate_up_kbps)\t\(.data_limit_bytes)\t\(.duration_min)\t\(.is_visible)\t\(.price_cents)\t\(.time_block_start // "")\t\(.time_block_end // "")"' 2>/dev/null | \
    while IFS=$(printf '\t') read -r p_id p_name p_down p_up p_limit p_time p_visible p_price p_tb_start p_tb_end; do
        db_supabase_insert_downloaded_package "$p_id" "$p_name" "$p_down" "$p_up" "$p_limit" "$p_time" "$p_visible" "$p_price" "$p_tb_start" "$p_tb_end"
        sw_log "INFO" "sw-sync: downloaded package $p_name (ID: $p_id)"
    done
fi

# 3C. Vouchers
vouchers_json=$(printf '%s' "$SYNC_RESPONSE" | jq -c '.vouchers' 2>/dev/null)
if [ "$vouchers_json" != "null" ] && [ "$vouchers_json" != "[]" ]; then
    printf '%s' "$vouchers_json" | jq -r '.[] | "\(.code)\t\(.package_id)\t\(.status)"' 2>/dev/null | \
    while IFS=$(printf '\t') read -r v_code v_pkg v_status; do
        db_supabase_insert_downloaded_voucher "$v_code" "$v_pkg" "$v_status"
        sw_log "INFO" "sw-sync: downloaded voucher $v_code"
    done
fi

# 3D. Deleted Packages
del_packages_json=$(printf '%s' "$SYNC_RESPONSE" | jq -c '.deleted_packages' 2>/dev/null)
if [ "$del_packages_json" != "null" ] && [ "$del_packages_json" != "[]" ]; then
    printf '%s' "$del_packages_json" | jq -r '.[] | "\(.id)\t\(.name)"' 2>/dev/null | \
    while IFS=$(printf '\t') read -r dp_id dp_name; do
        db_supabase_delete_package "$dp_id"
        sw_log "INFO" "sw-sync: deleted package $dp_name (ID: $dp_id)"
    done
fi

# 3E. Deleted Vouchers
del_vouchers_json=$(printf '%s' "$SYNC_RESPONSE" | jq -c '.deleted_vouchers' 2>/dev/null)
if [ "$del_vouchers_json" != "null" ] && [ "$del_vouchers_json" != "[]" ]; then
    printf '%s' "$del_vouchers_json" | jq -r '.[] | "\(.code)"' 2>/dev/null | \
    while IFS=$(printf '\t') read -r dv_code; do
        mac=$(db_get_session_mac_by_voucher "$dv_code")
        ip=$(db_get_session_ip_by_voucher "$dv_code")
        if [ -n "$mac" ]; then
            sw_fw_deauth "$mac" "$ip" "$dv_code" "voucher_deleted"
            sw_log "INFO" "sw-sync: deauthed $mac because voucher $dv_code was deleted"
        fi
        db_supabase_delete_voucher "$dv_code"
        sw_log "INFO" "sw-sync: deleted voucher $dv_code"
    done
fi

# ==============================================================================
# 4. Finalize
# ==============================================================================
db_supabase_mark_all_synced "$NOW_TS"
sw_log "INFO" "Cloud Sync completed"

# ==============================================================================
# 5. Firmware Update Check
# ==============================================================================
auto_update=$(printf '%s' "$SYNC_RESPONSE" | jq -r '.auto_update' 2>/dev/null)
update_url=$(printf '%s' "$SYNC_RESPONSE" | jq -r '.update_url' 2>/dev/null)

if [ "$update_url" != "null" ] && [ -n "$update_url" ]; then
    sw_log "INFO" "sw-sync: Firmware update available at $update_url"
    
    # Check if auto update is disabled locally or remotely
    local_auto_update=$(uci get superwifi.core.auto_update 2>/dev/null || echo "1")
    # Extract expected SHA256 hash from cloud response for integrity verification
    update_hash=$(printf '%s' "$SYNC_RESPONSE" | jq -r '.update_sha256 // empty' 2>/dev/null)
    
    if [ "$local_auto_update" = "1" ] && [ "$auto_update" = "true" ]; then
        sw_log "INFO" "sw-sync: Triggering auto update..."
        /usr/sbin/sw update "$update_url" "$update_hash" &
    else
        sw_log "INFO" "sw-sync: Auto update disabled, run 'sw update $update_url $update_hash' manually."
    fi
fi
