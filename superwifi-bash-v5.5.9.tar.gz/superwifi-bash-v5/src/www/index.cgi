#!/bin/sh
printf "Status: 302 Found\r\n"
printf "Location: /superwifi/login.html\r\n\r\n"
