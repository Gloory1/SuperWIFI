#!/bin/sh
# /www/index.cgi — SuperWiFi Smart Root Router

REMOTE_IP="${REMOTE_ADDR:-}"
CLIENT_MAC=$(grep -i "^${REMOTE_IP} " /proc/net/arp 2>/dev/null | awk '{print $4}')
IS_BYPASS=0

if [ -n "$CLIENT_MAC" ]; then
    BYPASS_MACS=$(uci get superwifi.bypass.mac 2>/dev/null)
    for bmac in $BYPASS_MACS; do
        if [ "$(echo "$bmac" | tr 'A-Z' 'a-z')" = "$(echo "$CLIENT_MAC" | tr 'A-Z' 'a-z')" ]; then
            IS_BYPASS=1
            break
        fi
    done
fi

if [ "$IS_BYPASS" = "1" ]; then
    printf "Status: 302 Found\r\n"
    printf "Location: /cgi-bin/luci\r\n\r\n"
else
    printf "Status: 302 Found\r\n"
    printf "Location: /superwifi/login.html\r\n\r\n"
fi
