(function(){
  'use strict';

  // -- Polyfills for Legacy Android WebViews (Android < 9) --
  if (!String.prototype.startsWith) {
    String.prototype.startsWith = function(search, pos) {
      return this.substr(!pos || pos < 0 ? 0 : +pos, search.length) === search;
    };
  }
  if (!String.prototype.includes) {
    String.prototype.includes = function(search, start) {
      if (typeof start !== 'number') { start = 0; }
      if (start + search.length > this.length) { return false; }
      return this.indexOf(search, start) !== -1;
    };
  }

  function formatDuration(m, lang) {
    if (m === 0) return lang === 'ar' ? 'غير محدود' : 'Unlimited';
    var str = [];
    var d = Math.floor(m / 1440);
    m %= 1440;
    var h = Math.floor(m / 60);
    m %= 60;
    var y = Math.floor(d / 365);
    d %= 365;
    var mo = Math.floor(d / 30);
    d %= 30;

    if (lang === 'ar') {
      if(y) str.push(y + ' سنة');
      if(mo) str.push(mo + ' شهر');
      if(d) str.push(d + ' يوم');
      if(h) str.push(h + ' ساعة');
      if(m) str.push(m + ' دقيقة');
    } else {
      if(y) str.push(y + ' y');
      if(mo) str.push(mo + ' mo');
      if(d) str.push(d + ' d');
      if(h) str.push(h + ' h');
      if(m) str.push(m + ' m');
    }
    
    // Limit to max 2 components for brevity (e.g. "2 months, 5 days")
    str = str.slice(0, 2);
    
    return str.join(', ');
  }



  var dict = {
    en: {
      welcome_msg: 'SuperWiFi v5.6.1',
      tab_home: 'Home',
      tab_packages: 'Plans',
      tab_about: 'About',
      tab_contact: 'Contact',
      about_bind_title: 'Voucher Device Binding',
      about_bind_desc: 'Once activated, your voucher is bound to this device to protect your balance and prevent unauthorized access.',
      about_forget_title: 'Avoid "Forget Network"',
      about_forget_desc: 'Do not tap "Forget Network" in Wi-Fi settings to avoid changing your device MAC and losing access.',
      about_ap_title: 'Multiple Access Points',
      about_ap_desc: 'To connect to other network extenders, set Wi-Fi privacy settings to "Use Device MAC" instead of Randomized MAC.',
      about_reset_title: 'Lost Access or Changed Device',
      about_reset_desc: 'If your MAC changed or you got a new device, contact network support to reset your voucher MAC binding.',
      more_title: 'More Options',
      settings_title: 'Display & Language',
      theme_label: 'Theme Mode',
      lang_label: 'Language',
      mode_dark: 'Dark Mode',
      mode_light: 'Light Mode',
      btn_switch: 'Switch',
      history_title: 'My Previous Vouchers',
      history_sub: 'View your history on this device',
      placeholder: 'Enter Code Here',
      voucher_info: 'Once activated, this voucher will be permanently linked to your current device.',
      submit_text: 'Verify Code',
      status_connected: 'You\'re Connected!',
      connected_msg: 'You can now safely close this window.',
      speed_down: 'Download',
      speed_up: 'Upload',
      data_left: 'Data remaining',
      time_left: 'Limits',
      package_title: 'Available Plans',
      contact_title: 'Get in Touch',
      contact_wa: 'WhatsApp Support',
      contact_email: 'Email Support',
      footer_line1: 'Developed by',
      developed_by: 'Developed by',
      err_format: 'Invalid voucher format (2-32 characters).',
      err_empty: 'Please enter your voucher code.',
      err_server: 'Unexpected server response.',
      err_net: 'Network error. Please try again.',
      unlimited: 'Unlimited',
      msg_auth: 'Verifying voucher...',
      msg_setup: 'Setting up your connection...',
      copied: 'Copied!'
    },
    ar: {
      welcome_msg: 'مرحباً بك!',
      tab_home: 'الرئيسية',
      tab_packages: 'الباقات',
      tab_about: 'حول',
      tab_contact: 'التواصل',
      about_bind_title: 'ربط الجهاز بكارت النت',
      about_bind_desc: 'بمجرد كتابة وتفعيل الكارت، يتم ربطه تلقائياً بجهازك الحالي للحفاظ على رصيدك ومنع الاستخدام غير المصرح به.',
      about_forget_title: 'تجنب عمل "نسيان للشبكة"',
      about_forget_desc: 'تجنب الضغط على نسيان الشبكة من إعدادات الواي فاي لمنع تغيير عنوان MAC العشوائي وفقدان الاتصال بالكرت.',
      about_ap_title: 'الاتصال بأكثر من مقوي/أكسس',
      about_ap_desc: 'للاتصال بأكثر من نقطة وصول بنفس الكارت، قم بتغيير إعدادات الواي فاي بجهازك إلى "استخدام MAC الجهاز الأصلي".',
      about_reset_title: 'فقدان الوصول أو تغيير الجهاز',
      about_reset_desc: 'في حال قمت بتغيير هاتفك أو ظهرت مشكلة في الربط، يمكنك التواصل مع إدارة الشبكة لفك ربط الكارت وإعادة تفعيله.',
      more_title: 'المزيد من الخيارات',
      settings_title: 'إعدادات العرض واللغة',
      theme_label: 'مظهر النظام',
      lang_label: 'لغة النظام',
      mode_dark: 'الوضع الداكن',
      mode_light: 'الوضع الفاتح',
      btn_switch: 'تغيير',
      history_title: 'كروتي السابقة',
      history_sub: 'عرض الكروت التي استخدمتها على هذا الجهاز',
      placeholder: 'اكتب الكود هنا',
      voucher_info: 'بمجرد التفعيل سيتم ربط الكود بجهازك الحالي ولن يعمل على أي جهاز آخر.',
      submit_text: 'تحقق من الرقم',
      status_connected: 'أنت متصل بالإنترنت!',
      connected_msg: 'يمكنك الآن إغلاق هذه النافذة وتصفح الإنترنت بحرية.',
      speed_down: 'سرعة التحميل',
      speed_up: 'سرعة الرفع',
      data_left: 'البيانات المتبقية',
      time_left: 'المدة المتبقية',
      package_title: 'باقات الإنترنت المتاحة',
      contact_title: 'تواصل معنا',
      contact_wa: 'دعم واتساب',
      contact_email: 'البريد الإلكتروني',
      footer_line1: 'تطوير',
      developed_by: 'تطوير',
      err_format: 'تنسيق الكود غير صحيح (٢-٣٢ حرف).',
      err_empty: 'يرجى كتابة الكود أولاً.',
      err_server: 'خطأ غير متوقع من الخادم.',
      err_net: 'خطأ في الشبكة. يرجى المحاولة.',
      unlimited: 'غير محدود',
      msg_auth: 'جاري التحقق من الكود...',
      msg_setup: 'جاري تجهيز اتصالك...',
      copied: 'تم النسخ!'
    }
  };

  var apiErrors = {
    'INVALID_FORMAT': {en: 'Invalid voucher code format.', ar: 'تنسيق الكود غير صحيح'},
    'IP_UNKNOWN': {en: 'Cannot determine client IP.', ar: 'تعذر تحديد عنوان IP'},
    'MAC_UNKNOWN': {en: 'Cannot determine device MAC. Try reconnecting to Wi-Fi.', ar: 'تعذر تحديد الماك أدرس، أعد الاتصال بالشبكة'},
    'SYSTEM_ERROR': {en: 'Service unavailable. Please try again.', ar: 'الخدمة غير متاحة الآن'},
    'VOUCHER_NOT_FOUND': {en: 'Invalid code or attempts exceeded.', ar: 'كود القسيمة غير صحيح'},
    'MAC_BANNED': {en: 'Your device is blocked. Contact staff.', ar: 'جهازك محظور، تواصل مع الإدارة'},
    'SPAM_BLOCKED': {en: 'Too many failed attempts. Try again later.', ar: 'محاولات خاطئة كثيرة، حاول لاحقاً'},
    'VOUCHER_BANNED': {en: 'Account suspended. Contact staff.', ar: 'الحساب موقوف، تواصل مع الإدارة'},
    'VOUCHER_EXHAUSTED': {en: 'Voucher expired or quota exhausted.', ar: 'انتهت صلاحية الكود أو الرصيد'},
    'TIME_BLOCKED': {en: 'Access is restricted during this time.', ar: 'غير مسموح بالاتصال في هذا الوقت'},
    'MAC_MISMATCH': {en: 'Voucher already in use by another device.', ar: 'الكود مستخدم حالياً على جهاز آخر'},
    'TC_ERROR': {en: 'Failed to allocate bandwidth.', ar: 'حدث خطأ أثناء تخصيص السرعة'}
  };
  
  var msgChecking = {
    en: 'Checking auto-reconnect possibility...',
    ar: 'جاري فحص إمكانية إعادة الربط التلقائي...'
  };
  
  // -- State --
  var curLang = localStorage.getItem('swLang');
  if (!curLang) {
    var userLang = navigator.language || navigator.userLanguage || '';
    curLang = (userLang.toLowerCase().indexOf('ar') === 0) ? 'ar' : 'en';
  }
  var curTheme = localStorage.getItem('swTheme') || 'light';
  
  var iconSun = '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>';
  var iconMoon = '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>';
  
  // -- Elements --
  var htmlEl = document.documentElement;
  var themeBtn = document.getElementById('theme-toggle');
  var themeIcon = document.getElementById('theme-icon');
  var langBtn = document.getElementById('lang-toggle');
  var macDisplay = document.getElementById('mac-display');
  var clientMacIn = document.getElementById('client-mac');
  var tabs = document.querySelectorAll('.tab-btn');
  var contents = document.querySelectorAll('.tab-content');
  var packagesList = document.getElementById('packages-list');
  var form = document.getElementById('login-form');
  var voucherIn = document.getElementById('voucher');
  var submitBtn = document.getElementById('submit-btn');
  var errBox = document.getElementById('error-box');
  var errMsg = document.getElementById('error-msg');
  var infoBox = document.getElementById('info-box');
  var infoMsgEl = document.getElementById('info-msg');
  var sessionInfo = document.getElementById('session-info');
  var defaultNote = document.getElementById('default-note');
  var pkgsLoaded = false;
  
  function t(key) {
    if (dict && dict[curLang] && dict[curLang][key]) return dict[curLang][key];
    return key;
  }
  
  // -- Initialization --
  function applyTheme() {
    htmlEl.setAttribute('data-theme', curTheme);
    if(themeIcon) themeIcon.innerHTML = (curTheme === 'dark') ? iconSun : iconMoon;
    var themeSubText = document.getElementById('theme-sub-text');
    var themeBtnText = document.getElementById('theme-btn-text');
    if (themeSubText) themeSubText.textContent = (curTheme === 'dark') ? t('mode_dark') : t('mode_light');
    if (themeBtnText) themeBtnText.textContent = t('btn_switch');
    localStorage.setItem('swTheme', curTheme);
  }
  function applyLang() {
    htmlEl.setAttribute('lang', curLang);
    htmlEl.setAttribute('dir', curLang === 'ar' ? 'rtl' : 'ltr');
    var els1=document.querySelectorAll('[data-i18n]'); for(var i1=0; i1<els1.length; i1++){ var el=els1[i1];
      if(dict[curLang][el.getAttribute('data-i18n')]) {
        el.textContent = dict[curLang][el.getAttribute('data-i18n')];
      }
    }
    var els2=document.querySelectorAll('[data-i18n-ph]'); for(var i2=0; i2<els2.length; i2++){ var el=els2[i2];
      if(dict[curLang][el.getAttribute('data-i18n-ph')]) {
        el.setAttribute('placeholder', dict[curLang][el.getAttribute('data-i18n-ph')]);
      }
    }
    var langSubText = document.getElementById('lang-sub-text');
    var langBtnText = document.getElementById('lang-btn-text');
    if (langSubText) langSubText.textContent = (curLang === 'ar') ? 'العربية' : 'English';
    if (langBtnText) langBtnText.textContent = (curLang === 'ar') ? 'English' : 'العربية';
    var themeSubText = document.getElementById('theme-sub-text');
    var themeBtnText = document.getElementById('theme-btn-text');
    if (themeSubText) themeSubText.textContent = (curTheme === 'dark') ? t('mode_dark') : t('mode_light');
    if (themeBtnText) themeBtnText.textContent = t('btn_switch');
    localStorage.setItem('swLang', curLang);
    if(pkgsLoaded) loadPackages();
  }
  
  applyTheme();
  applyLang();
  
  // Auto-fetch MAC address & placeholders if not replaced properly (fallback)
  if(macDisplay && (!macDisplay.textContent || macDisplay.textContent.indexOf('%%') !== -1)) {
    macDisplay.textContent = '...';
  }
  var welcomeMsgEl = document.querySelector('.welcome-msg');
  if (welcomeMsgEl && (!welcomeMsgEl.textContent || welcomeMsgEl.textContent.indexOf('%%') !== -1)) {
    welcomeMsgEl.textContent = 'SuperWiFi v5.6.1';
  }
  var providerTitleEl = document.querySelector('.provider-title');
  if (providerTitleEl && (!providerTitleEl.textContent || providerTitleEl.textContent.indexOf('%%') !== -1)) {
    providerTitleEl.textContent = 'SuperWiFi';
  }
  
  // -- Seamless Auto-Reconnect Check --
  form.style.display = 'none'; // hide form temporarily
  showInfo(msgChecking[curLang] || msgChecking.en);
  
  var cxhr = new XMLHttpRequest();
  cxhr.open('GET', '/cgi-bin/auth.sh?action=capport', true);
  cxhr.timeout = 5000;
  cxhr.onload = function() {
    if(cxhr.status === 200) {
      try {
        var d = JSON.parse(cxhr.responseText);
        if(d.provider_name && providerTitleEl) {
          providerTitleEl.textContent = d.provider_name;
        }
        if(d['client-mac'] && macDisplay.textContent === '...') {
          macDisplay.textContent = d['client-mac'];
          clientMacIn.value = d['client-mac'];
        }
        
        if(d.captive === false) {
           infoBox.classList.remove('show');
           sessionInfo.classList.add('show');
           
           document.getElementById('si-down').textContent = formatKbps(d.rate_down_kbps||0); 
           document.getElementById('si-up').textContent = formatKbps(d.rate_up_kbps||0);
           var remBytes = d['bytes-remaining'];
           document.getElementById('si-rem').textContent = (remBytes===undefined||remBytes===null||remBytes<0) ? t('unlimited') : formatBytes(remBytes);
           
           var expiryStr = '';
           if(d.remaining_min && d.remaining_min > 0) {
             expiryStr += formatDuration(d.remaining_min, curLang);
           }
           if(expiryStr !== '') {
             document.getElementById('si-expiry-row').style.display = 'flex';
             document.getElementById('si-expiry').innerText = expiryStr;
           }
           
           if(window.location.search.indexOf('cp=1') !== -1) {
             setTimeout(function() {
               window.close();
               window.location.href = "http://connectivitycheck.gstatic.com/generate_204";
             }, 2000);
           }
           return;
        }
      } catch(e) {}
    }
    infoBox.classList.remove('show');
    updateNoteVisibility();
    form.style.display = 'block';
    if(voucherIn) voucherIn.focus();
  };
  cxhr.onerror = function() {
    infoBox.classList.remove('show');
    updateNoteVisibility();
    form.style.display = 'block';
    if(voucherIn) voucherIn.focus();
  };
  cxhr.send();
  
  // -- Event Listeners --
  document.addEventListener('click', function(e) {
    var toggleBtn = e.target.closest('#settings-toggle');
    if (toggleBtn) {
      var modal = document.getElementById('settings-modal');
      if (modal) modal.classList.add('show');
      return;
    }
    var closeBtn = e.target.closest('#close-settings');
    if (closeBtn) {
      var modal = document.getElementById('settings-modal');
      if (modal) modal.classList.remove('show');
      return;
    }
    var modalOverlay = document.getElementById('settings-modal');
    if (modalOverlay && e.target === modalOverlay) {
      modalOverlay.classList.remove('show');
      return;
    }
    var tToggle = e.target.closest('#theme-toggle');
    if (tToggle) {
      curTheme = (curTheme === 'dark') ? 'light' : 'dark';
      applyTheme();
      return;
    }
    var lToggle = e.target.closest('#lang-toggle');
    if (lToggle) {
      curLang = (curLang === 'en') ? 'ar' : 'en';
      applyLang();
      return;
    }
  });
  
  for(var _i=0; _i<tabs.length; _i++){
    (function(tab) {
      tab.addEventListener('click', function() {
        for(var _t=0; _t<tabs.length; _t++) { tabs[_t].classList.remove('active'); }
        for(var _c=0; _c<contents.length; _c++) { contents[_c].classList.remove('active'); }
        tab.classList.add('active');
        var targetId = tab.getAttribute('data-target');
        var targetEl = document.getElementById(targetId);
        if(targetEl) targetEl.classList.add('active');
        
        if(targetId === 'tab-packages' && !pkgsLoaded) {
          loadPackages();
        }
      });
    })(tabs[_i]);
  }
  
  // MAC Long Press to Copy
  var pressTimer;
  var startPress = function(e) {
    if(e.type === 'mousedown' && e.button !== 0) return;
    pressTimer = setTimeout(function() {
      var mac = macDisplay.textContent;
        if(mac && mac.indexOf('%%') < 0 && mac !== '...' && mac !== 'Unknown' && mac !== 'Error' && mac !== t('copied')) {
          var copyMsg = (document.documentElement.lang === 'ar') ? 'تم النسخ!' : 'Copied!';
          // FIX: safe clipboard write — navigator.clipboard is undefined on HTTP (captive portal)
          if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(mac).then(function() {
              macDisplay.textContent = copyMsg;
              macDisplay.style.color = 'var(--success)';
              setTimeout(function() { macDisplay.textContent = mac; macDisplay.style.color = ''; }, 1500);
            }).catch(function() {
              fallbackCopy(mac, copyMsg);
            });
          } else {
            fallbackCopy(mac, copyMsg);
            macDisplay.textContent = copyMsg;
            macDisplay.style.color = 'var(--success)';
            setTimeout(function() { macDisplay.textContent = mac; macDisplay.style.color = ''; }, 1500);
          }
      }
    }, 600);
  };
  var cancelPress = function() { clearTimeout(pressTimer); };
  
  macDisplay.addEventListener('mousedown', startPress);
  macDisplay.addEventListener('touchstart', startPress, {passive: true});
  macDisplay.addEventListener('mouseup', cancelPress);
  macDisplay.addEventListener('mouseleave', cancelPress);
  macDisplay.addEventListener('touchend', cancelPress);
  macDisplay.addEventListener('touchcancel', cancelPress);
  
  // -- Utility --
  function formatBytes(b) {
    if(b<0||!b) return t('unlimited');
    var res = '';
    if (curLang === 'ar') {
      if(b>=1073741824) res = parseFloat((b/1073741824).toFixed(2))+' جيجا';
      else if(b>=1048576) res = parseFloat((b/1048576).toFixed(1))+' ميجا';
      else if(b>=1024) res = parseFloat((b/1024).toFixed(0))+' ك.ب';
      else res = b+' بايت';
    } else {
      if(b>=1073741824) res = parseFloat((b/1073741824).toFixed(2))+' GB';
      else if(b>=1048576) res = parseFloat((b/1048576).toFixed(1))+' MB';
      else if(b>=1024) res = parseFloat((b/1024).toFixed(0))+' KB';
      else res = b+' B';
    }
    return res;
  }
  function formatKbps(k) {
    var res = '';
    if (curLang === 'ar') {
      res = k>=1024 ? parseFloat((k/1024).toFixed(1))+' ميجا' : k+' ك.ب';
    } else {
      res = k>=1024 ? parseFloat((k/1024).toFixed(1))+' Mbps' : k+' Kbps';
    }
    return res;
  }
  function updateNoteVisibility() {
    if (!defaultNote) return;
    if (errBox.classList.contains('show') || infoBox.classList.contains('show')) {
      defaultNote.style.setProperty('display', 'none', 'important');
    } else {
      defaultNote.style.setProperty('display', 'flex', 'important');
    }
  }
  function showError(msg, originalMsg){
    var finalMsg = msg;
    if(apiErrors[msg]) {
        finalMsg = apiErrors[msg][curLang] || apiErrors[msg].en || finalMsg;
    }
    if(originalMsg && (msg === 'VOUCHER_NOT_FOUND' || msg === 'SPAM_BLOCKED')) {
       var num = originalMsg.match(/\d+/);
       if(num) {
           if(curLang === 'ar' && msg === 'VOUCHER_NOT_FOUND') {
               finalMsg += ' (متبقي ' + num[0] + ' محاولات)';
           } else if(curLang === 'en' && msg === 'VOUCHER_NOT_FOUND') {
               finalMsg = 'Invalid code. ' + num[0] + ' attempts remaining.';
           } else if(curLang === 'ar' && msg === 'SPAM_BLOCKED') {
               finalMsg = 'محاولات خاطئة كثيرة، حاول بعد ' + num[0] + ' دقائق';
           } else if(curLang === 'en' && msg === 'SPAM_BLOCKED') {
               finalMsg = 'Too many failed attempts. Try again in ' + num[0] + ' minutes.';
           }
       }
    }
    errMsg.textContent = finalMsg;
    errBox.classList.add('show');
    infoBox.classList.remove('show');
    updateNoteVisibility();
  }
  function showInfo(msg){
    infoMsgEl.textContent=msg;
    infoBox.classList.add('show');
    errBox.classList.remove('show');
    updateNoteVisibility();
  }
  
  // -- Fetch Packages --
  function loadPackages() {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/cgi-bin/auth.sh?action=packages', true);
    xhr.onload = function() {
      if(xhr.status === 200) {
        try {
          var d = JSON.parse(xhr.responseText);
          if(d.status === 'ok' && d.packages) {
            pkgsLoaded = true;
            packagesList.innerHTML = '';
            if(d.packages.length === 0) {
               packagesList.innerHTML = '<div style="text-align:center;padding:20px;color:var(--text-muted)">No plans available currently.</div>';
               return;
            }
            d.packages.forEach(function(p) {
              var pdiv = document.createElement('div');
              pdiv.className = 'pkg-card';
              var priceStr = (p.price_sell_cent > 0) ? (p.price_sell_cent / 100).toFixed(2) + (curLang==='ar'?' ج.م':' EGP') : (curLang==='ar'?'مجاناً':'Free');
              var dataStr = formatBytes(p.data_limit_bytes);
              var tHTML = '<div class="pkg-spec"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg> <span>'+formatDuration(p.duration_min, curLang)+'</span></div>';
              pdiv.innerHTML = '<div class="pkg-header"><div class="pkg-name">'+p.name+'</div></div><div class="pkg-specs"><div class="pkg-spec" style="color:var(--success)"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--success)"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg> <span style="font-weight:700">'+priceStr+'</span></div><div class="pkg-spec"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg> <span>'+formatKbps(p.rate_down_kbps)+'</span></div>'+tHTML+'<div class="pkg-spec"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg> <span>'+dataStr+'</span></div></div>';
              packagesList.appendChild(pdiv);
            });
          }
        } catch(e) {}
      }
    };
    xhr.send();
  }

  // -- Fetch History --
  var btnHistory = document.getElementById('btn-history');
  var historyModal = document.getElementById('history-modal');
  var historyList = document.getElementById('history-list');

  function closeHistoryModal() {
    if(historyModal) {
      historyModal.classList.remove('show');
      document.body.classList.remove('no-scroll');
    }
  }
  
  if(btnHistory) {
    btnHistory.addEventListener('click', function() {
      historyModal.classList.add('show');
      document.body.classList.add('no-scroll');
      historyList.innerHTML = '<div style="text-align:center;padding:20px;"><div class="spinner dark"></div></div>';

      var xhr = new XMLHttpRequest();
      xhr.open('GET', '/cgi-bin/history.sh', true);
      xhr.onload = function() {
        if(xhr.status === 200) {
          try {
            var d = JSON.parse(xhr.responseText);
            if(d.status === 'success' && d.vouchers) {
              historyList.innerHTML = '';
              if(d.vouchers.length === 0) {
                historyList.innerHTML = '<div style="text-align:center;color:var(--text-muted);padding:20px;">' + (curLang==='ar'?'لا يوجد كروت سابقة':'No previous vouchers.') + '</div>';
                return;
              }
              d.vouchers.forEach(function(v) {
                var vdiv = document.createElement('div');
                vdiv.className = 'hist-card';
                var isAct = (v.status === 'Active');
                var statusClass = isAct ? 'hist-status active' : 'hist-status expired';
                var statusText = isAct ? (curLang==='ar'?'نشط':'Active') : (curLang==='ar'?'منتهي':'Expired');
                
                var usedHtml = '<span style="color:var(--error);font-weight:700;">' + formatBytes(v.used_kb * 1024) + '</span>';
                var limitHtml = '<span style="color:var(--success);font-weight:700;">' + (v.limit_kb > 0 ? formatBytes(v.limit_kb * 1024) : t('unlimited')) + '</span>';
                var quotaHtml = usedHtml + '<span style="opacity:0.5;margin:0 4px;">/</span>' + limitHtml;
                
                var durText = formatDuration(v.duration_min, curLang);
                var priceText = (v.price_cent > 0) ? (v.price_cent / 100).toFixed(2) + (curLang==='ar'?' ج.م':' EGP') : (curLang==='ar'?'مجاني':'Free');

                vdiv.innerHTML = 
                  '<div class="hist-header">' +
                    '<div class="hist-code">' + v.voucher + '</div>' +
                    '<div class="' + statusClass + '">' + statusText + '</div>' +
                  '</div>' +
                  '<div class="hist-chips">' +
                    '<div class="chip-tag primary">' +
                      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>' +
                      priceText +
                    '</div>' +
                    '<div class="chip-tag">' +
                      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>' +
                      quotaHtml +
                    '</div>' +
                    '<div class="chip-tag"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><span>' + durText + '</span></div>' +
                  '</div>';

                historyList.appendChild(vdiv);
              });
            } else {
              historyList.innerHTML = '<div style="color:var(--error);padding:20px;text-align:center;">Error loading history.</div>';
            }
          } catch(e) {
            historyList.innerHTML = '<div style="color:var(--error);padding:20px;text-align:center;">Parse error.</div>';
          }
        }
      };
      xhr.send();
    });
  }
  
  var closeHist = document.getElementById('close-history');
  if(closeHist) closeHist.addEventListener('click', closeHistoryModal);
  if(historyModal) {
    historyModal.addEventListener('click', function(e) {
      if(e.target === historyModal) closeHistoryModal();
    });
  }
  
  // -- Utility --
  function convertArabicNumerals(str) {
    var arabicNumbers = [/٠/g, /١/g, /٢/g, /٣/g, /٤/g, /٥/g, /٦/g, /٧/g, /٨/g, /٩/g];
    for (var i = 0; i < 10; i++) {
      str = str.replace(arabicNumbers[i], i);
    }
    return str;
  }

  if (voucherIn) {
    voucherIn.addEventListener('input', function() {
      this.value = convertArabicNumerals(this.value);
    });
  }

  // -- Form Submission --
  form.addEventListener('submit', function(e){
    e.preventDefault();
    errBox.classList.remove('show'); infoBox.classList.remove('show');
    updateNoteVisibility();
    var voucher = convertArabicNumerals(voucherIn.value.trim());
    if(!voucher){ showError(t('err_empty')); voucherIn.focus(); return; }
    if(!/^[A-Za-z0-9_-]{2,32}$/.test(voucher)){ showError(t('err_format')); voucherIn.focus(); return; }
    
    submitBtn.disabled = true; 
    submitBtn.innerHTML = '<span class="spinner"></span> ' + t('msg_auth');
    showInfo(t('msg_auth'));
    
    var body = 'voucher=' + encodeURIComponent(voucher);
    var cMac = document.getElementById('client-mac').value;
    if(cMac && cMac !== '' && cMac.indexOf('%%') < 0) body += '&mac=' + encodeURIComponent(cMac);
    
    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/cgi-bin/auth.sh', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.timeout = 10000;
    xhr.onload = function(){
      var data;
      try { data = JSON.parse(xhr.responseText); } catch(err) {
        showError(t('err_server'));
        submitBtn.disabled = false; submitBtn.innerHTML = t('submit_text');
        return;
      }
      if(data.status === 'ok') {
        errBox.classList.remove('show'); infoBox.classList.remove('show');
        form.style.display = 'none';
        sessionInfo.classList.add('show');
        
        document.getElementById('si-down').textContent = formatKbps(data.rate_down_kbps||0);
        document.getElementById('si-up').textContent = formatKbps(data.rate_up_kbps||0);
        var remBytes = data.remaining_bytes;
        document.getElementById('si-rem').textContent = (remBytes===undefined||remBytes===null||remBytes<0) ? t('unlimited') : formatBytes(remBytes);
        
        var expiryStr = '';
        if(data.remaining_min && data.remaining_min > 0) {
          expiryStr += formatDuration(data.remaining_min, curLang);
        }
        if(expiryStr !== '') {
          document.getElementById('si-expiry-row').style.display = 'flex';
          document.getElementById('si-expiry').innerText = expiryStr;
        }
        
        // Force captive portal to close after 2 seconds
        setTimeout(function() {
          window.close();
          window.location.href = "http://connectivitycheck.gstatic.com/generate_204";
        }, 2000);
      } else {
        showError(data.error_code || data.message || t('err_server'), data.message);
        submitBtn.disabled = false; submitBtn.innerHTML = t('submit_text');
      }
    };
    xhr.onerror = function(){ showError(t('err_net')); submitBtn.disabled = false; submitBtn.innerHTML = t('submit_text'); };
    xhr.ontimeout = xhr.onerror;
    xhr.send(body);
  });
})();

function copyMac() {
  var mac = document.getElementById('mac-display').innerText;
  var msg = document.documentElement.lang === 'ar' ? 'تم نسخ الماك بنجاح!' : 'MAC Address Copied!';
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(mac).then(function() { alert(msg); }).catch(function() { fallbackCopy(mac, msg); });
  } else {
    fallbackCopy(mac, msg);
  }
}

function fallbackCopy(text, msg) {
  var textArea = document.createElement("textarea");
  textArea.value = text;
  textArea.style.position = "fixed";
  textArea.style.left = "-9999px";
  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();
  try {
    document.execCommand('copy');
    alert(msg);
  } catch (err) {
    console.error('Fallback copy failed', err);
  }
  document.body.removeChild(textArea);
}
