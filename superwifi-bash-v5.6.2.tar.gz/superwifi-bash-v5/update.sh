#!/bin/sh
# SuperWiFi Automated Update Script (v5)
# This script safely updates core scripts and UI files without modifying the database or config.

INSTALL_BASE="${INSTALL_BASE:-https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/SuperWiFi/main/src}"

set -e

echo "======================================================"
echo "    SuperWiFi Safe Update Wizard (v5)"
echo "======================================================"
echo ""

echo "[1/4] Stopping services temporarily..."
/etc/init.d/superwifi stop 2>/dev/null || true
echo "Services stopped."

echo ""
echo "[2/4] Updating system & UI files..."

download() {
  local remote_path="$1"
  local local_path="$2"
  echo "   -> $(basename "$local_path")..."
  if ! curl -sSLf "$INSTALL_BASE/$remote_path" -o "$local_path"; then
      echo "      curl failed, trying wget..."
      if ! wget -qO "$local_path" "$INSTALL_BASE/$remote_path"; then
          echo "      Failed to download $remote_path"
          exit 1
      fi
  fi
}

echo "Update source:"
echo "1) Local (Use files from the 'src' directory next to this script)"
echo "2) Internet (Download from GitHub)"
read -p "Choose source [1/2, default 1]: " install_source
install_source=${install_source:-1}

if [ "$install_source" = "1" ]; then
    if [ -d "./src" ]; then
        echo "Using local files from ./src"
        # Only copy scripts, html, css, js. DO NOT overwrite /etc/config/superwifi
        cp -r ./src/usr/* /usr/ 2>/dev/null || true
        cp -r ./src/www/* /www/ 2>/dev/null || true
        cp -r ./src/etc/init.d/* /etc/init.d/ 2>/dev/null || true
        cp -r ./src/etc/superwifi/schema.sql /etc/superwifi/schema.sql 2>/dev/null || true
    elif [ -d "$(dirname "$0")/src" ]; then
        echo "Using local files from $(dirname "$0")/src"
        cp -r "$(dirname "$0")/src/usr/"* /usr/ 2>/dev/null || true
        cp -r "$(dirname "$0")/src/www/"* /www/ 2>/dev/null || true
        cp -r "$(dirname "$0")/src/etc/init.d/"* /etc/init.d/ 2>/dev/null || true
        cp -r "$(dirname "$0")/src/etc/superwifi/schema.sql" /etc/superwifi/schema.sql 2>/dev/null || true
    else
        echo "Warning: ./src directory not found. Cannot proceed with local update."
        exit 1
    fi
else
    echo "Downloading updated files from internet..."
    
    # Core Scripts
    download "usr/lib/superwifi/core.sh"        "/usr/lib/superwifi/core.sh"
    download "usr/lib/superwifi/db.sh"           "/usr/lib/superwifi/db.sh"
    download "usr/lib/superwifi/db-queries.sh"   "/usr/lib/superwifi/db-queries.sh"
    download "usr/lib/superwifi/fw.sh"           "/usr/lib/superwifi/fw.sh"
    download "usr/lib/superwifi/tc.sh"           "/usr/lib/superwifi/tc.sh"
    download "usr/lib/superwifi/fw-restore.sh"   "/usr/lib/superwifi/fw-restore.sh"
    download "usr/lib/superwifi/sw-sentinel.sh"  "/usr/lib/superwifi/sw-sentinel.sh"

    # Binaries/Daemons
    download "usr/sbin/sw"                       "/usr/sbin/sw"
    download "usr/sbin/sw-acct.sh"               "/usr/sbin/sw-acct.sh"
    download "usr/sbin/sw-sync.sh"               "/usr/sbin/sw-sync.sh"

    # UI & API
    download "www/cgi-bin/auth.sh"               "/www/cgi-bin/auth.sh"
    download "www/cgi-bin/history.sh"            "/www/cgi-bin/history.sh"
    download "www/cgi-bin/capport-api.sh"        "/www/cgi-bin/capport-api.sh"
    download "www/cgi-bin/redirect.sh"           "/www/cgi-bin/redirect.sh"
    download "www/cgi-bin/luci"                  "/www/cgi-bin/luci"
    download "www/index.html"                    "/www/index.html"
    download "www/index.cgi"                     "/www/index.cgi"
    download "www/superwifi/login.html"          "/www/superwifi/login.html"
    download "www/superwifi/css/style.css"       "/www/superwifi/css/style.css"
    download "www/superwifi/js/main.js"          "/www/superwifi/js/main.js"

    # Ensure schema is updated (safe)
    download "etc/superwifi/schema.sql"          "/etc/superwifi/schema.sql"
    download "etc/init.d/superwifi"              "/etc/init.d/superwifi"
    download "etc/superwifi-version"             "/etc/superwifi-version"
fi

echo "Setting executable permissions..."
chmod +x /usr/lib/superwifi/*.sh
chmod +x /usr/sbin/sw /usr/sbin/sw-acct.sh /usr/sbin/sw-sync.sh
chmod +x /www/cgi-bin/*.sh /www/index.cgi
chmod +x /etc/init.d/superwifi
chmod +x /usr/lib/superwifi/fw-restore.sh

echo ""
echo "[3/4] Applying Schema Updates (if any)..."
DB_PATH=$(uci get superwifi.core.db_path 2>/dev/null || echo "/tmp/superwifi/superwifi.db")
if [ -f "$DB_PATH" ] && [ -f "/etc/superwifi/schema.sql" ]; then
    # This safely applies any new CREATE TABLE IF NOT EXISTS statements
    sqlite3 "$DB_PATH" < /etc/superwifi/schema.sql
    echo "Database schema checked/updated."
fi

echo ""
echo "[4/4] Restarting SuperWiFi..."
/etc/init.d/superwifi enable
/etc/init.d/superwifi start

echo "======================================================"
echo " UPDATE COMPLETE! "
echo " Configuration and Database were preserved."
echo "======================================================"
