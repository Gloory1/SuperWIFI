#!/bin/sh
# SuperWiFi Automated Installation Script — OpenWrt edition (v5)
# Developed by Saeed Muhammad

INSTALL_BASE="${INSTALL_BASE:-https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/SuperWiFi/main/src}"
REQUIRED_PKGS="sqlite3-cli jq nftables tc-tiny curl coreutils-timeout coreutils-sha256sum"

set -e

echo "======================================================"
echo "    SuperWiFi Installation Wizard (v5)"
echo "======================================================"
echo ""

echo "[1/8] Pre-flight checks..."
if ! ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1; then
  echo "Error: No network connection."
  exit 1
fi

PKG_MGR=""
if command -v opkg >/dev/null 2>&1; then
    PKG_MGR="opkg"
elif command -v apk >/dev/null 2>&1; then
    PKG_MGR="apk"
else
    echo "Error: Neither opkg nor apk package manager found."
    exit 1
fi
echo "Package manager: $PKG_MGR"
echo "OK"

echo ""
echo "[2/8] Installing required packages..."
if [ "$PKG_MGR" = "opkg" ]; then
    opkg update >/dev/null 2>&1 || true
    for pkg in $REQUIRED_PKGS; do
        opkg install "$pkg" >/dev/null 2>&1 || echo "  Warning: $pkg may not be available"
    done
elif [ "$PKG_MGR" = "apk" ]; then
    apk update >/dev/null 2>&1 || true
    for pkg in $REQUIRED_PKGS; do
        apk add "$pkg" >/dev/null 2>&1 || echo "  Warning: $pkg may not be available"
    done
fi

if ! command -v sqlite3 >/dev/null 2>&1; then
  echo "Error: sqlite3 failed to install."
  exit 1
fi
echo "Packages OK"

echo ""
echo "[3/8] Cleaning previous installation..."
/etc/init.d/superwifi stop 2>/dev/null || true
rm -f /etc/fw4.d/99-superwifi.sh 2>/dev/null || true
rm -f /www/cgi-bin/test_*.sh 2>/dev/null || true
rm -f /usr/sbin/sw-acct_temp.sh 2>/dev/null || true
echo "Cleanup OK"

echo ""
echo "[4/8] Preparing directories..."
mkdir -p /usr/lib/superwifi
mkdir -p /usr/sbin
mkdir -p /www/cgi-bin
mkdir -p /www/superwifi/css
mkdir -p /www/superwifi/js
mkdir -p /www/superwifi/fonts
mkdir -p /etc/superwifi
mkdir -p /etc/config
mkdir -p /etc/init.d
mkdir -p /etc/dnsmasq.d
mkdir -p /tmp/superwifi
echo "Directories ready."

echo ""
echo "[5/8] System files deployment..."

download() {
  local remote_path="$1"
  local local_path="$2"
  echo "   -> $(basename "$local_path")..."
  if ! curl -sSLf "$INSTALL_BASE/$remote_path" -o "$local_path"; then
      echo "      curl failed, trying wget..."
      if ! wget -qO "$local_path" "$INSTALL_BASE/$remote_path"; then
          echo "      Failed to download $remote_path"
          exit 1
      fi
  fi
}

echo "Installation source:"
echo "1) Local (Use files from the 'src' directory next to this script)"
echo "2) Internet (Download from GitHub)"
read -p "Choose source [1/2, default 1]: " install_source
install_source=${install_source:-1}

if [ "$install_source" = "1" ]; then
    if [ -d "./src" ]; then
        echo "Using local files from ./src"
        cp -r ./src/* /
    elif [ -d "$(dirname "$0")/src" ]; then
        echo "Using local files from $(dirname "$0")/src"
        cp -r "$(dirname "$0")/src/"* /
    else
        echo "Warning: ./src directory not found. Assuming files are already synced to /"
    fi
else
    echo "Downloading files from internet..."
    download "usr/lib/superwifi/core.sh"        "/usr/lib/superwifi/core.sh"
    download "usr/lib/superwifi/db.sh"           "/usr/lib/superwifi/db.sh"
    download "usr/lib/superwifi/db-queries.sh"   "/usr/lib/superwifi/db-queries.sh"
    download "usr/lib/superwifi/fw.sh"           "/usr/lib/superwifi/fw.sh"
    download "usr/lib/superwifi/tc.sh"           "/usr/lib/superwifi/tc.sh"
    download "usr/lib/superwifi/fw-restore.sh"   "/usr/lib/superwifi/fw-restore.sh"
    download "usr/lib/superwifi/sw-sentinel.sh"  "/usr/lib/superwifi/sw-sentinel.sh"

    download "usr/sbin/sw"                       "/usr/sbin/sw"
    download "usr/sbin/sw-acct.sh"               "/usr/sbin/sw-acct.sh"
    download "usr/sbin/sw-sync.sh"               "/usr/sbin/sw-sync.sh"

    download "www/cgi-bin/auth.sh"               "/www/cgi-bin/auth.sh"
    download "www/cgi-bin/history.sh"            "/www/cgi-bin/history.sh"
    download "www/cgi-bin/capport-api.sh"        "/www/cgi-bin/capport-api.sh"
    download "www/cgi-bin/redirect.sh"           "/www/cgi-bin/redirect.sh"
    download "www/cgi-bin/luci"                  "/www/cgi-bin/luci"
    download "www/index.html"                    "/www/index.html"
    download "www/index.cgi"                     "/www/index.cgi"
    download "www/superwifi/login.html"          "/www/superwifi/login.html"
    download "www/superwifi/css/style.css"       "/www/superwifi/css/style.css"
    download "www/superwifi/js/main.js"          "/www/superwifi/js/main.js"

    # Fonts
    for font in inter-400 inter-500 inter-600 inter-700 inter-800 noto-arabic-400 noto-arabic-500 noto-arabic-600 noto-arabic-700 noto-arabic-800; do
        download "www/superwifi/fonts/${font}.ttf" "/www/superwifi/fonts/${font}.ttf"
    done

    download "etc/config/superwifi"              "/etc/config/superwifi"
    download "etc/init.d/superwifi"              "/etc/init.d/superwifi"
    download "etc/dnsmasq.d/superwifi.conf"      "/etc/dnsmasq.d/superwifi.conf"
    download "etc/superwifi/superwifi.nft.tpl"   "/etc/superwifi/superwifi.nft.tpl"
    download "etc/superwifi/schema.sql"          "/etc/superwifi/schema.sql"
    download "etc/superwifi/config-guide.txt"    "/etc/superwifi/config-guide.txt"
    download "etc/superwifi-version"             "/etc/superwifi-version"
fi


echo "Setting executable permissions..."
chmod +x /usr/lib/superwifi/*.sh
chmod +x /usr/sbin/sw /usr/sbin/sw-acct.sh /usr/sbin/sw-sync.sh
chmod +x /www/cgi-bin/* /www/index.cgi
chmod +x /etc/init.d/superwifi
chmod +x /usr/lib/superwifi/fw-restore.sh

echo ""
echo ""
echo "[5.5/8] Auto-detecting LAN IP..."
LAN_IP=$(uci get network.lan.ipaddr 2>/dev/null || echo "10.0.0.1")
echo "Detected LAN IP: $LAN_IP"
sed -i "s/10.0.0.1/$LAN_IP/g" /etc/config/superwifi
sed -i "s/10.0.0.1/$LAN_IP/g" /etc/dnsmasq.d/superwifi.conf
echo "[6/8] Configuring..."

# Configure Cloud Sync
echo "--- Cloud Sync & Security Settings ---"
read -p "Enable Cloud Sync (Supabase)? [y/N]: " enable_sync_ans
if [ "$enable_sync_ans" = "y" ] || [ "$enable_sync_ans" = "Y" ]; then
    uci set superwifi.core.enable_sync='1'
    read -p "Supabase URL: " supabase_url
    uci set superwifi.credentials.supabase_url="$supabase_url"
    read -p "Supabase API Key: " supabase_key
    uci set superwifi.credentials.supabase_key="$supabase_key"
    read -p "Gateway ID: " gateway_id
    uci set superwifi.gateway.gateway_id="$gateway_id"
    read -s -p "Gateway Password: " gateway_pw
    echo
    uci set superwifi.gateway.gateway_password="$gateway_pw"
    read -p "Sync interval (minutes, default 5): " sync_int
    [ -n "$sync_int" ] && uci set superwifi.core.sync_interval="$sync_int"
else
    uci set superwifi.core.enable_sync='0'
fi
echo

# Auto-detect SSH client MAC for Bypass
echo "--- Bypass MAC Addresses ---"
SSH_IP=$(echo "$SSH_CONNECTION" | awk '{print $1}')
MY_MAC=""
if [ -n "$SSH_IP" ]; then
    MY_MAC=$(cat /proc/net/arp 2>/dev/null | grep "^$SSH_IP " | awk '{print $4}')
fi

bypass_macs=""
if [ -n "$MY_MAC" ] && printf '%s' "$MY_MAC" | grep -qiE '^([0-9a-f]{2}:){5}[0-9a-f]{2}$'; then
    read -p "Add your current device's MAC ($MY_MAC) to bypass the portal? [y/N]: " bypass_ans
    if [ "$bypass_ans" = "y" ] || [ "$bypass_ans" = "Y" ]; then
        bypass_macs="$MY_MAC"
        echo "Added: $MY_MAC"
    fi
else
    echo "Could not auto-detect your device's MAC address via SSH connection."
fi

if [ -n "$bypass_macs" ]; then
    # Clear existing list
    uci delete superwifi.bypass.mac 2>/dev/null || true
    for mac in $bypass_macs; do
        uci add_list superwifi.bypass.mac="$mac"
    done
fi
uci commit superwifi

# Configure fw-restore include
echo "Configuring firewall include..."
# Remove old references first
i=0
while uci get firewall.@include[$i] >/dev/null 2>&1; do
    if [ "$(uci get firewall.@include[$i].path 2>/dev/null)" = "/usr/lib/superwifi/fw-restore.sh" ]; then
        uci delete firewall.@include[$i]
    else
        i=$((i + 1))
    fi
done
# Add new reference
FW_INCLUDE=$(uci add firewall include)
uci set firewall.${FW_INCLUDE}.type='script'
uci set firewall.${FW_INCLUDE}.path='/usr/lib/superwifi/fw-restore.sh'
uci commit firewall

# Configure uhttpd
echo "Configuring uhttpd for captive portal..."
if ! uci get uhttpd.main.lua_prefix 2>/dev/null | grep -q '/api/capport'; then
    uci add_list uhttpd.main.lua_prefix='/api/capport=/www/cgi-bin/capport-api.sh'
fi
uci set uhttpd.main.error_page='/cgi-bin/redirect.sh'
uci set uhttpd.main.max_requests='100'
uci commit uhttpd
/etc/init.d/uhttpd restart 2>/dev/null || true

# Disable flow offloading (required for nftables counters)
uci set firewall.@defaults[0].flow_offloading='0'
uci commit firewall

echo ""
echo "[7/8] Initializing Database..."
DB_PATH=$(uci get superwifi.core.db_path 2>/dev/null || echo "/tmp/superwifi/superwifi.db")
if [ ! -f "$DB_PATH" ]; then
    echo "Creating new database..."
    sqlite3 "$DB_PATH" < /etc/superwifi/schema.sql
    echo "Database initialized."
else
    echo "Database already exists. Applying schema updates..."
    sqlite3 "$DB_PATH" < /etc/superwifi/schema.sql
fi

# Cron setup for cloud sync
CRON_FILE="/etc/crontabs/root"
[ ! -f "$CRON_FILE" ] && touch "$CRON_FILE"
sed -i '/sw-sync.sh/d' "$CRON_FILE"
SYNC_INT=$(uci get superwifi.core.sync_interval 2>/dev/null || echo 5)
echo "*/$SYNC_INT * * * * /usr/sbin/sw-sync.sh >/dev/null 2>&1" >> "$CRON_FILE"
/etc/init.d/cron restart || true

echo ""
echo "[8/8] Activating SuperWiFi..."
fw4 reload || true
/etc/init.d/dnsmasq restart || true
/etc/init.d/superwifi enable
/etc/init.d/superwifi start

echo "======================================================"
echo " INSTALLATION COMPLETE! (v5)"
echo "======================================================"
echo " Service Status:"
/etc/init.d/superwifi status || echo "  Failed to check status"
echo ""
echo " Bypass MACs:"
uci get superwifi.bypass.mac 2>/dev/null || echo "  None"
echo ""
echo " Portal URL: $(uci get superwifi.core.portal_url 2>/dev/null)"
echo "======================================================"
