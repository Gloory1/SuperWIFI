#!/bin/sh
# SuperWiFi Automated Custom Installation Script for Saeed
# This script installs SuperWiFi with pre-configured values to avoid manual entry.

INSTALL_BASE="${INSTALL_BASE:-https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/SuperWiFi/main/src}"
REQUIRED_PKGS="sqlite3-cli jq nftables tc-tiny curl coreutils-timeout coreutils-sha256sum"

set -e

echo "======================================================"
echo "    SuperWiFi Custom Installation Wizard for Saeed"
echo "======================================================"
echo ""

echo "[1/8] Pre-flight checks..."
if ! ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1; then
  echo "Error: No network connection."
  exit 1
fi

PKG_MGR=""
if command -v opkg >/dev/null 2>&1; then
    PKG_MGR="opkg"
elif command -v apk >/dev/null 2>&1; then
    PKG_MGR="apk"
else
    echo "Error: Neither opkg nor apk package manager found."
    exit 1
fi
echo "Package manager: $PKG_MGR"
echo "OK"

echo ""
echo "[2/8] Installing required packages..."
if [ "$PKG_MGR" = "opkg" ]; then
    opkg update >/dev/null 2>&1 || true
    for pkg in $REQUIRED_PKGS; do
        opkg install "$pkg" >/dev/null 2>&1 || echo "  Warning: $pkg may not be available"
    done
elif [ "$PKG_MGR" = "apk" ]; then
    apk update >/dev/null 2>&1 || true
    for pkg in $REQUIRED_PKGS; do
        apk add "$pkg" >/dev/null 2>&1 || echo "  Warning: $pkg may not be available"
    done
fi

if ! command -v sqlite3 >/dev/null 2>&1; then
  echo "Error: sqlite3 failed to install."
  exit 1
fi
echo "Packages OK"

echo ""
echo "[3/8] Cleaning previous installation..."
/etc/init.d/superwifi stop 2>/dev/null || true
rm -f /etc/fw4.d/99-superwifi.sh 2>/dev/null || true
rm -f /www/cgi-bin/test_*.sh 2>/dev/null || true
rm -f /usr/sbin/sw-acct_temp.sh 2>/dev/null || true
echo "Cleanup OK"

echo ""
echo "[4/8] Preparing directories..."
mkdir -p /usr/lib/superwifi
mkdir -p /usr/sbin
mkdir -p /www/cgi-bin
mkdir -p /www/superwifi/css
mkdir -p /www/superwifi/js
mkdir -p /www/superwifi/fonts
mkdir -p /etc/superwifi
mkdir -p /etc/config
mkdir -p /etc/init.d
mkdir -p /etc/dnsmasq.d
mkdir -p /tmp/superwifi
echo "Directories ready."

echo ""
echo "[5/8] System files deployment..."

# Always use local src since we are scp-ing the files
echo "Using local files from ./src"
cp -r ./src/* /

echo "Setting executable permissions..."
chmod +x /usr/lib/superwifi/*.sh
chmod +x /usr/sbin/sw /usr/sbin/sw-acct.sh /usr/sbin/sw-sync.sh
chmod +x /www/cgi-bin/* /www/index.cgi
chmod +x /etc/init.d/superwifi
chmod +x /usr/lib/superwifi/fw-restore.sh

echo ""
echo ""
echo "[5.5/8] Auto-detecting LAN IP..."
LAN_IP=$(uci get network.lan.ipaddr 2>/dev/null | cut -d/ -f1 || echo "10.0.0.1")
echo "Detected LAN IP: $LAN_IP"
sed -i "s|10.0.0.1|$LAN_IP|g" /etc/config/superwifi
sed -i "s|10.0.0.1|$LAN_IP|g" /etc/dnsmasq.d/superwifi.conf
echo "[6/8] Configuring..."

# Pre-configured Cloud Sync Settings
echo "--- Applying Pre-configured Settings ---"
uci set superwifi.core.enable_sync='1'
uci set superwifi.credentials.supabase_url='https://bxtjyytedvcavbyjuhag.supabase.co'
uci set superwifi.credentials.supabase_key='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ4dGp5eXRlZHZjYXZieWp1aGFnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODI3NTYwMTgsImV4cCI6MjA5ODMzMjAxOH0.VoB5SfelYEuk1l6VT6hizTqQM7BECjqUV1CW-R6Apik'
uci set superwifi.gateway.gateway_id='7UM4YDPL'
uci set superwifi.gateway.gateway_password='618491'
uci set superwifi.core.sync_interval='5'

# Auto-detect SSH client MAC for Bypass
echo "--- Bypass MAC Addresses ---"
# Add Saeed's hardcoded MAC address automatically
MY_MAC="d8:43:ae:3d:1a:ee"

bypass_macs="$MY_MAC"
echo "Added Saeed's MAC: $MY_MAC"

if [ -n "$bypass_macs" ]; then
    # Clear existing list
    uci delete superwifi.bypass.mac 2>/dev/null || true
    for mac in $bypass_macs; do
        uci add_list superwifi.bypass.mac="$mac"
    done
fi
uci commit superwifi

# Configure fw-restore include
echo "Configuring firewall include..."
i=0
while uci get firewall.@include[$i] >/dev/null 2>&1; do
    if [ "$(uci get firewall.@include[$i].path 2>/dev/null)" = "/usr/lib/superwifi/fw-restore.sh" ]; then
        uci delete firewall.@include[$i]
    else
        i=$((i + 1))
    fi
done
FW_INCLUDE=$(uci add firewall include)
uci set firewall.${FW_INCLUDE}.type='script'
uci set firewall.${FW_INCLUDE}.path='/usr/lib/superwifi/fw-restore.sh'
uci commit firewall

# Configure uhttpd
echo "Configuring uhttpd for captive portal..."
if ! uci get uhttpd.main.lua_prefix 2>/dev/null | grep -q '/api/capport'; then
    uci add_list uhttpd.main.lua_prefix='/api/capport=/www/cgi-bin/capport-api.sh'
fi
uci set uhttpd.main.error_page='/cgi-bin/redirect.sh'
uci set uhttpd.main.max_requests='100'
uci commit uhttpd
/etc/init.d/uhttpd restart 2>/dev/null || true

uci set firewall.@defaults[0].flow_offloading='0'
uci commit firewall

echo ""
echo "[7/8] Initializing Database..."
DB_PATH=$(uci get superwifi.core.db_path 2>/dev/null || echo "/tmp/superwifi/superwifi.db")
if [ ! -f "$DB_PATH" ]; then
    echo "Creating new database..."
    sqlite3 "$DB_PATH" < /etc/superwifi/schema.sql
    echo "Database initialized."
else
    echo "Database already exists. Applying schema updates..."
    sqlite3 "$DB_PATH" < /etc/superwifi/schema.sql
fi

# Cron setup for cloud sync
CRON_FILE="/etc/crontabs/root"
[ ! -f "$CRON_FILE" ] && touch "$CRON_FILE"
sed -i '/sw-sync.sh/d' "$CRON_FILE"
SYNC_INT=$(uci get superwifi.core.sync_interval 2>/dev/null || echo 5)
echo "*/$SYNC_INT * * * * /usr/sbin/sw-sync.sh >/dev/null 2>&1" >> "$CRON_FILE"
/etc/init.d/cron restart || true

echo ""
echo "[8/8] Activating SuperWiFi..."
fw4 reload || true
/etc/init.d/dnsmasq restart || true
/etc/init.d/superwifi enable
/etc/init.d/superwifi start

echo "======================================================"
echo " CUSTOM INSTALLATION COMPLETE! (Saeed Version)"
echo "======================================================"
echo " Service Status:"
/etc/init.d/superwifi status || echo "  Failed to check status"
echo ""
echo " Bypass MACs:"
uci get superwifi.bypass.mac 2>/dev/null || echo "  None"
echo ""
echo " Portal URL: $(uci get superwifi.core.portal_url 2>/dev/null)"
echo "======================================================"
