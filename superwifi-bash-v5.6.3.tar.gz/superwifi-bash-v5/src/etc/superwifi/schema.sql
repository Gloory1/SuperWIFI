-- =============================================================================
-- SuperWiFi v5 — Database Schema
-- Engine:   SQLite 3.39+ (OpenWrt 23.x+)
-- Mode:     WAL (set at connection time, not here)
-- Encoding: UTF-8
-- =============================================================================
--
-- DESIGN PRINCIPLES:
--   1. Hot-path isolation: The 'session' table is the only table touched every
--      60 seconds by the accounting daemon. It is self-contained — no JOINs
--      needed for the write path. Rates and limits are denormalized at punch
--      time from the voucher table.
--   2. Integer timestamps: All timestamps are Unix epoch seconds (INTEGER).
--      This saves ~15 bytes/row vs TEXT datetime, enables pure integer
--      arithmetic (no datetime() parsing), and is native to shell (date +%s).
--   3. Flash-wear minimization: Narrow hot rows, INTEGER types everywhere,
--      WAL mode (sequential appends), and manual checkpoint control.
--   4. Lock contention elimination: Session updates use a single batched
--      transaction. Class ID allocation uses BEGIN IMMEDIATE with gap-finding.
--      Rate limiting uses INSERT OR REPLACE (one row per MAC, no table growth).
--
-- NAMING CONVENTIONS:
--   Tables:    Singular nouns (package, voucher, session)
--   PKs:       'id' on surrogate keys, natural key name on natural keys
--   FKs:       <referenced_table>_<referenced_column> (e.g. voucher_code)
--   Booleans:  Avoided — use TEXT status enums or 0/non-0 semantics
--   Timestamps: *_at suffix, always INTEGER epoch seconds
--   Byte counts: *_bytes suffix, always INTEGER
--   Rates:     *_kbps suffix, always INTEGER
-- =============================================================================


-- =============================================================================
-- 1. SYSTEM CONFIGURATION
-- =============================================================================
CREATE TABLE IF NOT EXISTS system_config (
    key             TEXT PRIMARY KEY,
    value           TEXT NOT NULL,
    updated_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);

INSERT OR IGNORE INTO system_config (key, value) VALUES ('firmware_version', '5.6.3');

-- =============================================================================
-- 2. PACKAGE — Plan Templates (Cold Data)
--    Written rarely (admin creates/edits plans). Read on voucher generation
--    and for the portal packages API.
-- =============================================================================
CREATE TABLE IF NOT EXISTS package (
    id              INTEGER PRIMARY KEY,                -- AUTOINCREMENT omitted: saves B-tree overhead, rowid reuse is fine
    name            TEXT    NOT NULL UNIQUE,
    rate_down_kbps  INTEGER NOT NULL DEFAULT 2048,      -- Download speed cap (kilobits/sec)
    rate_up_kbps    INTEGER NOT NULL DEFAULT 1024,      -- Upload speed cap (kilobits/sec)
    data_limit_bytes INTEGER NOT NULL DEFAULT 0,        -- 0 = unlimited data
    duration_min    INTEGER NOT NULL DEFAULT 0,         -- 0 = unlimited time (minutes for admin readability)
    price_cents     INTEGER NOT NULL DEFAULT 0,         -- Price in cents (integer avoids float rounding)
    is_visible      INTEGER NOT NULL DEFAULT 1,         -- 1 = shown in portal package list
    time_block_start INTEGER NOT NULL DEFAULT 0,        -- HHMM format (e.g. 800 = 08:00), 0 = no restriction
    time_block_end  INTEGER NOT NULL DEFAULT 0,         -- HHMM format (e.g. 2200 = 22:00)
    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),

    CHECK (rate_down_kbps > 0),
    CHECK (rate_up_kbps > 0),
    CHECK (data_limit_bytes >= 0),
    CHECK (duration_min >= 0),
    CHECK (price_cents >= 0)
);


-- =============================================================================
-- 2. VOUCHER — Generated Codes (Warm Data)
--    Written once at generation time. Read on each login attempt (by code PK).
--    Separated from session to isolate cold voucher definitions from hot
--    session runtime state.
-- =============================================================================
CREATE TABLE IF NOT EXISTS voucher (
    code            TEXT    PRIMARY KEY,                 -- Natural key: the voucher code itself
    package_id      INTEGER DEFAULT NULL,               -- NULL = custom voucher (not from a package)
    rate_down_kbps  INTEGER NOT NULL DEFAULT 2048,      -- Copied from package at generation (allows per-voucher override)
    rate_up_kbps    INTEGER NOT NULL DEFAULT 1024,
    data_limit_bytes INTEGER NOT NULL DEFAULT 0,        -- 0 = unlimited
    duration_min    INTEGER NOT NULL DEFAULT 0,         -- 0 = unlimited
    valid_until     INTEGER NOT NULL DEFAULT 0,         -- Epoch: absolute expiry of the code itself (0 = never)
    time_block_start INTEGER NOT NULL DEFAULT 0,        -- HHMM format (e.g. 800 = 08:00), 0 = no restriction
    time_block_end  INTEGER NOT NULL DEFAULT 0,         -- HHMM format (e.g. 2200 = 22:00)
    price_cents     INTEGER NOT NULL DEFAULT 0,
    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),

    FOREIGN KEY (package_id) REFERENCES package(id) ON DELETE SET NULL,

    CHECK (rate_down_kbps > 0),
    CHECK (rate_up_kbps > 0),
    CHECK (data_limit_bytes >= 0),
    CHECK (duration_min >= 0)
);


-- =============================================================================
-- 3. SESSION — Runtime State (HOT Data)
--    This is the performance-critical table. Updated every accounting cycle
--    (60 seconds) for ALL active sessions. Designed for maximum write
--    throughput and minimum page churn.
--
--    KEY OPTIMIZATION: Rates, limits, and expiry are denormalized from the
--    voucher at punch time. This makes the accounting daemon's read+write
--    path 100% single-table — zero JOINs on the hot path.
--
--    STATUS LIFECYCLE:
--      pending → active → expired|disconnected|quarantined
--
--    The status column replaces the old dual-boolean (is_active + is_quarantined)
--    approach. A single CHECK-constrained TEXT column is clearer, more
--    expressive, and prevents impossible states (active AND quarantined).
-- =============================================================================
CREATE TABLE IF NOT EXISTS session (
    id                  INTEGER PRIMARY KEY,
    voucher_code        TEXT    NOT NULL,                -- FK to voucher.code
    bound_mac           TEXT,                            -- Client MAC (NULL until punched)
    bound_ip            TEXT,                            -- Client IP (may change on re-auth)
    class_id            INTEGER UNIQUE,                  -- TC HTB class ID (≥1000, unique across active sessions)
    status              TEXT    NOT NULL DEFAULT 'pending',

    -- Denormalized from voucher at punch time (hot-path read optimization)
    rate_down_kbps      INTEGER NOT NULL DEFAULT 0,
    rate_up_kbps        INTEGER NOT NULL DEFAULT 0,
    data_limit_bytes    INTEGER NOT NULL DEFAULT 0,      -- 0 = unlimited
    time_block_start    INTEGER NOT NULL DEFAULT 0,      -- HHMM
    time_block_end      INTEGER NOT NULL DEFAULT 0,      -- HHMM

    -- Accounting counters (updated every cycle by sw-acct.sh)
    cumulative_usage_bytes INTEGER NOT NULL DEFAULT 0,   -- Total bytes consumed (monotonically increasing)
    season_usage_bytes  INTEGER NOT NULL DEFAULT 0,      -- TC counter snapshot from last cycle (for delta calculation)

    -- Timestamps (all epoch seconds)
    punched_at          INTEGER NOT NULL DEFAULT 0,      -- First authentication time (0 = not yet punched)
    expires_at          INTEGER NOT NULL DEFAULT 0,      -- Precomputed: min(valid_until, punched_at + duration*60). 0 = no expiry
    last_seen_at        INTEGER NOT NULL DEFAULT 0,      -- Last accounting cycle that saw traffic from this session

    -- Metadata
    quarantine_reason   TEXT,                            -- Non-NULL only when status='quarantined'
    created_at          INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    last_sync_at        INTEGER,                         -- Epoch: when this session was last successfully synced to cloud

    FOREIGN KEY (voucher_code) REFERENCES voucher(code) ON DELETE CASCADE,

    CHECK (status IN ('pending', 'active', 'expired', 'disconnected', 'quarantined')),
    CHECK (cumulative_usage_bytes >= 0),
    CHECK (season_usage_bytes >= 0)
);


-- =============================================================================
-- 4. ACCT_LOG — Per-Cycle Accounting Deltas (Append-Only)
--    One row per session per accounting cycle where traffic was observed.
--    Grows linearly: ~N_sessions × 1440 rows/day. Pruned after 7 days
--    by the maintenance routine. Optional — not on the critical write path
--    (appended in the same batch transaction as session updates).
-- =============================================================================
CREATE TABLE IF NOT EXISTS acct_log (
    id              INTEGER PRIMARY KEY,
    session_id      INTEGER NOT NULL,                   -- FK to session.id (not voucher code — sessions are the accounting unit)
    mac             TEXT    NOT NULL,                    -- Denormalized for fast per-MAC history queries
    delta_bytes     INTEGER NOT NULL,                   -- Bytes consumed in this cycle
    logged_at       INTEGER NOT NULL DEFAULT (strftime('%s','now')),  -- Cycle timestamp

    FOREIGN KEY (session_id) REFERENCES session(id) ON DELETE CASCADE,

    CHECK (delta_bytes >= 0)
);


-- =============================================================================
-- 5. QUARANTINE_EVENT — Anomaly Audit Trail (Append-Only)
--    Logs every quarantine trigger (rate anomaly, admin action).
--    Kept for 30 days then pruned. Small table, cold path.
-- =============================================================================
CREATE TABLE IF NOT EXISTS quarantine_event (
    id              INTEGER PRIMARY KEY,
    mac             TEXT    NOT NULL,
    voucher_code    TEXT,                                -- May be NULL for admin quarantines without a voucher
    reason          TEXT    NOT NULL,                    -- 'rate_anomaly', 'manual', 'cloud_action'
    delta_bytes     INTEGER NOT NULL DEFAULT 0,         -- Traffic delta that triggered the anomaly
    threshold_bytes INTEGER NOT NULL DEFAULT 0,         -- Computed threshold that was exceeded
    detected_at     INTEGER NOT NULL DEFAULT (strftime('%s','now'))
);


-- =============================================================================
-- 6. RATE_LIMIT — Consolidated Login Rate Limiting (Replaces login_attempts + blocks)
--    One row per MAC address. Never grows unboundedly — each MAC gets exactly
--    one row that is UPSERTed. Stale rows are harmlessly overwritten.
--    Eliminates the need for periodic cleanup of the old login_attempts table.
-- =============================================================================
CREATE TABLE IF NOT EXISTS rate_limit (
    mac             TEXT    PRIMARY KEY,                 -- Client MAC
    fail_count      INTEGER NOT NULL DEFAULT 0,         -- Consecutive failures in current window
    window_start_at INTEGER NOT NULL DEFAULT 0,         -- Epoch: when the current failure window opened
    blocked_until   INTEGER NOT NULL DEFAULT 0,         -- Epoch: blocked until this time (0 = not blocked)
    reason          TEXT                                 -- Why this MAC was blocked
);


-- =============================================================================
-- 7. INDEXES — Targeted for Actual Query Patterns
-- =============================================================================

-- Session: The hot-path query. Partial index — only active sessions are indexed.
-- This index stays tiny (only active rows) and auto-shrinks as sessions expire.
-- Covers the accounting daemon's SELECT and the sentinel's reconciliation.
CREATE INDEX IF NOT EXISTS idx_session_active
    ON session(status) WHERE status = 'active';

-- Session: Active session lookup by MAC (deauth-by-MAC, sentinel, re-auth check)
CREATE INDEX IF NOT EXISTS idx_session_active_mac
    ON session(bound_mac) WHERE status = 'active';

-- Session: Class ID lookup (TC stats correlation, gap-finding for new allocation)
-- Note: class_id already has a UNIQUE constraint which creates an implicit index,
-- but this partial index only covers active sessions for faster gap-finding.
CREATE INDEX IF NOT EXISTS idx_session_active_class
    ON session(class_id) WHERE status = 'active' AND class_id IS NOT NULL;

-- Session: Voucher code FK lookups (auth.sh checks for existing session by voucher)
CREATE INDEX IF NOT EXISTS idx_session_voucher
    ON session(voucher_code);

-- Voucher: Package FK lookups (list vouchers by package)
CREATE INDEX IF NOT EXISTS idx_voucher_package
    ON voucher(package_id) WHERE package_id IS NOT NULL;

-- Acct_log: Cleanup queries (DELETE WHERE logged_at < threshold)
CREATE INDEX IF NOT EXISTS idx_acct_log_time
    ON acct_log(logged_at);

-- Acct_log: Per-session history
CREATE INDEX IF NOT EXISTS idx_acct_log_session
    ON acct_log(session_id);

-- Quarantine_event: Cleanup (DELETE WHERE detected_at < threshold)
CREATE INDEX IF NOT EXISTS idx_quarantine_time
    ON quarantine_event(detected_at);

-- Rate_limit: Block expiry check (WHERE blocked_until > now)
-- Not strictly necessary since rate_limit is PK-accessed, but helps cleanup queries.
CREATE INDEX IF NOT EXISTS idx_rate_limit_blocked
    ON rate_limit(blocked_until) WHERE blocked_until > 0;


-- =============================================================================
-- 8. VIEWS — Encapsulate Complex Query Logic
--    These views exist so that shell scripts never contain inline SQL with
--    complex CASE/WHEN/datetime logic. The accounting daemon reads one view;
--    the CLI reads another.
-- =============================================================================

-- 8.1 Active Sessions (for the sw CLI list command and general queries)
CREATE VIEW IF NOT EXISTS v_active AS
    SELECT
        s.id,
        s.voucher_code,
        s.bound_mac,
        s.bound_ip,
        s.class_id,
        s.rate_down_kbps,
        s.rate_up_kbps,
        s.data_limit_bytes,
        s.cumulative_usage_bytes,
        s.season_usage_bytes,
        s.punched_at,
        s.expires_at,
        s.last_seen_at,
        s.time_block_start,
        s.time_block_end
    FROM session s
    WHERE s.status = 'active';

-- 8.2 Accounting Targets (for sw-acct.sh — the 60-second hot path)
--     Returns only the columns the daemon needs. The expires_at check is
--     a simple integer comparison — no datetime() parsing, no JOINs.
DROP VIEW IF EXISTS v_acct_target;
CREATE VIEW v_acct_target AS
    SELECT
        s.bound_mac,
        s.bound_ip,
        s.voucher_code,
        s.class_id,
        s.rate_down_kbps,
        s.rate_up_kbps,
        s.data_limit_bytes,
        s.cumulative_usage_bytes,
        s.season_usage_bytes,
        -- Precomputed expiry flags: pure integer arithmetic, no function calls
        CASE WHEN s.expires_at > 0 AND s.expires_at <= strftime('%s','now')
             THEN 1 ELSE 0
        END AS is_expired,
        CASE 
            -- FIX: use 'localtime' — SQLite 'now' is always UTC
            WHEN s.time_block_start > 0 AND s.time_block_end > 0 AND s.time_block_start < s.time_block_end AND CAST(strftime('%H%M','now','localtime') AS INTEGER) >= s.time_block_start AND CAST(strftime('%H%M','now','localtime') AS INTEGER) <= s.time_block_end THEN 1
            WHEN s.time_block_start > 0 AND s.time_block_end > 0 AND s.time_block_start > s.time_block_end AND (CAST(strftime('%H%M','now','localtime') AS INTEGER) >= s.time_block_start OR CAST(strftime('%H%M','now','localtime') AS INTEGER) <= s.time_block_end) THEN 1
            ELSE 0 
        END AS is_time_blocked
    FROM session s
    WHERE s.status = 'active'
      AND s.bound_mac IS NOT NULL
      AND s.bound_ip IS NOT NULL;

-- 8.3 Quota Status (for capport API and CLI display)
CREATE VIEW IF NOT EXISTS v_quota AS
    SELECT
        s.voucher_code,
        s.bound_mac,
        s.data_limit_bytes,
        s.cumulative_usage_bytes,
        CASE WHEN s.data_limit_bytes = 0 THEN -1
             ELSE s.data_limit_bytes - s.cumulative_usage_bytes
        END AS remaining_bytes,
        CASE WHEN s.data_limit_bytes = 0 THEN 0.0
             ELSE ROUND(100.0 * s.cumulative_usage_bytes / s.data_limit_bytes, 1)
        END AS usage_pct
    FROM session s
    WHERE s.status = 'active';

-- 8.4 Near Quota (for monitoring — sessions approaching their limit)
CREATE VIEW IF NOT EXISTS v_near_quota AS
    SELECT * FROM v_quota WHERE usage_pct >= 90.0;

-- 8.5 Session Restore (for fw-restore.sh after reboot)
CREATE VIEW IF NOT EXISTS v_restore AS
    SELECT
        s.bound_mac,
        s.bound_ip,
        s.rate_down_kbps,
        s.rate_up_kbps,
        s.class_id,
        s.expires_at,
        s.data_limit_bytes,
        s.cumulative_usage_bytes
    FROM session s
    WHERE s.status = 'active'
      AND s.bound_mac IS NOT NULL
      AND s.bound_ip IS NOT NULL
      AND s.class_id IS NOT NULL
      -- [FIX H4] Don't restore expired sessions
      AND (s.expires_at = 0 OR s.expires_at > strftime('%s','now'))
      -- [FIX H4] Don't restore quota-exhausted sessions
      AND (s.data_limit_bytes = 0 OR s.cumulative_usage_bytes < s.data_limit_bytes)
      AND (
          s.time_block_start IS NULL 
          OR s.time_block_end IS NULL 
          OR s.time_block_start = 0 
          OR s.time_block_end = 0
          OR (
              -- FIX: use 'localtime' — SQLite 'now' is always UTC
              s.time_block_start < s.time_block_end AND
              CAST(strftime('%H%M', 'now', 'localtime') AS INTEGER) NOT BETWEEN s.time_block_start AND s.time_block_end
          )
          OR (
              s.time_block_start > s.time_block_end AND
              CAST(strftime('%H%M', 'now', 'localtime') AS INTEGER) NOT BETWEEN s.time_block_start AND 2359 AND
              CAST(strftime('%H%M', 'now', 'localtime') AS INTEGER) NOT BETWEEN 0 AND s.time_block_end
          )
      );

-- 8.6 Quarantined MACs (for fw-restore.sh — re-add to nft quarantine set)
CREATE VIEW IF NOT EXISTS v_quarantined AS
    SELECT DISTINCT s.bound_mac
    FROM session s
    WHERE s.status = 'quarantined'
      AND s.bound_mac IS NOT NULL;


-- =============================================================================
-- 9. TRIGGERS — Automatic State Transitions
-- =============================================================================

-- Quota enforcement trigger: fires on every usage update.
-- When cumulative bytes reach the data limit, automatically transition
-- the session to 'expired'. This provides sub-second quota cutoff without
-- waiting for the next accounting cycle to check.



UPDATE system_config SET value = '5.6.3' WHERE key = 'firmware_version';
