# SuperWiFi nftables ruleset — TEMPLATE FILE
# Placeholders substituted by superwifi start:
#   %%LAN_IFACE%%   → LAN_IFACE
#   %%PORTAL_IP%%   → PORTAL_IP
#   %%BYPASS_MACS_BLOCK%% → space/comma separated MACs (may be empty)
#
# PREREQUISITE: Disable software flow offloading:
#   uci set firewall.@defaults[0].flow_offloading=0
#   uci commit firewall && fw4 reload

table inet superwifi {

    # Authenticated clients: MAC+IP binding with per-element byte counters
    set authenticated {
        type ether_addr . ipv4_addr
        flags dynamic, timeout
        timeout 24h
        counter
        comment "MAC+IP pairs of authenticated sessions"
    }

    # Static bypass MACs (staff/printers — skip portal)
    # Note: elements line is only added when ALLOWED_MACS is non-empty
    set bypass_macs {
        type ether_addr
        flags interval
        comment "MACs that bypass captive portal"
        %%BYPASS_MACS_BLOCK%%
    }

    # Quarantined MACs (anomaly detection) — timeout matches BLOCK_DUR (default 15m)
    # Using 'flags dynamic,timeout' so individual elements can have per-element timeouts
    set quarantined {
        type ether_addr
        flags dynamic, timeout
        timeout 15m
        comment "MACs quarantined by anomaly detection (auto-expire)"
    }

    chain forward {
        type filter hook forward priority filter - 1; policy drop;

        # Fast path for established incoming traffic (Internet -> br-lan)
        iifname != "%%LAN_IFACE%%" ct state established, related accept

        # ── Block ALL IPv6 from LAN (no IPv6 captive portal support yet)
        # Without this, devices can bypass the portal entirely using IPv6.
        # Allow only ICMPv6 neighbor discovery (essential for LAN to function)
        ip6 saddr != ::1 iifname "%%LAN_IFACE%%" icmpv6 type {
            nd-neighbor-solicit, nd-neighbor-advert,
            nd-router-solicit, nd-router-advert,
            mld-listener-query, mld-listener-report
        } accept
        ip6 saddr != ::1 iifname "%%LAN_IFACE%%" drop

        ether saddr @quarantined log prefix "superwifi-quarantine: " level warn drop
        ether saddr @bypass_macs accept
        iifname "%%LAN_IFACE%%" oifname "%%LAN_IFACE%%" drop
        ether saddr . ip saddr @authenticated accept
        ip daddr %%PORTAL_IP%% tcp dport { 80, 443 } accept
        ip daddr %%PORTAL_IP%% udp dport 53 accept
        
        # Drop any remaining outgoing traffic from the LAN (kills established connections of deauthed users)
        iifname "%%LAN_IFACE%%" drop
    }

    chain prerouting {
        type nat hook prerouting priority dstnat; policy accept;
        # Redirect HTTP to captive portal for unauthenticated clients
        iifname "%%LAN_IFACE%%" tcp dport 80 ip daddr != %%PORTAL_IP%% ether saddr != @bypass_macs ether saddr . ip saddr != @authenticated redirect to :80
        # HTTPS handling for unauthenticated clients (Candidate A: drop / Candidate B: reject with icmpx type port-unreachable)
        # Prevents immediate TCP RST socket teardown on legacy Android parallel probe threads
        iifname "%%LAN_IFACE%%" tcp dport 443 ip daddr != %%PORTAL_IP%% ether saddr != @bypass_macs ether saddr . ip saddr != @authenticated drop
        # FIX: Force DNS queries from unauthenticated clients to local resolver
        # Without this, devices using 8.8.8.8 or other external DNS cannot resolve
        # captive portal detection domains (connectivitycheck.gstatic.com, etc.)
        iifname "%%LAN_IFACE%%" udp dport 53 ip daddr != %%PORTAL_IP%% ether saddr != @bypass_macs ether saddr . ip saddr != @authenticated redirect to :53
        iifname "%%LAN_IFACE%%" tcp dport 53 ip daddr != %%PORTAL_IP%% ether saddr != @bypass_macs ether saddr . ip saddr != @authenticated redirect to :53
    }
}
