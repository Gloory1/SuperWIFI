#!/bin/sh
# /www/index.cgi — SuperWiFi Smart Root Router

REMOTE_IP="${REMOTE_ADDR:-}"
IS_BYPASS=0

if [ -n "$REMOTE_IP" ]; then
    CLIENT_MAC=$(ip neigh show "$REMOTE_IP" 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="lladdr" && $(i+1)!="") {print tolower($(i+1)); exit}}')
    [ -z "$CLIENT_MAC" ] && [ -f /proc/net/arp ] && CLIENT_MAC=$(awk -v ip="$REMOTE_IP" '$1 == ip && $4 != "00:00:00:00:00:00" {print tolower($4); exit}' /proc/net/arp 2>/dev/null)
    [ -z "$CLIENT_MAC" ] && [ -f /tmp/dhcp.leases ] && CLIENT_MAC=$(awk -v ip="$REMOTE_IP" '$3 == ip {print tolower($2); exit}' /tmp/dhcp.leases 2>/dev/null)

    if [ -n "$CLIENT_MAC" ]; then
        CLIENT_MAC_LOWER=$(printf '%s' "$CLIENT_MAC" | tr 'A-Z' 'a-z')
        BYPASS_MACS=$(uci get superwifi.bypass.mac 2>/dev/null)
        for bmac in $BYPASS_MACS; do
            bmac_lower=$(printf '%s' "$bmac" | tr 'A-Z' 'a-z')
            if [ -n "$bmac_lower" ] && [ "$bmac_lower" = "$CLIENT_MAC_LOWER" ]; then
                IS_BYPASS=1
                break
            fi
        done
    fi
fi

if [ "$IS_BYPASS" = "1" ]; then
    printf "Status: 302 Found\r\n"
    printf "Location: /cgi-bin/luci\r\n\r\n"
else
    printf "Status: 302 Found\r\n"
    printf "Location: /superwifi/login.html\r\n\r\n"
fi
