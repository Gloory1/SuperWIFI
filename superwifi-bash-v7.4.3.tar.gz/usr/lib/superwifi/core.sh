#!/bin/sh
# /usr/lib/superwifi/core.sh

json_error() {
    local error_code="${1:-UNKNOWN_ERROR}"
    local message="${2:-Unknown error occurred.}"
    local extra="${3}"
    printf 'Content-Type: application/json\r\n'
    printf 'Cache-Control: no-store\r\n\r\n'
    if [ -n "$extra" ]; then
        printf '{"status":"error","error_code":"%s","message":"%s",%s}\n' "$error_code" "$message" "$extra"
    else
        printf '{"status":"error","error_code":"%s","message":"%s"}\n' "$error_code" "$message"
    fi
}

format_time() {
    local t="$1"
    [ -z "$t" ] && t=0
    printf "%02d:%02d" $(( t / 100 )) $(( t % 100 ))
}

json_ok() {
    printf 'Content-Type: application/json\r\n'
    printf 'Cache-Control: no-store\r\n\r\n'
    printf '{"status":"ok",%s}\n' "$1"
}

validate_voucher() {
    printf '%s' "$1" | grep -qE '^[A-Za-z0-9_-]{2,32}$'
}

validate_mac() {
    printf '%s' "$1" | grep -qiE '^([0-9a-f]{2}:){5}[0-9a-f]{2}$'
}

validate_ip() {
    local ip="$1"
    # First check format, then validate each octet is 0-255
    printf '%s' "$ip" | grep -qE '^([0-9]{1,3}\.){3}[0-9]{1,3}$' || return 1
    local IFS='.'
    # shellcheck disable=SC2086
    set -- $ip
    [ "$1" -le 255 ] && [ "$2" -le 255 ] && [ "$3" -le 255 ] && [ "$4" -le 255 ] 2>/dev/null
}

sw_log() {
    local level="$1"
    local msg="$2"
    logger -t superwifi "[$level] $msg"
}

# Load configuration using UCI
sw_load_config() {
    [ -f "/etc/config/superwifi" ] || return 0
    . /lib/functions.sh 2>/dev/null || true
    
    config_load superwifi 2>/dev/null || {
        # Fallback if config_load fails (e.g. testing off-router)
        DB_PATH=$(uci get superwifi.core.db_path 2>/dev/null)
        LAN_IFACE=$(uci get superwifi.core.lan_iface 2>/dev/null)
        PORTAL_IP=$(uci get superwifi.core.portal_ip 2>/dev/null)
        PORTAL_PORT=$(uci get superwifi.core.portal_port 2>/dev/null)
        PORTAL_URL=$(uci get superwifi.core.portal_url 2>/dev/null)
        SUCCESS_URL=$(uci get superwifi.core.success_url 2>/dev/null)
        [ -z "$SUCCESS_URL" ] && SUCCESS_URL="$PORTAL_URL"
        CAPPORT_API_URL=$(uci get superwifi.core.capport_api_url 2>/dev/null)
        CHECK_INTERVAL_SEC=$(uci get superwifi.core.check_interval_sec 2>/dev/null)
        TC_BURST_KB=$(uci get superwifi.core.tc_burst_kb 2>/dev/null)
        MAC_REBIND_ENABLED=$(uci get superwifi.core.mac_rebind_enabled 2>/dev/null)
        ANOMALY_MULTIPLIER=$(uci get superwifi.core.anomaly_multiplier 2>/dev/null)
        SENTINEL_ENABLED=$(uci get superwifi.core.sentinel_enabled 2>/dev/null)
        RATE_LIMIT=$(uci get superwifi.core.rate_limit 2>/dev/null)
        
        ALLOWED_MACS=$(uci get superwifi.bypass.mac 2>/dev/null | tr ' ' '\n' | xargs)
        return 0
    }
    
    config_get DB_PATH core db_path "/etc/superwifi/superwifi.db"
    config_get LAN_IFACE core lan_iface "br-lan"
    config_get PORTAL_IP core portal_ip "10.0.0.1"
    config_get PORTAL_PORT core portal_port "80"
    config_get PORTAL_URL core portal_url "http://10.0.0.1/superwifi/login.html"
    config_get SUCCESS_URL core success_url "$PORTAL_URL"
    config_get CAPPORT_API_URL core capport_api_url "http://10.0.0.1/cgi-bin/capport-api.sh"
    config_get CHECK_INTERVAL_SEC core check_interval_sec "60"
    config_get TC_BURST_KB core tc_burst_kb "64"
    config_get MAC_REBIND_ENABLED core mac_rebind_enabled "0"
    config_get ANOMALY_MULTIPLIER core anomaly_multiplier "1.2"
    config_get SENTINEL_ENABLED core sentinel_enabled "1"
    config_get RATE_LIMIT core rate_limit "30"
    
    local macs=""
    config_list_foreach bypass mac append_mac
    ALLOWED_MACS="$macs"
}

append_mac() {
    local m="$1"
    if [ -z "$macs" ]; then
        macs="$m"
    else
        macs="$macs $m"
    fi
}

gen_bypass_elements() {
    local result=""
    local mac
    for mac in $ALLOWED_MACS; do
        validate_mac "$mac" || { sw_log "WARN" "invalid bypass MAC '$mac', skipping"; continue; }
        if [ -z "$result" ]; then
            result="$mac"
        else
            result="${result}, ${mac}"
        fi
    done
    printf '%s' "$result"
}

get_mac_by_ip() {
    local ip="$1"
    validate_ip "$ip" || return 1
    local mac attempt=1 max_attempts=3

    while [ "$attempt" -le "$max_attempts" ]; do
        # 1. Try ip neigh show with robust lladdr extraction
        mac=$(ip neigh show "$ip" 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="lladdr" && $(i+1)!="") {print tolower($(i+1)); exit}}')
        if [ -n "$mac" ] && validate_mac "$mac"; then
            printf '%s' "$mac"
            return 0
        fi

        # 2. Try /proc/net/arp
        if [ -f /proc/net/arp ]; then
            mac=$(awk -v ip="$ip" '$1 == ip && $4 != "00:00:00:00:00:00" {print tolower($4); exit}' /proc/net/arp 2>/dev/null)
            if [ -n "$mac" ] && validate_mac "$mac"; then
                printf '%s' "$mac"
                return 0
            fi
        fi

        # 3. Try /tmp/dhcp.leases
        if [ -f /tmp/dhcp.leases ]; then
            mac=$(awk -v ip="$ip" '$3 == ip {print tolower($2); exit}' /tmp/dhcp.leases 2>/dev/null)
            if [ -n "$mac" ] && validate_mac "$mac"; then
                printf '%s' "$mac"
                return 0
            fi
        fi

        # 4. Active ARP probe fallback: force kernel neighbor discovery via ping
        ping -c 1 -W 1 "$ip" >/dev/null 2>&1 || true

        # Re-check ip neigh immediately after ping probe
        mac=$(ip neigh show "$ip" 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="lladdr" && $(i+1)!="") {print tolower($(i+1)); exit}}')
        if [ -n "$mac" ] && validate_mac "$mac"; then
            printf '%s' "$mac"
            return 0
        fi

        # Re-check /proc/net/arp after ping probe
        if [ -f /proc/net/arp ]; then
            mac=$(awk -v ip="$ip" '$1 == ip && $4 != "00:00:00:00:00:00" {print tolower($4); exit}' /proc/net/arp 2>/dev/null)
            if [ -n "$mac" ] && validate_mac "$mac"; then
                printf '%s' "$mac"
                return 0
            fi
        fi

        if [ "$attempt" -lt "$max_attempts" ]; then
            sleep 1 2>/dev/null || true
        fi
        attempt=$((attempt + 1))
    done

    sw_log "WARN" "MAC resolution failed for IP $ip after $max_attempts attempts"
    return 1
}

get_mac_by_ip_safe() {
    local ip="$1"
    local mac
    mac=$(get_mac_by_ip "$ip")
    if [ -z "$mac" ] || ! validate_mac "$mac"; then
        return 1
    fi
    printf '%s' "$mac"
}

sw_apply_arp_harden() {
    local iface="${LAN_IFACE:-br-lan}"
    sysctl -w "net.ipv4.conf.${iface}.arp_ignore=1"    >/dev/null 2>&1 || true
    sysctl -w "net.ipv4.conf.${iface}.arp_announce=2"  >/dev/null 2>&1 || true
}

# Config validation — prints WARN for each issue, returns 0=all good
sw_validate_config() {
    local rc=0
    validate_ip "$PORTAL_IP" || { sw_log "WARN" "PORTAL_IP='$PORTAL_IP' invalid"; rc=1; }
    [ -n "$LAN_IFACE" ] || { sw_log "WARN" "LAN_IFACE is empty"; rc=1; }
    [ "${CHECK_INTERVAL_SEC:-60}" -gt 0 ] 2>/dev/null || { sw_log "WARN" "check_interval_sec must be > 0"; rc=1; }
    [ "${TC_BURST_KB:-64}" -gt 0 ] 2>/dev/null || { sw_log "WARN" "tc_burst_kb must be > 0"; rc=1; }
    command -v sqlite3 >/dev/null 2>&1 || { sw_log "WARN" "sqlite3 not installed"; rc=1; }
    command -v nft >/dev/null 2>&1 || { sw_log "WARN" "nftables not installed"; rc=1; }
    command -v tc >/dev/null 2>&1 || { sw_log "WARN" "tc not installed"; rc=1; }
    command -v logger >/dev/null 2>&1 || { sw_log "WARN" "logger not found"; rc=1; }
    return "$rc"
}

sw_load_config

# Single Source of Truth Version Reader
sw_get_version() {
    if [ -f "/etc/superwifi-version" ]; then
        tr -d ' \r\n' < /etc/superwifi-version 2>/dev/null
    else
        db_get_firmware_version 2>/dev/null || echo "0.0.0"
    fi
}
