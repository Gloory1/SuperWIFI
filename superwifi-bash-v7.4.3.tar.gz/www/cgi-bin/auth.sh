#!/bin/sh
# /www/cgi-bin/auth.sh — SuperWiFi Authentication CGI
#   GET  ?action=page     → serve login.html with MAC injected
#   GET  ?action=capport  → RFC 8908 JSON response
#   GET  ?action=packages → JSON packages list
#   POST                  → authenticate voucher, return JSON

. /usr/lib/superwifi/core.sh
. /usr/lib/superwifi/db-queries.sh
. /usr/lib/superwifi/tc.sh
. /usr/lib/superwifi/fw.sh

MAX_FAILS=$(uci get superwifi.core.max_failed_attempts 2>/dev/null || echo 5)
MAX_FAILS=$(printf '%s' "$MAX_FAILS" | tr -dc '0-9'); [ -z "$MAX_FAILS" ] && MAX_FAILS=5
BLOCK_DUR=$(uci get superwifi.core.block_duration_min 2>/dev/null || echo 15)
# [FIX M12] Sanitize BLOCK_DUR to digits-only before use in nft command
BLOCK_DUR=$(printf '%s' "$BLOCK_DUR" | tr -dc '0-9'); [ -z "$BLOCK_DUR" ] && BLOCK_DUR=15
# [v6.2.5] URL the frontend should navigate to after a successful auth to dismiss the CNA
SUCCESS_URL=$(uci get superwifi.core.success_url 2>/dev/null || echo "http://connectivitycheck.gstatic.com/generate_204")

read_post_body() {
    local len="${CONTENT_LENGTH:-0}"
    len=$(printf '%s' "$len" | tr -dc '0-9')
    # Cap at 256 bytes — voucher codes are at most 32 chars, form overhead ~50 bytes
    [ "$len" -gt 256 ] && len=256
    [ "$len" -gt 0 ] && dd bs=1 count="$len" 2>/dev/null || true
}

urldecode() {
    local encoded="$1"
    printf '%b' "$(printf '%s' "$encoded" | sed 's/+/ /g; s/%\([0-9A-Fa-f][0-9A-Fa-f]\)/\\x\1/g')"
}

check_time_block() {
    local tstart="$1"
    local tend="$2"
    local now_hm="$3"
    
    [ -z "$tstart" ] || [ "$tstart" -eq 0 ] && return 0
    [ -z "$tend" ] || [ "$tend" -eq 0 ] && return 0
    
    local _now_hm
    _now_hm=$(echo "$now_hm" | sed 's/^0*//')
    [ -z "$_now_hm" ] && _now_hm=0
    
    if [ "$tstart" -lt "$tend" ]; then
        if [ "$_now_hm" -ge "$tstart" ] && [ "$_now_hm" -le "$tend" ]; then
            return 1
        fi
    else
        if [ "$_now_hm" -ge "$tstart" ] || [ "$_now_hm" -le "$tend" ]; then
            return 1
        fi
    fi
    return 0
}

parse_capport_session() {
    [ -z "$1" ] && return 1
    local _old_ifs="$IFS"
    IFS='|'
    set -- $1
    IFS="$_old_ifs"
    active_voucher="$1"
    s_status="$2"
    s_ip="$3"
    s_down="$4"
    s_up="$5"
    s_limit="$6"
    s_cum="$7"
    s_expires="$8"
    tstart="$9"
    shift 9 2>/dev/null || true
    tend="$1"
    tmo="$2"
    v_dur="$3"
}

handle_capport_rebind() {
    local client_mac="$1"
    local client_ip="$2"

    # [FIX H1] Check if MAC is quarantined/banned before allowing rebind
    if nft get element inet superwifi quarantined "{ $client_mac }" >/dev/null 2>&1; then
        sw_log "WARN" "CAPPORT REBIND BLOCKED: MAC $client_mac is quarantined."
        return 1
    fi

    local session_raw
    session_raw=$(db_get_capport_session_full "$client_mac")
    if [ -z "$session_raw" ]; then
        return 1
    fi

    local active_voucher s_status s_ip s_down s_up s_limit s_cum s_expires tstart tend tmo v_dur
    parse_capport_session "$session_raw"

    local status="$s_status" r_down="$s_down" r_up="$s_up" limit="$s_limit" cum="$s_cum" expires="$s_expires"
    [ -z "$limit" ] && limit=0
    [ -z "$cum" ] && cum=0
    [ -z "$expires" ] && expires=0
    [ -z "$tmo" ] && tmo=86400

    local now_epoch=$(date +%s)
    if [ "$status" = "quarantined" ] || [ "$status" = "expired" ] || [ "$status" = "disconnected" ] || { [ "$expires" -gt 0 ] && [ "$expires" -le "$now_epoch" ]; } || { [ "$limit" -gt 0 ] && [ "$cum" -ge "$limit" ]; }; then
        return 1 # Cannot rebind, session invalid or disconnected
    fi

    local d now_hm
    d=$(date +"%s|%H%M")
    now_hm=${d#*|}

    if ! check_time_block "${tstart:-0}" "${tend:-0}" "$now_hm"; then
        local ts_fmt te_fmt msg
        ts_fmt=$(format_time "${tstart:-0}")
        te_fmt=$(format_time "${tend:-0}")
        msg="Access is restricted between $ts_fmt and $te_fmt."
        json_error "TIME_BLOCKED" "$msg" "\"time_start\":\"$ts_fmt\",\"time_end\":\"$te_fmt\""
        return 1
    fi

    db_reauth_session "$active_voucher" "$client_ip"
    sw_fw_auth "$client_mac" "$client_ip" "$tmo"
    sw_tc_apply "$client_mac" "$client_ip" "${r_down:-2048}" "${r_up:-1024}" "1000" 2>/dev/null || true
    sw_log "INFO" "CAPPORT: Auto-rebound active session for $client_mac with new IP $client_ip"
    return 0
}

handle_capport_api() {
    sw_db_init || return
    local client_ip="$1"
    local client_mac="" is_captive="true" remaining_bytes="null"
    local active_voucher="" s_status="" s_down="0" s_up="0" v_dur="0" rem_min="0"

    if validate_ip "$client_ip"; then
        client_mac=$(get_mac_by_ip_safe "$client_ip")
    fi

    if [ -n "$client_mac" ]; then
        nft get element inet superwifi authenticated "{ ${client_mac} . ${client_ip} }" >/dev/null 2>&1 && is_captive="false"
        
        # Self-healing auto-rebind for known MAC with new DHCP IP
        if [ "$is_captive" = "true" ]; then
            if handle_capport_rebind "$client_mac" "$client_ip"; then
                is_captive="false"
            fi
        fi

        local session_raw
        session_raw=$(db_get_capport_session_full "$client_mac")
        if [ -n "$session_raw" ]; then
            local s_ip s_limit s_cum s_expires tstart tend tmo
            parse_capport_session "$session_raw"
            [ -z "$s_limit" ] && s_limit=0
            [ -z "$s_cum" ] && s_cum=0
            [ -z "$s_expires" ] && s_expires=0
            [ -z "$v_dur" ] && v_dur=0

            if [ "$s_limit" -gt 0 ]; then
                remaining_bytes=$(( s_limit - s_cum ))
                [ "$remaining_bytes" -lt 0 ] && remaining_bytes=0
            fi

            if [ "$s_expires" -gt 0 ]; then
                local now_epoch=$(date +%s)
                rem_min=$(( (s_expires - now_epoch) / 60 ))
                [ "$rem_min" -lt 0 ] && rem_min=0
            elif [ "$v_dur" -gt 0 ]; then
                rem_min=$v_dur
            fi
        fi
    else
        sw_log "WARN" "CAPPORT: MAC resolution failed for IP $client_ip"
        s_status="mac_unknown"
    fi

    local p_name sys_ver
    p_name=$(uci get superwifi.core.provider_name 2>/dev/null || echo "SuperWiFi")
    sys_ver=$(cat /etc/superwifi-version 2>/dev/null)

    local canonical_portal_url="$PORTAL_URL"
    case "$canonical_portal_url" in
        *\?*) ;;
        *) canonical_portal_url="${canonical_portal_url}?cp=1" ;;
    esac

    printf 'Content-Type: application/captive+json\r\n'
    printf 'Cache-Control: private\r\n\r\n'
    if [ "$is_captive" = "false" ]; then
        printf '{"captive":false,"user-portal-url":"%s","bytes-remaining":%s,"client-mac":"%s","provider_name":"%s","sys_version":"%s","rate_down_kbps":%s,"rate_up_kbps":%s,"remaining_min":%s,"bound_voucher":"%s","session_status":"%s"}\n' \
            "$canonical_portal_url" "${remaining_bytes:-null}" "$client_mac" "$p_name" "$sys_ver" "${s_down:-0}" "${s_up:-0}" "${rem_min:-0}" "${active_voucher:-}" "${s_status:-active}"
    else
        if [ "$s_status" = "disconnected" ] && [ -n "$active_voucher" ]; then
            printf '{"captive":true,"user-portal-url":"%s","client-mac":"%s","provider_name":"%s","sys_version":"%s","bound_voucher":"%s","session_status":"disconnected","bytes-remaining":%s,"rate_down_kbps":%s,"rate_up_kbps":%s,"remaining_min":%s}\n' \
                "$canonical_portal_url" "$client_mac" "$p_name" "$sys_ver" "$active_voucher" "${remaining_bytes:-null}" "${s_down:-0}" "${s_up:-0}" "${rem_min:-0}"
        elif [ "$s_status" = "mac_unknown" ]; then
            printf '{"captive":true,"user-portal-url":"%s","client-mac":"","provider_name":"%s","sys_version":"%s","session_status":"mac_unknown","error_code":"MAC_UNKNOWN"}\n' \
                "$canonical_portal_url" "$p_name" "$sys_ver"
        else
            printf '{"captive":true,"user-portal-url":"%s","client-mac":"%s","provider_name":"%s","sys_version":"%s","session_status":"none"}\n' "$canonical_portal_url" "$client_mac" "$p_name" "$sys_ver"
        fi
    fi
}

handle_logout() {
    sw_db_init || { json_error "SYSTEM_ERROR" "Service unavailable."; return; }
    local client_ip="$REMOTE_ADDR"
    local client_mac=""
    if validate_ip "$client_ip"; then
        client_mac=$(get_mac_by_ip_safe "$client_ip")
    fi
    validate_mac "$client_mac" || {
        json_error "MAC_UNKNOWN" "Cannot determine device MAC."
        return
    }

    local active_voucher
    active_voucher=$(db_get_voucher_code_by_mac "$client_mac")
    if [ -z "$active_voucher" ]; then
        json_error "VOUCHER_NOT_FOUND" "No session found to log out."
        return
    fi

    local cid
    cid=$(db_get_class_id_by_voucher "$active_voucher")

    # Error-isolated teardown
    nft delete element inet superwifi authenticated "{ ${client_mac} . ${client_ip} }" 2>/dev/null || true
    conntrack -D -s "$client_ip" 2>/dev/null || true
    sw_tc_remove_by_ip "$client_ip" 2>/dev/null || true
    [ -n "$cid" ] && [ "$cid" != "NULL" ] && sw_tc_remove "$cid" 2>/dev/null || true

    db_deactivate_session_by_code "$active_voucher"

    sw_log "INFO" "LOGOUT SUCCESS: mac=$client_mac ip=$client_ip voucher=$active_voucher"

    printf 'Content-Type: application/json\r\nCache-Control: no-store\r\n\r\n'
    printf '{"status":"ok","message":"Logged out successfully","voucher":"%s"}\n' "$active_voucher"
}

handle_page() {
    local client_ip="$REMOTE_ADDR"
    local client_mac=""

    if validate_ip "$client_ip"; then
        client_mac=$(get_mac_by_ip_safe "$client_ip")
    fi

    local login_html="/www/superwifi/login.html"
    if [ ! -f "$login_html" ]; then
        printf 'Status: 500 Internal Server Error\r\nContent-Type: text/plain\r\n\r\n'
        printf 'Login page not found. Run: /etc/init.d/superwifi start\n'
        return
    fi

    printf 'Content-Type: text/html; charset=UTF-8\r\n'
    printf 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0\r\n'
    printf 'Pragma: no-cache\r\n'
    printf 'Expires: 0\r\n\r\n'
    local provider_name fw_version
    provider_name=$(uci get superwifi.core.provider_name 2>/dev/null || echo "SuperWiFi")
    fw_version=$(sw_get_version)
    sed -e "s|%%CLIENT_MAC%%|${client_mac}|g" \
        -e "s|%%PROVIDER_NAME%%|${provider_name}|g" \
        -e "s|%%VERSION%%|${fw_version}|g" \
        -e "s|%%FIRMWARE_VERSION%%|${fw_version}|g" "$login_html"
}

handle_packages_api() {
    sw_db_init || { json_error "SYSTEM_ERROR" "Service unavailable."; return; }
    printf 'Content-Type: application/json\r\nCache-Control: no-store\r\n\r\n'
    local pkgs_json
    pkgs_json=$(db_get_packages_json)
    [ -z "$pkgs_json" ] || [ "$pkgs_json" = "null" ] && pkgs_json="[]"
    printf '{"status":"ok","packages":%s}\n' "$pkgs_json"
}

handle_auth() {
    local client_ip="$REMOTE_ADDR"
    local post_body voucher client_mac

    post_body=$(read_post_body)
    voucher=$(printf '%s' "$post_body" | tr '&' '\n' | grep '^voucher=' | cut -d= -f2- | head -1)
    voucher=$(urldecode "$voucher")

    validate_voucher "$voucher" || {
        json_error "INVALID_FORMAT" "Invalid voucher code format."
        sw_log "WARN" "AUTH REJECT: bad format from $client_ip"
        return
    }
    validate_ip "$client_ip" || {
        json_error "IP_UNKNOWN" "Cannot determine client IP."
        return
    }

    client_mac=$(get_mac_by_ip_safe "$client_ip")
    [ -z "$client_mac" ] && client_mac=""
    validate_mac "$client_mac" || {
        json_error "MAC_UNKNOWN" "Cannot determine device MAC. Try reconnecting to Wi-Fi."
        sw_log "WARN" "AUTH REJECT: ARP lookup failed for $client_ip"
        return
    }

    sw_db_init || { json_error "SYSTEM_ERROR" "Service unavailable."; return; }

    local now_epoch now_hm d
    d=$(date    +"%s|%H%M")
    now_epoch=${d%|*}
    now_hm=${d#*|}

    nft get element inet superwifi quarantined "{ $client_mac }" 2>/dev/null
    if [ $? -eq 0 ]; then
        json_error "MAC_BANNED" "Your device has been blocked by the administrator."
        sw_log "WARN" "AUTH REJECT: MAC $client_mac is banned."
        return
    fi

    # 1. Check Rate Limiting using the new unified table
    local rate_data fail_count blocked_until
    rate_data=$(db_get_rate_limit "$client_mac")
    if [ -n "$rate_data" ]; then
        fail_count=$(printf '%s' "$rate_data" | cut -d'|' -f1)
        blocked_until=$(printf '%s' "$rate_data" | cut -d'|' -f2)
        
        if [ "$blocked_until" -gt "$now_epoch" ]; then
            local wait_min=$(( (blocked_until - now_epoch) / 60 + 1 ))
            json_error "SPAM_BLOCKED" "Too many failed attempts. Try again in $wait_min minutes."
            return
        fi
    else
        fail_count=0
        blocked_until=0
    fi

    # 2. Look up the voucher definition
    local v_data
    v_data=$(db_get_voucher_definition "$voucher")

    if [ -z "$v_data" ]; then
        # Voucher doesn't exist. Increment fail count.
        fail_count=$((fail_count + 1))
        if [ "$fail_count" -ge "$MAX_FAILS" ]; then
            local block_time=$((now_epoch + (BLOCK_DUR * 60)))
            db_upsert_rate_limit "$client_mac" "$fail_count" "$block_time" "Too many failed attempts"
            # Add to nft quarantine with matching timeout so it auto-expires with the DB block
            nft add element inet superwifi quarantined "{ $client_mac timeout ${BLOCK_DUR}m }" 2>/dev/null || \
                nft add element inet superwifi quarantined "{ $client_mac }" 2>/dev/null || true
            json_error "SPAM_BLOCKED" "Blocked for $BLOCK_DUR minutes due to invalid attempts."
            sw_log "WARN" "AUTH BLOCKED: $client_mac reached max failed attempts."
        else
            db_upsert_rate_limit "$client_mac" "$fail_count" 0 "Failed attempt"
            json_error "VOUCHER_NOT_FOUND" "Invalid code. $((MAX_FAILS - fail_count)) attempts remaining."
            sw_log "WARN" "AUTH REJECT: voucher '$voucher' not found from $client_mac (Fail $fail_count/$MAX_FAILS)"
        fi
        return
    fi

    # [FIX H2] Do NOT reset rate limit here — wait until all validation passes below

    # 3. Check if a session already exists for this voucher
    local s_data
    s_data=$(db_get_session_by_voucher "$voucher")

    if [ -n "$s_data" ]; then
        # Session Exists
        # Extract v_dur from voucher definition for the JSON response
        local v_dur
        v_dur=$(printf '%s' "$v_data" | cut -d'|' -f5)
        [ -z "$v_dur" ] && v_dur=0
        local s_id s_mac s_ip s_status s_down s_up s_limit s_cum s_punched s_expires s_tstart s_tend
        s_id=$(printf '%s' "$s_data" | cut -d'|' -f1)
        s_mac=$(printf '%s' "$s_data" | cut -d'|' -f2)
        s_ip=$(printf '%s' "$s_data" | cut -d'|' -f3)
        s_status=$(printf '%s' "$s_data" | cut -d'|' -f4)
        s_down=$(printf '%s' "$s_data" | cut -d'|' -f5)
        s_up=$(printf '%s' "$s_data" | cut -d'|' -f6)
        s_limit=$(printf '%s' "$s_data" | cut -d'|' -f7)
        s_cum=$(printf '%s' "$s_data" | cut -d'|' -f8)
        s_punched=$(printf '%s' "$s_data" | cut -d'|' -f9)
        s_expires=$(printf '%s' "$s_data" | cut -d'|' -f10)
        s_tstart=$(printf '%s' "$s_data" | cut -d'|' -f11)
        s_tend=$(printf '%s' "$s_data" | cut -d'|' -f12)

        [ -z "$s_limit" ] && s_limit=0
        [ -z "$s_cum" ] && s_cum=0
        [ -z "$s_expires" ] && s_expires=0
        [ -z "$s_tstart" ] && s_tstart=0
        [ -z "$s_tend" ] && s_tend=0


        if [ "$s_status" = "quarantined" ]; then
            json_error "VOUCHER_BANNED" "This voucher has been blocked by the administrator."
            sw_log "WARN" "AUTH REJECT: quarantined voucher '$voucher'"
            return
        fi

        if [ "$s_status" = "expired" ] || { [ "$s_expires" -gt 0 ] && [ "$s_expires" -le "$now_epoch" ]; } || { [ "$s_limit" -gt 0 ] && [ "$s_cum" -ge "$s_limit" ]; }; then
            db_expire_session_by_code "$voucher"
            json_error "VOUCHER_EXHAUSTED" "Voucher expired or quota exhausted."
            sw_log "WARN" "AUTH REJECT: expired '$voucher'"
            return
        fi

        if [ -n "$s_mac" ] && [ "$s_mac" != "$client_mac" ]; then
            json_error "MAC_MISMATCH" "This voucher is already in use by another device."
            sw_log "WARN" "AUTH REJECT: MAC mismatch for voucher '$voucher'"
            return
        fi

        if [ -z "$s_mac" ]; then
            db_rebind_session_mac_ip "$voucher" "$client_mac" "$client_ip"
            sw_log "INFO" "AUTH REBIND: voucher '$voucher' rebound to mac $client_mac"
        fi

        # Time block check natively
        if ! check_time_block "$s_tstart" "$s_tend" "$now_hm"; then
            local ts_fmt te_fmt msg
            ts_fmt=$(format_time "$s_tstart")
            te_fmt=$(format_time "$s_tend")
            msg="Access is restricted between $ts_fmt and $te_fmt."
            json_error "TIME_BLOCKED" "$msg" "\"time_start\":\"$ts_fmt\",\"time_end\":\"$te_fmt\""
            return
        fi

        # [FIX H2] All validation passed — now safe to reset rate limit
        db_upsert_rate_limit "$client_mac" 0 0 "Success"

        # Re-auth: remove old tc class to reset hardware counters (fixes double-counting)
        local old_cid
        old_cid=$(db_get_class_id_by_voucher "$voucher")
        if [ -n "$old_cid" ]; then
            sw_tc_remove "$old_cid" 2>/dev/null || true
        fi
        db_reauth_session "$voucher" "$client_ip"

    else
        # 4. No session exists -> First Punch
        local v_pkg_id v_down v_up v_limit v_dur v_valid v_tstart v_tend
        v_pkg_id=$(printf '%s' "$v_data" | cut -d'|' -f1)
        v_down=$(printf '%s' "$v_data" | cut -d'|' -f2)
        v_up=$(printf '%s' "$v_data" | cut -d'|' -f3)
        v_limit=$(printf '%s' "$v_data" | cut -d'|' -f4)
        v_dur=$(printf '%s' "$v_data" | cut -d'|' -f5)
        v_valid=$(printf '%s' "$v_data" | cut -d'|' -f6)
        v_tstart=$(printf '%s' "$v_data" | cut -d'|' -f7)
        v_tend=$(printf '%s' "$v_data" | cut -d'|' -f8)

        # Time block check natively
        if ! check_time_block "$v_tstart" "$v_tend" "$now_hm"; then
            local ts_fmt te_fmt msg
            ts_fmt=$(format_time "$v_tstart")
            te_fmt=$(format_time "$v_tend")
            msg="Access is restricted between $ts_fmt and $te_fmt."
            json_error "TIME_BLOCKED" "$msg" "\"time_start\":\"$ts_fmt\",\"time_end\":\"$te_fmt\""
            return
        fi

        # Absolute expiry check before punch
        if [ "$v_valid" -gt 0 ] && [ "$v_valid" -le "$now_epoch" ]; then
            json_error "VOUCHER_EXHAUSTED" "This voucher has expired."
            sw_log "WARN" "AUTH REJECT: voucher '$voucher' absolute expiry reached before punch"
            return
        fi

        # [FIX H2] All validation passed — now safe to reset rate limit
        db_upsert_rate_limit "$client_mac" 0 0 "Success"

        # [FIX M11] Fetch existing class_id before we deactivate the old session so we can remove its TC class
        local existing_cid
        existing_cid=$(db_get_class_id_by_mac "$client_mac")

        local old_voucher
        old_voucher=$(db_get_voucher_code_by_mac "$client_mac")
        if [ -n "$old_voucher" ] && [ "$old_voucher" != "$voucher" ]; then
            db_remove_active_session_by_code "$old_voucher"
            sw_log "INFO" "AUTH SWITCH: mac=$client_mac released old voucher '$old_voucher' in favor of '$voucher'"
        fi

        db_deactivate_session_by_mac "$client_mac"
        sw_tc_remove_by_ip "$client_ip" 2>/dev/null || true
        
        # Now safe to remove the specific old TC class if it existed
        if [ -n "$existing_cid" ] && [ "$existing_cid" != "NULL" ]; then
            sw_tc_remove "$existing_cid" 2>/dev/null || true
        fi
        
        rows_changed=$(db_first_punch_session "$voucher" "$client_mac" "$client_ip" "$now_epoch")
        if [ "${rows_changed:-0}" -eq 0 ]; then
            json_error "SYSTEM_ERROR" "Failed to activate session."
            return
        fi
    fi

    # 5. Apply Firewall & TC rules
    local class_id
    class_id=$(db_assign_class_id "$voucher")

    local rate_down rate_up s_limit s_cum s_expires tmo
    if [ -n "$s_data" ]; then
        rate_down=$s_down
        rate_up=$s_up
        s_limit=$s_limit
        s_cum=$s_cum
        s_expires=$s_expires
        tmo=$(printf '%s' "$s_data" | cut -d'|' -f13)
    else
        local final_s_data
        final_s_data=$(db_get_session_by_voucher "$voucher")
        rate_down=$(printf '%s' "$final_s_data" | cut -d'|' -f5)
        rate_up=$(printf '%s' "$final_s_data" | cut -d'|' -f6)
        s_limit=$(printf '%s' "$final_s_data" | cut -d'|' -f7)
        s_cum=$(printf '%s' "$final_s_data" | cut -d'|' -f8)
        s_expires=$(printf '%s' "$final_s_data" | cut -d'|' -f10)
        tmo=$(printf '%s' "$final_s_data" | cut -d'|' -f13)
    fi

    [ -z "$rate_down" ] && rate_down=2048
    [ -z "$rate_up" ] && rate_up=1024
    [ -z "$s_limit" ] && s_limit=0
    [ -z "$s_cum" ] && s_cum=0
    [ -z "$s_expires" ] && s_expires=0

    sw_tc_remove "$class_id" 2>/dev/null
    sw_tc_apply "$client_mac" "$client_ip" "$rate_down" "$rate_up" "$class_id" || {
        json_error "TC_ERROR" "Failed to allocate bandwidth class"
        return
    }
    [ -z "$tmo" ] && tmo=86400
    sw_fw_auth "$client_mac" "$client_ip" "$tmo"

    sw_log "INFO" "AUTH SUCCESS: $client_mac ($client_ip) with '$voucher' (Class: $class_id)"

    local rem_bytes
    if [ -n "$s_limit" ] && [ "$s_limit" -gt 0 ]; then
        rem_bytes=$((s_limit - s_cum))
        [ "$rem_bytes" -lt 0 ] && rem_bytes=0
    fi

    local rem_min=0
    if [ "$s_expires" -gt 0 ]; then
        local now_epoch=$(date    +%s)
        rem_min=$(( (s_expires - now_epoch) / 60 ))
        [ "$rem_min" -lt 0 ] && rem_min=0
    elif [ "$v_dur" -gt 0 ]; then
        rem_min=$v_dur
    fi

    printf 'Content-Type: application/json\r\nCache-Control: no-store\r\n\r\n'
    printf '{"status":"ok","message":"Connected successfully","bound_voucher":"%s","voucher":"%s","rate_down_kbps":%d,"rate_up_kbps":%d,"remaining_bytes":%s,"remaining_min":%d,"redirect":"%s"}\n' "$voucher" "$voucher" "${rate_down:-0}" "${rate_up:-0}" "${rem_bytes:-null}" "${rem_min:-0}" "$SUCCESS_URL"
}

REQUEST_METHOD="${REQUEST_METHOD:-GET}"
QUERY_STRING="${QUERY_STRING:-}"

action=$(printf '%s' "$QUERY_STRING" | grep -o 'action=[^&]*' | cut -d= -f2)

if [ "$REQUEST_METHOD" = "POST" ]; then
    case "$action" in
        logout)   handle_logout ;;
        *)        handle_auth ;;
    esac
else
    case "$action" in
        capport)  handle_capport_api "$REMOTE_ADDR" ;;
        logout)   handle_logout ;;
        packages) handle_packages_api ;;
        page|*)   handle_page ;;
    esac
fi
