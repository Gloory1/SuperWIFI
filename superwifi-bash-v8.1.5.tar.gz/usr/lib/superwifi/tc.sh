#!/bin/sh
# /usr/lib/superwifi/tc.sh
# MAC-centric traffic shaping with unique DB-allocated class_id

. /usr/lib/superwifi/core.sh
. /usr/lib/superwifi/db-queries.sh

sw_tc_ensure_root() {
    tc qdisc show dev "$LAN_IFACE" 2>/dev/null | grep -q "htb" || \
        tc qdisc add dev "$LAN_IFACE" root handle 1: htb default 9999 2>/dev/null
}

sw_tc_apply() {
    local mac="$1"
    local ip="$2"
    local rate_down="$3"
    local rate_up="$4"
    local class_id="$5"

    validate_mac "$mac" || return 1
    validate_ip "$ip" || return 1
    rate_down=$(printf '%s' "$rate_down" | tr -dc '0-9')
    rate_up=$(printf '%s' "$rate_up" | tr -dc '0-9')
    class_id=$(printf '%s' "$class_id" | tr -dc '0-9')
    [ -z "$rate_down" ] || [ "$rate_down" -eq 0 ] && rate_down=1000000
    [ -z "$rate_up" ] || [ "$rate_up" -eq 0 ] && rate_up=1000000
    [ -z "$class_id" ] && return 1

    local burst_bytes=$(( TC_BURST_KB * 1024 ))
    local sfq_handle
    sfq_handle=$(printf '%x' "$class_id" 2>/dev/null)

    sw_tc_ensure_root

    tc class replace dev "$LAN_IFACE" parent 1: classid "1:${class_id}" \
        htb rate "${rate_down}kbit" ceil "${rate_down}kbit" \
        burst "${burst_bytes}" cburst "${burst_bytes}" 2>/dev/null || {
        sw_log "ERROR" "tc: failed to add class 1:${class_id} for $mac"
        return 1
    }

    tc qdisc replace dev "$LAN_IFACE" parent "1:${class_id}" \
        handle "${sfq_handle}:" sfq perturb 10 2>/dev/null || true

    tc filter del dev "$LAN_IFACE" parent 1: protocol ip prio 1 u32 match ip dst "${ip}/32" 2>/dev/null || true
    tc filter add dev "$LAN_IFACE" parent 1: protocol ip prio 1 \
        u32 match ip dst "${ip}/32" flowid "1:${class_id}" 2>/dev/null || true

    tc filter del dev "$LAN_IFACE" parent 1: protocol ip prio 2 u32 match ip src "${ip}/32" 2>/dev/null || true
    tc filter add dev "$LAN_IFACE" parent 1: protocol ip prio 2 \
        u32 match ip src "${ip}/32" flowid "1:${class_id}" 2>/dev/null || true
}

sw_tc_remove() {
    local class_id="$1"
    [ -z "$class_id" ] && return 0
    tc class del dev "$LAN_IFACE" parent 1: classid "1:${class_id}" 2>/dev/null || true
}

sw_tc_remove_by_ip() {
    local ip="$1"
    validate_ip "$ip" || return 0
    tc filter del dev "$LAN_IFACE" parent 1: protocol ip prio 1 \
        u32 match ip dst "${ip}/32" 2>/dev/null || true
    tc filter del dev "$LAN_IFACE" parent 1: protocol ip prio 2 \
        u32 match ip src "${ip}/32" 2>/dev/null || true
    local cid
    cid=$(db_query "SELECT class_id FROM session WHERE bound_ip='${ip}' ORDER BY id DESC LIMIT 1;")
    if [ -n "$cid" ] && [ "$cid" != "NULL" ]; then
        tc class del dev "$LAN_IFACE" parent 1: classid "1:${cid}" 2>/dev/null || true
    fi
}

sw_tc_rebuild_filters() {
    sw_tc_ensure_root
    db_get_all_active_sessions | \
    while IFS='|' read -r s_mac s_ip s_rate_down s_rate_up s_class_id; do
        [ -z "$s_mac" ] || [ -z "$s_ip" ] && continue
        [ -z "$s_class_id" ] && continue
        sw_tc_apply "$s_mac" "$s_ip" "${s_rate_down:-2048}" "${s_rate_up:-1024}" "$s_class_id" 2>/dev/null || true
    done
}
