#!/bin/sh
# /usr/lib/superwifi/dhcp-restore-hook.sh
# dnsmasq dhcp-script hook for lazy session restore on DHCP lease events.
#
# Arguments passed by dnsmasq:
#   $1 = action (add | del | old)
#   $2 = MAC address
#   $3 = IP address
#   $4 = hostname (optional)
#
# Integration: Registered in /etc/dnsmasq.d/superwifi.conf via:
#   dhcp-script=/usr/lib/superwifi/dhcp-restore-hook.sh
#
# Behavior:
#   - Checks UCI option superwifi.core.restore_mode.
#   - If 'eager' (or default/absent), immediately exits 0 (no-op).
#   - If 'lazy', looks up MAC in DB (v_restore view). If a valid active session exists
#     and mac.ip is not yet present in the live 'authenticated' nft set, restores session on-demand.

. /usr/lib/superwifi/core.sh
. /usr/lib/superwifi/db-queries.sh
. /usr/lib/superwifi/tc.sh
. /usr/lib/superwifi/fw.sh

ACTION="$1"
MAC="$2"
IP="$3"

# Only handle lease assignment and renewal events (add / old)
[ "$ACTION" = "add" ] || [ "$ACTION" = "old" ] || exit 0
[ -z "$MAC" ] || [ -z "$IP" ] && exit 0

# Check restore_mode — no-op immediately if eager
RESTORE_MODE=$(uci get superwifi.core.restore_mode 2>/dev/null || echo "lazy")
[ "$RESTORE_MODE" = "lazy" ] || exit 0

validate_mac "$MAC" || exit 0
validate_ip "$IP" || exit 0

sw_db_init || exit 0

# Look up active session for this MAC in DB
SESSION_INFO=$(db_get_restore_session_by_mac "$MAC")
[ -z "$SESSION_INFO" ] && exit 0

# Check if this MAC.IP is already in live 'authenticated' nft set
if nft get element inet superwifi authenticated "{ ${MAC} . ${IP} }" >/dev/null 2>&1; then
    exit 0
fi

# Parse session details: bound_mac|bound_ip|rate_down|rate_up|class_id|expires_at|data_limit|cum_usage
IFS='|' read -r s_mac s_ip rate_down rate_up class_id expires_at data_limit cum_usage <<EOF
$SESSION_INFO
EOF

# Perform single-session restore
if sw_restore_one_session "$MAC" "$IP" "$rate_down" "$rate_up" "$class_id" "$expires_at"; then
    sw_log "INFO" "dhcp-restore-hook: lazy restored session for mac=$MAC ip=$IP (class_id=$class_id)"
fi

exit 0
