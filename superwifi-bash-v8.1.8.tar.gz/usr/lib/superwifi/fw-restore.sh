#!/bin/sh
# /usr/lib/superwifi/fw-restore.sh
# Called by firewall include after fw4 reload: restores nftables + tc state.
# NOTE: /etc/fw4.d/ is unsupported in firewall4. Install via:
#   uci add firewall include
#   uci set firewall.@include[-1].path='/usr/lib/superwifi/fw-restore.sh'
#   uci commit firewall

. /usr/lib/superwifi/core.sh
. /usr/lib/superwifi/db-queries.sh
. /usr/lib/superwifi/tc.sh
. /usr/lib/superwifi/fw.sh

sw_db_init || exit 1

RESTORE_MODE=$(uci get superwifi.core.restore_mode 2>/dev/null || echo "lazy")
sw_log "INFO" "fw-restore: starting session restore after firewall reload (mode=${RESTORE_MODE})"

TMPNFT=$(mktemp)
[ -z "$TMPNFT" ] && { sw_log "FATAL" "fw-restore: cannot create tempfile"; exit 1; }

BYPASS_ELEMENTS=$(gen_bypass_elements)
if [ -n "$BYPASS_ELEMENTS" ]; then
    BYPASS_BLOCK="elements = { ${BYPASS_ELEMENTS} }"
else
    BYPASS_BLOCK=""
fi

    sed \
        -e "s/%%LAN_IFACE%%/${LAN_IFACE}/g" \
        -e "s/%%PORTAL_IP%%/${PORTAL_IP}/g" \
        -e "s|%%BYPASS_MACS_BLOCK%%|${BYPASS_BLOCK}|g" \
        /etc/superwifi/superwifi.nft.tpl > "$TMPNFT"

nft -f "$TMPNFT" 2>/dev/null || {
    sw_log "ERROR" "fw-restore: failed to load nft table"
    rm -f "$TMPNFT"
    exit 1
}
rm -f "$TMPNFT"

nft list table inet superwifi >/dev/null 2>&1 || {
    sw_log "ERROR" "fw-restore: nft table inet superwifi not found after load"
    exit 1
}

sw_tc_rebuild_filters

# Quarantined MACs are always restored eagerly for security
db_get_all_quarantined_macs | \
while read -r mac; do
    [ -z "$mac" ] && continue
    validate_mac "$mac" || continue
    nft add element inet superwifi quarantined "{ ${mac} }" 2>/dev/null || true
done

if [ "$RESTORE_MODE" = "lazy" ]; then
    sw_log "INFO" "fw-restore: lazy restore mode active — skipping bulk per-session restore"
else
    RST_TMP=$(mktemp) || exit 1
    db_get_restore_sessions > "$RST_TMP"
    COUNT=$(wc -l < "$RST_TMP")
    while IFS='|' read -r mac ip rate_down rate_up class_id expires_at data_limit cum_usage; do
        sw_restore_one_session "$mac" "$ip" "$rate_down" "$rate_up" "$class_id" "$expires_at"
    done < "$RST_TMP"
    rm -f "$RST_TMP"
    sw_log "INFO" "fw-restore: restored ${COUNT} sessions (eager mode)"
fi

