#!/bin/sh

NUM_DEVICES=${1:-100}
echo "🚀 Starting REALISTIC Stress Test with $NUM_DEVICES devices..."

. /usr/lib/superwifi/core.sh
. /usr/lib/superwifi/db.sh
sw_db_init || exit 1

# Make sure base tc is initialized
tc qdisc del dev "$LAN_IFACE" root 2>/dev/null
tc qdisc add dev "$LAN_IFACE" root handle 1: htb default 9999
tc class add dev "$LAN_IFACE" parent 1: classid 1:1 htb rate 1000mbit ceil 1000mbit

START_TIME=$(date +%s)

for i in $(seq 1 $NUM_DEVICES); do
    # Generate random MAC and IP (e.g., 10.0.X.Y)
    hex1=$(printf "%02x" $((i % 256)))
    hex2=$(printf "%02x" $(( (i / 256) % 256 )))
    MAC="00:11:22:33:$hex2:$hex1"
    IP="10.0.$(( (i / 256) % 256 )).$((i % 256))"
    VOUCHER="REALSTRESS-$i"
    class_id=$(( i + 10 ))
    
    # 1. Insert into Database
    sqlite3 "$DB_PATH" "
    INSERT OR IGNORE INTO voucher (code, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min) VALUES ('$VOUCHER', 3000, 3000, 20971520, 60);
    INSERT INTO session (voucher_code, bound_mac, bound_ip, status, class_id, rate_down_kbps, rate_up_kbps, data_limit_bytes, punched_at, last_seen_at) VALUES ('$VOUCHER', '$MAC', '$IP', 'active', $class_id, 3000, 3000, 20971520, strftime('%s','now'), strftime('%s','now'));"
    # 2. Add to Nftables (Firewall)
    nft add element inet superwifi authenticated "{ $MAC . $IP }" 2>/dev/null
    
    # 3. Add to Traffic Control (QoS)
    # Using raw tc commands for speed to avoid loading shell env overhead per iteration
    tc class add dev "$LAN_IFACE" parent 1:1 classid 1:$class_id htb rate 3000kbit ceil 3000kbit 2>/dev/null
    tc qdisc add dev "$LAN_IFACE" parent 1:$class_id handle $class_id: sfq perturb 10 2>/dev/null
    tc filter add dev "$LAN_IFACE" protocol ip parent 1:0 prio 1 u32 match ip dst "$IP" flowid 1:$class_id 2>/dev/null
    tc filter add dev "$LAN_IFACE" protocol ip parent 1:0 prio 1 u32 match ip src "$IP" flowid 1:$class_id 2>/dev/null
    
    if [ $((i % 50)) -eq 0 ]; then
        echo "   ... Provisioned $i devices"
    fi
done

END_TIME=$(date +%s)
echo "✅ Provisioning completed in $((END_TIME - START_TIME)) seconds."
echo ""
echo "📊 Current System Load:"
uptime
echo ""
echo "🏃 Testing sw-sync.sh execution time under full load..."
time /usr/sbin/sw-sync.sh

echo ""
echo "🧹 To clean up this mess later, restart the router or run: /etc/init.d/superwifi restart"
