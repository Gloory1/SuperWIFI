#!/bin/sh
# /usr/lib/superwifi/db-queries.sh
# SuperWiFi Core Unified SQL Layer
# Fully optimized for the split Voucher/Session schema using epoch timestamps.

. /usr/lib/superwifi/db.sh

# ==============================================================================
# Section 0 — System Configuration
# ==============================================================================

db_get_firmware_version() {
    db_query "SELECT value FROM system_config WHERE key='firmware_version' LIMIT 1;"
}

db_set_firmware_version() {
    local version=$(db_escape "$1")
    db_query "UPDATE system_config SET value='${version}', updated_at=$(date +%s) WHERE key='firmware_version';" >/dev/null 2>&1
}

# ==============================================================================
# Section 1 — Voucher Definitions (Cold Data)
# ==============================================================================

db_get_voucher_definition() {
    local code=$(db_escape "$1")
    db_query "SELECT package_id, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, valid_until, time_block_start, time_block_end FROM voucher WHERE code='${code}' LIMIT 1;"
}

db_voucher_exists() {
    local code=$(db_escape "$1")
    db_query "SELECT 1 FROM voucher WHERE code='${code}' LIMIT 1;"
}

db_insert_voucher() {
    local code=$(db_escape "$1")
    local pkg_id=$(db_escape "$2")
    local dl=$(db_escape "$3")
    local ul=$(db_escape "$4")
    local data=$(db_escape "$5")
    local dur=$(db_escape "$6")
    local valid=$(db_escape "$7")
    local valid_str="0"
    
    # If user provides a datetime string instead of epoch, we can't cleanly parse in pure shell without date command, 
    # but let's assume valid is either 'NULL', '0' or an epoch integer in schema. 
    # For backwards compatibility with v4 API payload (e.g. valid_until='2024-12-31 00:00:00'), 
    # we convert it using sqlite's strftime if it contains a dash.
    if [ "$valid" != "NULL" ] && [ -n "$valid" ] && [ "$valid" != "0" ]; then
        if echo "$valid" | grep -qE '^[0-9]{4}-[0-9]{2}-[0-9]{2}( [0-9]{2}:[0-9]{2}:[0-9]{2})?$'; then
            valid_str="(strftime('%s', '${valid}'))"
        elif echo "$valid" | grep -qE '^[0-9]+$'; then
            valid_str="${valid}"
        else
            valid_str="0"
        fi
    fi

    if [ -z "$pkg_id" ] || [ "$pkg_id" = "NULL" ]; then
        pkg_id="NULL"
    fi

    db_query "INSERT INTO voucher (code, package_id, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, valid_until) VALUES ('${code}', ${pkg_id}, ${dl}, ${ul}, ${data}, ${dur}, ${valid_str});"
    return 0
}

db_count_used_vouchers() {
    db_query "SELECT COUNT(DISTINCT voucher_code) FROM session;"
}

db_count_unused_vouchers() {
    db_query "SELECT COUNT(*) FROM voucher WHERE code NOT IN (SELECT voucher_code FROM session);"
}


# ==============================================================================
# Section 5 — Sentinel Helpers
# ==============================================================================

db_get_all_active_sessions() {
    db_query "SELECT bound_mac, bound_ip, rate_down_kbps, rate_up_kbps, class_id FROM session WHERE status='active';"
}

db_get_class_id_by_voucher() {
    local code=$(db_escape "$1")
    db_query "SELECT class_id FROM session WHERE voucher_code='${code}' AND status='active' LIMIT 1;"
}

db_get_class_id_by_ip() {
    local ip=$(db_escape "$1")
    db_query "SELECT class_id FROM session WHERE bound_ip='${ip}' AND status='active' LIMIT 1;"
}

db_deactivate_voucher_by_code() {
    local code=$(db_escape "$1")
    db_query "UPDATE session SET status='expired', class_id=NULL WHERE voucher_code='${code}';"
}

# ==============================================================================
# Section 2 — Session State (Hot Data)
# ==============================================================================

# auth.sh uses this to check if a session exists and its status
db_get_session_by_voucher() {
    local code=$(db_escape "$1")
    db_query "
        SELECT 
            id, bound_mac, bound_ip, status, rate_down_kbps, rate_up_kbps, 
            data_limit_bytes, cumulative_usage_bytes, punched_at, expires_at, 
            time_block_start, time_block_end,
            CASE 
                WHEN expires_at > 0 AND expires_at > strftime('%s','now') THEN expires_at - strftime('%s','now')
                WHEN expires_at > 0 THEN 60
                ELSE 86400
            END AS timeout_sec
        FROM session WHERE voucher_code='${code}' LIMIT 1;
    "
}

db_get_session_status() {
    local code=$(db_escape "$1")
    db_query "SELECT status FROM session WHERE voucher_code='${code}' LIMIT 1;"
}

db_first_punch_session() {
    local code=$(db_escape "$1")
    local mac=$(db_escape "$2")
    local ip=$(db_escape "$3")
    local now=$(db_escape "$4") # Unix epoch expected
    
    # This queries the voucher, computes expires_at natively in sqlite, and inserts the session in one step
    db_query "
    INSERT INTO session (voucher_code, bound_mac, bound_ip, status, rate_down_kbps, rate_up_kbps, data_limit_bytes, time_block_start, time_block_end, punched_at, expires_at, last_seen_at)
    SELECT 
        code, 
        '${mac}', 
        '${ip}', 
        'active', 
        rate_down_kbps, 
        rate_up_kbps, 
        data_limit_bytes, 
        time_block_start, 
        time_block_end, 
        ${now}, 
        CASE 
            WHEN duration_min > 0 AND valid_until > 0 THEN MIN(valid_until, ${now} + (duration_min * 60))
            WHEN duration_min > 0 THEN ${now} + (duration_min * 60)
            WHEN valid_until > 0 THEN valid_until
            ELSE 0
        END,
        ${now}
    FROM voucher 
    WHERE code='${code}' AND NOT EXISTS (SELECT 1 FROM session WHERE voucher_code='${code}');
    SELECT changes();"
}

db_reauth_session() {
    local code=$(db_escape "$1")
    local ip=$(db_escape "$2")
    # [FIX] Do NOT call db_assign_class_id here — class_id assignment is done
    # in auth.sh step 5 right before sw_tc_apply to keep assignment and TC setup atomic.
    # Calling it here caused a race/double-assignment that could result in class_id mismatch.
    db_query "UPDATE session SET status='active', bound_ip='${ip}', season_usage_bytes=0, last_seen_at=strftime('%s','now') WHERE voucher_code='${code}';"
}

db_deactivate_session_by_code() {
    local code=$(db_escape "$1")
    db_query "UPDATE session SET status='disconnected', class_id=NULL, last_seen_at=strftime('%s','now') WHERE voucher_code='${code}';"
}

db_deactivate_session_by_mac() {
    local mac=$(db_escape "$1")
    db_query "UPDATE session SET status='disconnected', class_id=NULL, last_seen_at=strftime('%s','now') WHERE bound_mac='${mac}';"
}

db_remove_active_session_by_code() {
    local code=$(db_escape "$1")
    db_query "UPDATE session SET status='disconnected', bound_mac=NULL, bound_ip=NULL, class_id=NULL, last_seen_at=strftime('%s','now') WHERE voucher_code='${code}';"
}

db_get_history_by_mac() {
    local mac=$(db_escape "$1")
    db_query "
        SELECT json_group_array(json_object(
            'voucher', s.voucher_code,
            'status', CASE WHEN s.status = 'active' THEN 'Active' ELSE 'Expired' END,
            'used_kb', s.cumulative_usage_bytes / 1024,
            'limit_kb', s.data_limit_bytes / 1024,
            'duration_min', IFNULL(v.duration_min, 0),
            'price_cent', IFNULL(p.price_cents, 0)
        ))
        FROM (
            SELECT voucher_code, status, cumulative_usage_bytes, data_limit_bytes, last_seen_at
            FROM session
            WHERE bound_mac='${mac}'
            ORDER BY last_seen_at DESC
            LIMIT 10
        ) s
        LEFT JOIN voucher v ON s.voucher_code = v.code
        LEFT JOIN package p ON v.package_id = p.id;
    "
}

db_get_session_mac_by_ip() {
    local ip=$(db_escape "$1")
    db_query "SELECT bound_mac FROM v_active WHERE bound_ip='${ip}' LIMIT 1;"
}

db_get_session_ip_by_mac() {
    local mac=$(db_escape "$1")
    db_query "SELECT bound_ip FROM v_active WHERE bound_mac='${mac}' LIMIT 1;"
}

db_get_session_mac_by_voucher() {
    local code=$(db_escape "$1")
    db_query "SELECT bound_mac FROM session WHERE voucher_code='${code}' LIMIT 1;"
}

db_get_session_ip_by_voucher() {
    local code=$(db_escape "$1")
    db_query "SELECT bound_ip FROM session WHERE voucher_code='${code}' LIMIT 1;"
}

db_get_remaining_bytes_by_mac() {
    local mac=$(db_escape "$1")
    db_query "SELECT remaining_bytes FROM v_quota WHERE bound_mac='${mac}' LIMIT 1;"
}

db_count_active_sessions() {
    db_query "SELECT COUNT(*) FROM v_active;"
}

# ==============================================================================
# Section 3 — TC Class ID Queries
# ==============================================================================

db_get_tc_params_by_voucher() {
    local code=$(db_escape "$1")
    db_query "SELECT rate_down_kbps, rate_up_kbps, class_id FROM session WHERE voucher_code='${code}' LIMIT 1;"
}

db_assign_class_id() {
    local code=$(db_escape "$1")
    local cid
    cid=$(db_query "SELECT class_id FROM session WHERE voucher_code='${code}' LIMIT 1;")
    if [ -n "$cid" ] && [ "$cid" != "NULL" ] && [ "$cid" -gt 0 ] 2>/dev/null; then
        printf '%s' "$cid"
        return 0
    fi
    local new_id=""
    local attempts=0
    while [ "$attempts" -lt 3 ]; do
        new_id=$(sqlite3 -cmd ".timeout 5000" "$DB_PATH" 2>/dev/null <<-EOSQL
            BEGIN EXCLUSIVE;
            UPDATE session SET class_id = (
                SELECT COALESCE(MIN(t1.class_id + 1), 1000)
                FROM session t1
                LEFT JOIN session t2 ON t1.class_id + 1 = t2.class_id
                WHERE t2.class_id IS NULL AND t1.class_id >= 1000
            ) WHERE voucher_code = '${code}' AND (class_id IS NULL OR class_id = 0);
            SELECT class_id FROM session WHERE voucher_code = '${code}';
            COMMIT;
EOSQL
        )
        if [ -n "$new_id" ] && [ "$new_id" != "NULL" ]; then
            break
        fi
        attempts=$((attempts + 1))
        sleep 0.1
    done
    if [ -z "$new_id" ] || [ "$new_id" = "NULL" ]; then
        # Fallback if the gap-finding fails for some reason
        new_id=$(sqlite3 -cmd ".timeout 5000" "$DB_PATH" 2>/dev/null <<-EOSQL
            BEGIN EXCLUSIVE;
            UPDATE session SET class_id = COALESCE((SELECT MAX(class_id) + 1 FROM session WHERE class_id IS NOT NULL), 1000) WHERE voucher_code = '${code}' AND (class_id IS NULL OR class_id = 0);
            SELECT class_id FROM session WHERE voucher_code = '${code}';
            COMMIT;
EOSQL
        )
        [ -z "$new_id" ] && new_id=1000
    fi
    printf '%s' "$new_id"
}

db_get_class_id_by_mac() {
    local mac=$(db_escape "$1")
    db_query "SELECT class_id FROM v_active WHERE bound_mac='${mac}' LIMIT 1;"
}

# Reset voucher MAC
db_reset_voucher_mac() {
    local code=$(db_escape "$1")
    db_query "UPDATE session SET bound_mac='', status='disconnected', class_id=NULL, last_seen_at=strftime('%s','now') WHERE voucher_code='${code}';" >/dev/null 2>&1
}

# Rebind voucher MAC
db_rebind_session_mac_ip() {
    local code=$(db_escape "$1")
    local mac=$(db_escape "$2")
    local ip=$(db_escape "$3")
    db_query "UPDATE session SET bound_mac='${mac}', bound_ip='${ip}', last_seen_at=strftime('%s','now') WHERE voucher_code='${code}';" >/dev/null 2>&1
}

db_release_class_id() {
    local code=$(db_escape "$1")
    db_query "UPDATE session SET class_id=NULL WHERE voucher_code='${code}';"
}

# ==============================================================================
# Section 4 — Accounting
# ==============================================================================

db_get_accounting_targets() {
    db_query "SELECT bound_mac, bound_ip, voucher_code, rate_down_kbps, rate_up_kbps, data_limit_bytes, cumulative_usage_bytes, season_usage_bytes, class_id, is_expired, is_time_blocked FROM v_acct_target;"
}

db_update_usage_season_sql() {
    local code=$(db_escape "$1")
    local curr_bytes=$(db_escape "$2")
    local delta_bytes=$(db_escape "$3")
    printf "UPDATE session SET cumulative_usage_bytes = cumulative_usage_bytes + %s, season_usage_bytes = %s, last_seen_at = strftime('%%s','now') WHERE voucher_code = '%s';\n" "${delta_bytes:-0}" "${curr_bytes:-0}" "${code}"
}

db_insert_accounting_log_sql() {
    local code=$(db_escape "$1")
    local mac=$(db_escape "$2")
    local delta=$(db_escape "$3")
    local cycle_epoch=$(db_escape "$4") # Unix epoch
    printf "INSERT INTO acct_log (session_id, mac, delta_bytes, logged_at) SELECT id, '${mac}', ${delta}, ${cycle_epoch} FROM session WHERE voucher_code='${code}';\n"
}

db_get_total_usage_by_mac() {
    local mac=$(db_escape "$1")
    db_query "SELECT cumulative_usage_bytes FROM session WHERE bound_mac='${mac}' LIMIT 1;"
}

db_expire_session_by_code() {
    local code=$(db_escape "$1")
    db_query "UPDATE session SET status='expired', class_id=NULL, last_seen_at=strftime('%s','now') WHERE voucher_code='${code}';"
}

db_expire_session_sql() {
    local code=$(db_escape "$1")
    printf "UPDATE session SET status='expired', class_id=NULL, last_seen_at=strftime('%%s','now') WHERE voucher_code='${code}';\n"
}

# ==============================================================================
# Section 6 — Quarantine
# ==============================================================================

db_count_quarantined_sessions() {
    db_query "SELECT COUNT(*) FROM v_quarantined;"
}

db_quarantine_mac_sql() {
    local mac=$(db_escape "$1")
    local reason=$(db_escape "$2")
    printf "UPDATE session SET status='quarantined', class_id=NULL, quarantine_reason='${reason}', last_seen_at=strftime('%%s','now') WHERE bound_mac='${mac}';\n"
}

db_quarantine_mac() {
    local mac=$(db_escape "$1")
    local reason=$(db_escape "$2")
    db_query "UPDATE session SET status='quarantined', class_id=NULL, quarantine_reason='${reason}', last_seen_at=strftime('%s','now') WHERE bound_mac='${mac}';"
}

db_insert_quarantine_log_sql() {
    local mac=$(db_escape "$1")
    local code=$(db_escape "$2")
    local reason=$(db_escape "$3")
    local delta=$(db_escape "$4")
    local threshold=$(db_escape "$5")
    local code_str="NULL"
    [ -n "$code" ] && code_str="'${code}'"
    printf "INSERT INTO quarantine_event (mac, voucher_code, reason, delta_bytes, threshold_bytes) VALUES ('${mac}', ${code_str}, '${reason}', ${delta}, ${threshold});\n"
}

db_unquarantine_mac() {
    local mac=$(db_escape "$1")
    db_query "UPDATE session SET status='disconnected', class_id=NULL, quarantine_reason=NULL WHERE bound_mac='${mac}' AND status='quarantined';"
}

db_quarantine_voucher() {
    local code=$(db_escape "$1")
    local reason=$(db_escape "${2:-manual}")
    db_query "UPDATE session SET status='quarantined', class_id=NULL, quarantine_reason='${reason}', last_seen_at=strftime('%s','now') WHERE voucher_code='${code}';"
}

db_unquarantine_voucher() {
    local code=$(db_escape "$1")
    db_query "UPDATE session SET status='disconnected', class_id=NULL, quarantine_reason=NULL, last_seen_at=strftime('%s','now') WHERE voucher_code='${code}' AND status='quarantined';"
}

db_is_quarantined_mac() {
    local mac=$(db_escape "$1")
    db_query "SELECT 1 FROM session WHERE bound_mac='${mac}' AND status='quarantined' LIMIT 1;"
}

# ==============================================================================
# Section 7 — Cloud Sync Engine
# ==============================================================================

# Push: Get all vouchers that changed since last sync
db_supabase_get_sync_vouchers_json() {
    printf "[]"
}

# Push: Get all sessions that changed since last sync
db_supabase_get_sync_sessions_json() {
    db_query "
        SELECT json_group_array(json_object(
            'voucher_code', voucher_code,
            'bound_mac', bound_mac,
            'bound_ip', bound_ip,
            'status', status,
            'cumulative_usage_bytes', cumulative_usage_bytes,
            'season_usage_bytes', season_usage_bytes,
            'punched_at', punched_at,
            'expires_at', expires_at,
            'last_seen_at', last_seen_at
        )) FROM session 
        WHERE last_sync_at IS NULL OR last_seen_at > last_sync_at;
    "
}

# Mark as synced
db_supabase_mark_all_synced() {
    local epoch="$1"
    # [FIX M4] Validate epoch is a positive integer before inserting into SQL
    epoch=$(printf '%s' "$epoch" | tr -dc '0-9')
    [ -z "$epoch" ] || [ "$epoch" -eq 0 ] && return 1
    db_query "
        UPDATE session SET last_sync_at = ${epoch} WHERE last_sync_at IS NULL OR last_seen_at IS NULL OR last_seen_at <= ${epoch};
        INSERT OR REPLACE INTO system_config (key, value, updated_at) VALUES ('last_cloud_sync_at', '${epoch}', ${epoch});
    " >/dev/null 2>&1
}

# Pull: Insert Package
db_supabase_insert_downloaded_package() {
    local id=$(db_escape "$1")
    local name=$(db_escape "$2")
    local down=$(db_escape "$3")
    local up=$(db_escape "$4")
    local limit=$(db_escape "$5")
    local time_limit=$(db_escape "$6")
    local is_active=$(db_escape "$7")
    local price_cents=$(db_escape "$8")
    local tb_start_raw=$(db_escape "$9")
    local tb_end_raw=$(db_escape "${10}")
    
    local tb_start=0
    local tb_end=0
    
    if [ -n "$tb_start_raw" ] && [ "$tb_start_raw" != "null" ]; then
        tb_start=$(echo "$tb_start_raw" | tr -d ':' | sed 's/^0*//')
        [ -z "$tb_start" ] && tb_start=0
    fi
    
    if [ -n "$tb_end_raw" ] && [ "$tb_end_raw" != "null" ]; then
        tb_end=$(echo "$tb_end_raw" | tr -d ':' | sed 's/^0*//')
        [ -z "$tb_end" ] && tb_end=0
    fi
    
    db_query "
        INSERT INTO package (id, name, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, is_visible, price_cents, time_block_start, time_block_end) 
        VALUES (${id}, '${name}', ${down}, ${up}, ${limit}, ${time_limit}, ${is_active}, ${price_cents}, ${tb_start}, ${tb_end})
        ON CONFLICT(id) DO UPDATE SET 
            name=excluded.name, 
            rate_down_kbps=excluded.rate_down_kbps, 
            rate_up_kbps=excluded.rate_up_kbps, 
            data_limit_bytes=excluded.data_limit_bytes, 
            duration_min=excluded.duration_min, 
            is_visible=excluded.is_visible,
            price_cents=excluded.price_cents,
            time_block_start=excluded.time_block_start,
            time_block_end=excluded.time_block_end;
    " >/dev/null 2>&1
}

# Pull: Insert Voucher
db_supabase_insert_downloaded_voucher() {
    local code=$(db_escape "$1")
    local pkg_id=$(db_escape "$2")
    local status=$(db_escape "$3")
    
    db_query "
        INSERT INTO voucher (code, package_id, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, time_block_start, time_block_end) 
        SELECT '${code}', ${pkg_id}, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, time_block_start, time_block_end
        FROM package WHERE id = ${pkg_id}
        ON CONFLICT(code) DO NOTHING;
    " >/dev/null 2>&1
}

# Pull: Delete Package (Soft Delete from Cloud)
db_supabase_delete_package() {
    local id=$(db_escape "$1")
    db_query "DELETE FROM package WHERE id=${id};" >/dev/null 2>&1
}

# Pull: Delete Voucher (Soft Delete from Cloud)
db_supabase_delete_voucher() {
    local code=$(db_escape "$1")
    db_query "
        DELETE FROM voucher WHERE code='${code}';
        DELETE FROM session WHERE voucher_code='${code}';
    " >/dev/null 2>&1
}

# ==============================================================================
# Section 8 — Rate Limiting & Admin
# ==============================================================================

db_upsert_rate_limit() {
    local mac=$(db_escape "$1")
    local fail_count=$(db_escape "$2")
    local block_until=$(db_escape "$3")
    local reason=$(db_escape "$4")
    db_query "INSERT OR REPLACE INTO rate_limit (mac, fail_count, window_start_at, blocked_until, reason) VALUES ('${mac}', ${fail_count}, strftime('%s','now'), ${block_until}, '${reason}');"
}

db_get_rate_limit() {
    local mac=$(db_escape "$1")
    db_query "SELECT fail_count, blocked_until FROM rate_limit WHERE mac='${mac}' LIMIT 1;"
}

# ==============================================================================
# Section 9 — Packages
# ==============================================================================

db_insert_package() {
    local name=$(db_escape "$1")
    local dl=$(db_escape "$2")
    local ul=$(db_escape "$3")
    local quota=$(db_escape "$4")
    local dur=$(db_escape "$5")
    local price=$(db_escape "$6")
    db_query "INSERT INTO package (name, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, price_cents, is_visible) VALUES ('${name}', ${dl}, ${ul}, ${quota}, ${dur}, ${price}, 1);"
}

db_delete_package() {
    local pkg_id=$(db_escape "$1")
    db_query "DELETE FROM package WHERE id=${pkg_id};"
}

db_get_package_info() {
    local pkg_id=$(db_escape "$1")
    db_query "SELECT rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, price_cents FROM package WHERE id=${pkg_id} LIMIT 1;"
}

db_list_packages() {
    db_query "SELECT id, name, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, price_cents, is_visible FROM package;"
}

db_get_packages_json() {
    db_query "SELECT json_group_array(json_object('package_id', id, 'name', name, 'rate_down_kbps', rate_down_kbps, 'rate_up_kbps', rate_up_kbps, 'data_limit_bytes', data_limit_bytes, 'duration_min', duration_min, 'price_sell_cent', price_cents)) FROM package WHERE is_visible=1;"
}

# ==============================================================================
# Section 10 — Maintenance
# ==============================================================================

db_maintenance_cleanup() {
    # Prune logs older than 7 days
    db_query "DELETE FROM acct_log WHERE logged_at < strftime('%s', 'now') - 604800;"
    # Prune rate limits that have expired
    db_query "DELETE FROM rate_limit WHERE blocked_until > 0 AND blocked_until < strftime('%s', 'now');"
    # Prune quarantine events older than 30 days
    db_query "DELETE FROM quarantine_event WHERE detected_at < strftime('%s', 'now') - 2592000;"
}

# ==============================================================================
# Section 11 — CLI & Diagnostics
# ==============================================================================

db_list_active_sessions() {
    # Returns epoch times for CLI to format natively
    db_query "SELECT bound_mac, bound_ip, voucher_code, rate_down_kbps, rate_up_kbps, cumulative_usage_bytes, data_limit_bytes, expires_at, punched_at, class_id FROM v_active ORDER BY last_seen_at DESC;"
}

db_get_restore_sessions() {
    db_query "SELECT bound_mac, bound_ip, rate_down_kbps, rate_up_kbps, class_id, expires_at, data_limit_bytes, cumulative_usage_bytes FROM v_restore;"
}

db_get_restore_session_by_mac() {
    local mac=$(db_escape "$1")
    # ORDER BY id DESC + LIMIT 1: in the unlikely event of more than one 'active'
    # row for the same MAC, always pick the most recently created session
    # (id is an autoincrement PK, so higher id = more recent), rather than
    # whichever row SQLite happens to return first.
    db_query "SELECT bound_mac, bound_ip, rate_down_kbps, rate_up_kbps, class_id, expires_at, data_limit_bytes, cumulative_usage_bytes FROM v_restore WHERE LOWER(bound_mac) = LOWER('${mac}') ORDER BY id DESC LIMIT 1;"
}

db_get_all_quarantined_macs() {
    db_query "SELECT bound_mac FROM v_quarantined;"
}

db_repair_active_sessions_class_id() {
    # 1. Reset season usage for ALL active sessions (for TC reset)
    db_query "UPDATE session SET season_usage_bytes = 0 WHERE status = 'active';" >/dev/null 2>&1

    # 2. Reset duplicate or invalid class_ids (NULL, 0, or legacy '1000' duplicates across active sessions)
    db_query "
        UPDATE session SET class_id = NULL 
        WHERE status = 'active' AND (
            class_id IS NULL OR class_id = 0 OR class_id = 1000 OR class_id IN (
                SELECT class_id FROM session WHERE status = 'active' AND class_id IS NOT NULL GROUP BY class_id HAVING COUNT(*) > 1
            )
        );
    " >/dev/null 2>&1

    # 3. Find any active sessions without a valid class_id and assign unique sequential class_ids
    local broken_vouchers
    broken_vouchers=$(db_query "SELECT voucher_code FROM session WHERE status = 'active' AND (class_id IS NULL OR class_id = 0);")
    for v in $broken_vouchers; do
        [ -n "$v" ] && db_assign_class_id "$v" >/dev/null 2>&1
    done
}

db_get_voucher_code_by_mac() {
    local mac=$(db_escape "$1")
    db_query "SELECT voucher_code FROM session WHERE bound_mac='${mac}' AND status IN ('active', 'disconnected') ORDER BY last_seen_at DESC LIMIT 1;"
}

db_get_capport_session_full() {
    local mac=$(db_escape "$1")
    db_query_fast "
        SELECT 
            s.voucher_code,
            COALESCE(s.status, ''),
            COALESCE(s.bound_ip, ''),
            COALESCE(s.rate_down_kbps, 0),
            COALESCE(s.rate_up_kbps, 0),
            COALESCE(s.data_limit_bytes, 0),
            COALESCE(s.cumulative_usage_bytes, 0),
            COALESCE(s.expires_at, 0),
            COALESCE(s.time_block_start, 0),
            COALESCE(s.time_block_end, 0),
            CASE 
                WHEN s.expires_at > 0 AND s.expires_at > strftime('%s','now') THEN s.expires_at - strftime('%s','now')
                WHEN s.expires_at > 0 THEN 60
                ELSE 86400
            END AS timeout_sec,
            COALESCE(v.duration_min, 0),
            COALESCE(s.class_id, 0)
        FROM session s
        LEFT JOIN voucher v ON s.voucher_code = v.code
        WHERE s.bound_mac='${mac}' AND s.status IN ('active', 'disconnected', 'quarantined')
        ORDER BY s.last_seen_at DESC LIMIT 1;
    "
}

db_supabase_get_sync_packages_json() {
    db_query "
        SELECT json_group_array(
            json_object(
                'name', name,
                'rate_down_kbps', rate_down_kbps,
                'rate_up_kbps', rate_up_kbps,
                'data_limit_bytes', data_limit_bytes,
                'duration_min', duration_min,
                'price_cents', price_cents,
                'is_visible', is_visible,
                'time_block_start', CASE WHEN time_block_start > 0 THEN printf('%02d:%02d', time_block_start / 100, time_block_start % 100) ELSE NULL END,
                'time_block_end', CASE WHEN time_block_end > 0 THEN printf('%02d:%02d', time_block_end / 100, time_block_end % 100) ELSE NULL END
            )
        )
        FROM package;
    " 2>/dev/null
}
