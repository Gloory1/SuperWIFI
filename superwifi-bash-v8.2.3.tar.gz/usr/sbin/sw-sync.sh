#!/bin/sh
# /usr/sbin/sw-sync.sh
# SuperWiFi Cloud Sync Library — sw_sync_cycle()
# Called by sw-engine.sh. Does NOT contain a daemon loop.
# Credentials (SP_URL, SP_KEY, GW_ID, GW_PASS) are set by sw-engine.sh.
# Libraries are loaded once by sw-engine.sh at startup.

# Validates that $1 is a plain non-negative integer; otherwise prints $2
sw_sync_numeric() {
    case "$1" in
        ''|*[!0-9]*) printf '%s' "$2" ;;
        *) printf '%s' "$1" ;;
    esac
}

sw_sync_cycle() {

    if [ -z "$SP_URL" ] || [ -z "$SP_KEY" ] || [ -z "$GW_ID" ]; then
        sw_log "WARN" "sw-sync: credentials incomplete — skipping cycle"
        return 0
    fi

    sw_db_init || return 1

    if ! command -v curl >/dev/null 2>&1 && ! command -v wget >/dev/null 2>&1; then
        sw_log "ERROR" "sw-sync: neither curl nor wget found"
        return 1
    fi

    FIRMWARE_VERSION=$(sw_get_version)
    sw_log "INFO" "Cloud Sync cycle started (v${FIRMWARE_VERSION})"

    # ==============================================================================
    # 1. PREPARE PAYLOAD
    # ==============================================================================
    VOUCHERS_JSON=$(db_supabase_get_sync_vouchers_json)
    SESSIONS_JSON=$(db_supabase_get_sync_sessions_json)

    [ "$VOUCHERS_JSON" = "" ] && VOUCHERS_JSON="[]"
    [ "$SESSIONS_JSON" = "" ] && SESSIONS_JSON="[]"

    PACKAGES_JSON=$(db_supabase_get_sync_packages_json)
    [ "$PACKAGES_JSON" = "" ] && PACKAGES_JSON="[]"

    payload=$(jq -n \
        --arg gw_id "$GW_ID" \
        --arg gw_pass "$GW_PASS" \
        --argjson sess "$SESSIONS_JSON" \
        --argjson vouch "$VOUCHERS_JSON" \
        --argjson pkgs "$PACKAGES_JSON" \
        --arg fw "$FIRMWARE_VERSION" \
        '{
            p_gateway_id: $gw_id,
            p_password: $gw_pass,
            p_sessions: $sess,
            p_vouchers: $vouch,
            p_packages: $pkgs,
            p_firmware_version: $fw
        }')

    # ==============================================================================
    # 2. EXECUTE CONSOLIDATED SYNC
    # ==============================================================================
    if command -v curl >/dev/null 2>&1; then
        SYNC_RESPONSE=$(curl -s -k --connect-timeout 10 --max-time 15 \
            -X POST \
            -H "apikey: $SP_KEY" \
            -H "Authorization: Bearer $SP_KEY" \
            -H "Content-Type: application/json" \
            -d "$payload" \
            "${SP_URL}/rest/v1/rpc/v5_sync" 2>/dev/null) || SYNC_RESPONSE=""
    else
        payload_file=$(mktemp "/tmp/superwifi/payload.XXXXXX")
        printf '%s' "$payload" > "$payload_file"
        SYNC_RESPONSE=$(wget -qO- --no-check-certificate --timeout=15 -t 1 \
            --post-file="$payload_file" \
            --header="apikey: $SP_KEY" \
            --header="Authorization: Bearer $SP_KEY" \
            --header="Content-Type: application/json" \
            "${SP_URL}/rest/v1/rpc/v5_sync" 2>/dev/null) || SYNC_RESPONSE=""
        rm -f "$payload_file"
    fi

    if [ -z "$SYNC_RESPONSE" ] || [ "$SYNC_RESPONSE" = "null" ]; then
        sw_log "WARN" "sw-sync: failed to communicate with Supabase"
        return 1
    fi

    error_msg=$(printf '%s' "$SYNC_RESPONSE" | jq -r '.message' 2>/dev/null)
    if [ "$error_msg" != "null" ] && [ -n "$error_msg" ]; then
        sw_log "ERROR" "sw-sync: Server returned error: $error_msg"
        return 1
    fi

    # ==============================================================================
    # 3. PROCESS RESPONSE
    # ==============================================================================
    actions_json=$(printf '%s' "$SYNC_RESPONSE" | jq -c '.actions' 2>/dev/null)
    if [ "$actions_json" != "null" ] && [ "$actions_json" != "[]" ]; then
        printf '%s' "$actions_json" | jq -r '.[] | "\(.action)\t\(.voucher_code)\t\(.bound_mac)\t\(.reason)\t\(.payload | tostring)"' 2>/dev/null | \
        while IFS=$(printf '\t') read -r action_code v_code v_mac reason payload_json; do
            case "$action_code" in
                deauth)
                    if [ -n "$v_code" ] && [ "$v_code" != "null" ]; then
                        mac=$(db_get_session_mac_by_voucher "$v_code")
                        ip=$(db_get_session_ip_by_voucher "$v_code")
                        if [ -n "$mac" ]; then
                            sw_fw_deauth "$mac" "$ip" "$v_code" "cloud_deauth"
                            sw_log "INFO" "sw-sync: remote deauth for $v_code"
                        fi
                    fi
                    ;;
                quarantine)
                    if [ -n "$v_mac" ] && [ "$v_mac" != "null" ]; then
                        db_quarantine_mac "$v_mac" "cloud_quarantine"
                        sw_fw_block_mac "$v_mac"
                        sw_log "INFO" "sw-sync: remote quarantine for $v_mac"
                    fi
                    ;;
                unquarantine)
                    if [ -n "$v_mac" ] && [ "$v_mac" != "null" ]; then
                        db_unquarantine_mac "$v_mac" "cloud_unquarantine"
                        sw_fw_unblock_mac "$v_mac"
                        sw_log "INFO" "sw-sync: remote unquarantine for $v_mac"
                    fi
                    ;;
                reset_mac)
                    if [ -n "$v_code" ] && [ "$v_code" != "null" ]; then
                        mac=$(db_get_session_mac_by_voucher "$v_code")
                        ip=$(db_get_session_ip_by_voucher "$v_code")
                        if [ -n "$mac" ]; then
                            sw_fw_deauth "$mac" "$ip" "$v_code" "cloud_reset_mac"
                        fi
                        db_reset_voucher_mac "$v_code"
                        sw_log "INFO" "sw-sync: remote reset_mac for $v_code (old mac: $mac)"
                    fi
                    ;;
                apply_theme)
                    script_url=$(printf '%s' "$payload_json" | jq -r '.script_url // empty' 2>/dev/null)
                    script_sha256=$(printf '%s' "$payload_json" | jq -r '.script_sha256 // empty' 2>/dev/null)
                    if [ -n "$script_url" ] && [ "$script_url" != "null" ]; then
                        sw_log "INFO" "sw-sync: downloading theme script from $script_url"
                        theme_script=$(mktemp "/tmp/superwifi/theme_install.XXXXXX")
                        if wget -qO "$theme_script" "$script_url" && [ -s "$theme_script" ]; then
                            actual_hash=$(sha256sum "$theme_script" 2>/dev/null | cut -d' ' -f1)
                            if [ -z "$script_sha256" ] || [ "$script_sha256" = "null" ] || [ "$actual_hash" != "$script_sha256" ]; then
                                sw_log "ERROR" "sw-sync: theme script integrity check failed — skipping execution"
                                rm -f "$theme_script"
                            else
                                chmod +x "$theme_script"
                                sw_log "INFO" "sw-sync: executing theme installation script"
                                tar -czf /tmp/superwifi/theme_backup.tar.gz -C / www/superwifi 2>/dev/null || true
                                "$theme_script" >/dev/null 2>&1
                                if [ ! -f "/www/superwifi/login.html" ]; then
                                    sw_log "ERROR" "sw-sync: Theme installation corrupted login.html. Rolling back."
                                    rm -rf /www/superwifi
                                    tar -xzf /tmp/superwifi/theme_backup.tar.gz -C / 2>/dev/null || true
                                else
                                    sw_log "INFO" "sw-sync: Theme applied successfully."
                                fi
                                rm -f /tmp/superwifi/theme_backup.tar.gz "$theme_script"
                            fi
                        else
                            sw_log "ERROR" "sw-sync: failed to download theme script from $script_url"
                            rm -f "$theme_script"
                        fi
                    fi
                    ;;
                change_config)
                    conf_key=$(printf '%s' "$payload_json" | jq -r '.config // empty' 2>/dev/null)
                    conf_val=$(printf '%s' "$payload_json" | jq -r '.value // empty' 2>/dev/null)
                    if [ -n "$conf_key" ] && [ "$conf_key" != "null" ] && [ -n "$conf_val" ]; then
                        case "$conf_key" in
                            credentials.*|gateway.*)
                                sw_log "WARN" "sw-sync: rejected attempt to change protected config key '$conf_key'"
                                ;;
                            *)
                                case "$conf_key" in
                                    core.provider_name|core.success_url|core.auto_update)
                                        uci set superwifi."$conf_key"="$conf_val"
                                        uci commit superwifi
                                        sw_log "INFO" "sw-sync: updated config superwifi.$conf_key to $conf_val"
                                        ;;
                                    *)
                                        sw_log "WARN" "sw-sync: rejected attempt to change non-whitelisted config key '$conf_key'"
                                        ;;
                                esac
                                ;;
                        esac
                    fi
                    ;;
            esac
        done
    fi

    # Prepare single-transaction SQL batch file for high performance
    SYNC_BATCH_SQL="/tmp/superwifi/sync_batch.sql"
    : > "$SYNC_BATCH_SQL"
    printf "BEGIN TRANSACTION;\n" >> "$SYNC_BATCH_SQL"
    has_batch_items=0

    # Packages
    packages_json=$(printf '%s' "$SYNC_RESPONSE" | jq -c '.packages' 2>/dev/null)
    if [ "$packages_json" != "null" ] && [ "$packages_json" != "[]" ]; then
        printf '%s' "$packages_json" | jq -r '.[] | "\(.id)\t\(.name)\t\(.rate_down_kbps)\t\(.rate_up_kbps)\t\(.data_limit_bytes)\t\(.duration_min)\t\(.is_visible)\t\(.price_cents)\t\(.time_block_start // "")\t\(.time_block_end // "")"' 2>/dev/null | \
        while IFS=$(printf '\t') read -r p_id p_name p_down p_up p_limit p_time p_visible p_price p_tb_start p_tb_end; do
            [ -z "$p_id" ] && continue
            p_id_safe=$(sw_sync_numeric "$p_id" "0")
            p_down_safe=$(sw_sync_numeric "$p_down" "2048")
            p_up_safe=$(sw_sync_numeric "$p_up" "1024")
            p_limit_safe=$(sw_sync_numeric "$p_limit" "0")
            p_time_safe=$(sw_sync_numeric "$p_time" "0")
            p_price_safe=$(sw_sync_numeric "$p_price" "0")

            p_name_esc=$(printf '%s' "$p_name" | sed "s/'/''/g")
            p_vis=1
            [ "$p_visible" = "false" ] || [ "$p_visible" = "0" ] && p_vis=0
            tb_start=0
            tb_end=0
            if [ -n "$p_tb_start" ] && [ "$p_tb_start" != "null" ]; then
                tb_start=$(echo "$p_tb_start" | tr -d ':' | sed 's/^0*//'); tb_start=$(sw_sync_numeric "$tb_start" "0")
            fi
            if [ -n "$p_tb_end" ] && [ "$p_tb_end" != "null" ]; then
                tb_end=$(echo "$p_tb_end" | tr -d ':' | sed 's/^0*//'); tb_end=$(sw_sync_numeric "$tb_end" "0")
            fi
            printf "INSERT INTO package (id, name, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, is_visible, price_cents, time_block_start, time_block_end) VALUES (%s, '%s', %s, %s, %s, %s, %s, %s, %s, %s) ON CONFLICT(name) DO UPDATE SET id=excluded.id, rate_down_kbps=excluded.rate_down_kbps, rate_up_kbps=excluded.rate_up_kbps, data_limit_bytes=excluded.data_limit_bytes, duration_min=excluded.duration_min, is_visible=excluded.is_visible, price_cents=excluded.price_cents, time_block_start=excluded.time_block_start, time_block_end=excluded.time_block_end;\n" \
                "$p_id_safe" "$p_name_esc" "$p_down_safe" "$p_up_safe" "$p_limit_safe" "$p_time_safe" "$p_vis" "$p_price_safe" "$tb_start" "$tb_end" >> "$SYNC_BATCH_SQL"
        done
        pkg_count=$(grep -c 'INSERT INTO package' "$SYNC_BATCH_SQL" 2>/dev/null || echo 0)
        has_batch_items=1
        sw_log "INFO" "sw-sync: prepared $pkg_count packages for batch insert"
    fi

    # Vouchers
    vouchers_json=$(printf '%s' "$SYNC_RESPONSE" | jq -c '.vouchers' 2>/dev/null)
    if [ "$vouchers_json" != "null" ] && [ "$vouchers_json" != "[]" ]; then
        printf '%s' "$vouchers_json" | jq -r '.[] | "\(.code)\t\(.package_name // "")\t\(.batch_id // "")"' 2>/dev/null | \
        while IFS=$(printf '\t') read -r v_code v_pkg_name v_batch; do
            [ -z "$v_code" ] && continue
            v_code_esc=$(printf '%s' "$v_code" | sed "s/'/''/g")
            batch_val="NULL"
            if [ -n "$v_batch" ] && [ "$v_batch" != "null" ]; then
                batch_val=$(sw_sync_numeric "$v_batch" "NULL")
            fi
            
            if [ -z "$v_pkg_name" ] || [ "$v_pkg_name" = "null" ]; then
                printf "INSERT INTO voucher (code, package_id, batch_id, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, time_block_start, time_block_end) VALUES ('%s', NULL, %s, 2048, 1024, 0, 0, 0, 0) ON CONFLICT(code) DO UPDATE SET batch_id=excluded.batch_id;\n" \
                    "$v_code_esc" "$batch_val" >> "$SYNC_BATCH_SQL"
            else
                v_pkg_name_esc=$(printf '%s' "$v_pkg_name" | sed "s/'/''/g")
                printf "INSERT INTO voucher (code, package_id, batch_id, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, time_block_start, time_block_end) SELECT '%s', id, %s, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, time_block_start, time_block_end FROM package WHERE name = '%s' ON CONFLICT(code) DO UPDATE SET batch_id=excluded.batch_id;\n" \
                    "$v_code_esc" "$batch_val" "$v_pkg_name_esc" >> "$SYNC_BATCH_SQL"
            fi
        done
        vouch_count=$(grep -c 'INSERT INTO voucher' "$SYNC_BATCH_SQL" 2>/dev/null || echo 0)
        has_batch_items=1
        sw_log "INFO" "sw-sync: prepared $vouch_count vouchers for batch insert"
    fi

    # Deleted Batches
    del_batches_json=$(printf '%s' "$SYNC_RESPONSE" | jq -c '.deleted_batches' 2>/dev/null)
    if [ "$del_batches_json" != "null" ] && [ "$del_batches_json" != "[]" ]; then
        batch_id_list=$(printf '%s' "$del_batches_json" | jq -r '.[] | if type == "object" then .id else . end' 2>/dev/null | grep -E '^[0-9]+$' | tr '\n' ',' | sed 's/,$//')
        if [ -n "$batch_id_list" ]; then
            printf "DELETE FROM voucher WHERE batch_id IN (%s);\n" "$batch_id_list" >> "$SYNC_BATCH_SQL"
            del_batches_count=$(printf '%s' "$del_batches_json" | jq '. | length' 2>/dev/null || echo 0)
            has_batch_items=1
            sw_log "INFO" "sw-sync: prepared $del_batches_count deleted batches for bulk deletion"
        fi
    fi

    # Deleted Packages
    del_packages_json=$(printf '%s' "$SYNC_RESPONSE" | jq -c '.deleted_packages' 2>/dev/null)
    if [ "$del_packages_json" != "null" ] && [ "$del_packages_json" != "[]" ]; then
        pkg_id_list=$(printf '%s' "$del_packages_json" | jq -r '.[] | if type == "object" then .id else . end' 2>/dev/null | grep -E '^[0-9]+$' | tr '\n' ',' | sed 's/,$//')
        pkg_name_list=$(printf '%s' "$del_packages_json" | jq -r '.[] | if type == "object" then .name else . end' 2>/dev/null | grep -v 'null' | sed "s/'/''/g; s/^/'/; s/$/'/" | tr '\n' ',' | sed 's/,$//')
        
        del_sql=""
        [ -n "$pkg_id_list" ] && del_sql="id IN ($pkg_id_list)"
        if [ -n "$pkg_name_list" ]; then
            [ -n "$del_sql" ] && del_sql="$del_sql OR "
            del_sql="${del_sql}name IN ($pkg_name_list)"
        fi
        
        if [ -n "$del_sql" ]; then
            printf "DELETE FROM voucher WHERE package_id IN (SELECT id FROM package WHERE %s);\n" "$del_sql" >> "$SYNC_BATCH_SQL"
            printf "DELETE FROM package WHERE %s;\n" "$del_sql" >> "$SYNC_BATCH_SQL"
            del_pkgs_count=$(printf '%s' "$del_packages_json" | jq '. | length' 2>/dev/null || echo 0)
            has_batch_items=1
            sw_log "INFO" "sw-sync: prepared $del_pkgs_count deleted packages for bulk deletion"
        fi
    fi

    # Deleted Vouchers
    del_vouchers_json=$(printf '%s' "$SYNC_RESPONSE" | jq -c '.deleted_vouchers' 2>/dev/null)
    if [ "$del_vouchers_json" != "null" ] && [ "$del_vouchers_json" != "[]" ]; then
        code_list_sql=$(printf '%s' "$del_vouchers_json" | jq -r '.[] | if type == "object" then .code else . end' 2>/dev/null | sed "s/'/''/g; s/^/'/; s/$/'/" | tr '\n' ',' | sed 's/,$//')
        if [ -n "$code_list_sql" ]; then
            printf "DELETE FROM voucher WHERE code IN (%s);\n" "$code_list_sql" >> "$SYNC_BATCH_SQL"
            del_vouch_count=$(printf '%s' "$del_vouchers_json" | jq '. | length' 2>/dev/null || echo 0)
            has_batch_items=1
            sw_log "INFO" "sw-sync: prepared $del_vouch_count deleted vouchers for bulk deletion"
        fi
    fi

    batch_ok=1
    if [ "$has_batch_items" = "1" ]; then
        printf "COMMIT;\n" >> "$SYNC_BATCH_SQL"
        if db_exec_batch "$SYNC_BATCH_SQL"; then
            sw_log "INFO" "sw-sync: executed single-transaction SQL batch successfully"
        else
            batch_ok=0
            sw_log "ERROR" "sw-sync: SQL batch execution FAILED — skipping mark-as-synced this cycle"
        fi
    fi
    rm -f "$SYNC_BATCH_SQL"

    # ==============================================================================
    # 4. FINALIZE & FIRMWARE CHECK
    # ==============================================================================
    if [ "$batch_ok" = "1" ]; then
        NOW_TS=$(date +%s)
        db_supabase_mark_all_synced "$NOW_TS"
        sw_log "INFO" "Cloud Sync cycle completed successfully"
    else
        sw_log "WARN" "Cloud Sync cycle completed with errors — unsynced rows will retry next cycle"
    fi

    auto_update=$(printf '%s' "$SYNC_RESPONSE" | jq -r '.auto_update' 2>/dev/null)
    update_url=$(printf '%s' "$SYNC_RESPONSE" | jq -r '.update_url' 2>/dev/null)

    if [ "$update_url" != "null" ] && [ -n "$update_url" ]; then
        # Parse version e.g. ota_v8.1.7.sh -> 8.1.7 and compare against local version to prevent auto-downgrade
        remote_ver=$(printf '%s' "$update_url" | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1)
        local_ver=$(sw_get_version | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1)

        remote_num=$(printf '%s' "$remote_ver" | tr -d '.')
        local_num=$(printf '%s' "$local_ver" | tr -d '.')

        if [ -n "$remote_num" ] && [ -n "$local_num" ] && [ "$remote_num" -le "$local_num" ]; then
            sw_log "INFO" "sw-sync: Remote version ($remote_ver) <= local version ($local_ver) — skipping auto-downgrade."
        else
            sw_log "INFO" "sw-sync: Firmware update available at $update_url"
            local_auto_update=$(uci get superwifi.core.auto_update 2>/dev/null || echo "1")
            update_hash=$(printf '%s' "$SYNC_RESPONSE" | jq -r '.update_sha256 // empty' 2>/dev/null)
            
            if [ "$local_auto_update" = "1" ] && [ "$auto_update" = "true" ]; then
                sw_log "INFO" "sw-sync: Triggering auto update..."
                /usr/sbin/sw update --async "$update_url" "$update_hash" &
            else
                sw_log "INFO" "sw-sync: Auto update disabled, run 'sw update $update_url $update_hash' manually."
            fi
        fi
    fi
}
