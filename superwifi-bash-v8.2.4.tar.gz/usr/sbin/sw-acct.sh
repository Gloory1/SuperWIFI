#!/bin/sh
# /usr/sbin/sw-acct.sh
# SuperWiFi Accounting Library — sw_acct_cycle()
# Called by sw-engine.sh. Does NOT contain a daemon loop.
# Libraries are loaded once by sw-engine.sh at startup.

sw_acct_cycle() {
    sw_db_init || return

    CYCLE_START_EPOCH=$(date +%s)
    # [FIX M2] Use mktemp to prevent predictable symlink attacks
    TC_STATS_FILE=$(mktemp "/tmp/superwifi/tc_stats.XXXXXX")
    local ifb_dev="ifb4${LAN_IFACE}"
    # TODO: report download/upload separately in history when schema supports it
    (
        tc -s class show dev "$LAN_IFACE" 2>/dev/null
        tc -s class show dev "$ifb_dev" 2>/dev/null
    ) | awk '/class htb 1:/ {c=$3; sub(/.*1:/,"",c)} /Sent/ {sum[c]+=$2} END {for (c in sum) print c "|" sum[c]}' > "$TC_STATS_FILE"

    SQL_OUT=$(mktemp "/tmp/superwifi/bulk_update.XXXXXX")
    LOG_OUT=$(mktemp "/tmp/superwifi/actions.XXXXXX")

    echo "BEGIN TRANSACTION;" > "$SQL_OUT"

    # [FIX] Load all TC counters into a single newline-separated string once before the loop.
    # Lookup is done with grep on the in-memory string — O(1) per session, zero subshells.
    TC_STATS_MAP=$(awk -F'|' '{printf "%s|%s\n", $1, $2}' "$TC_STATS_FILE")

    # Read the hot-path view: v_acct_target
    db_get_accounting_targets | \
    while IFS='|' read -r mac ip voucher rate_down rate_up limit cumulative season_usage class_id is_expired is_time_blocked; do
        [ -z "$mac" ] || [ -z "$ip" ] && continue
        [ -z "$class_id" ] || [ "$class_id" = "NULL" ] && continue

        # Fast lookup from pre-loaded map — no per-session subshell spawn
        local curr_bytes=0
        _tc_line=$(printf '%s\n' "$TC_STATS_MAP" | grep "^${class_id}|")
        [ -n "$_tc_line" ] && curr_bytes=${_tc_line#*|}
        curr_bytes=$(printf '%s' "$curr_bytes" | tr -dc '0-9')
        [ -z "$curr_bytes" ] && curr_bytes=0


        [ -z "$season_usage" ] && season_usage=0

        local delta_bytes=0
        if [ "$curr_bytes" -gt "$season_usage" ]; then
            delta_bytes=$(( curr_bytes - season_usage ))
        elif [ "$curr_bytes" -lt "$season_usage" ]; then
            # H5 Fix: Check if this is a likely 32-bit wrap (curr < season but not by much)
            local wrap_delta=$(( 4294967296 - season_usage + curr_bytes ))
            # If wrapped by less than the anomaly threshold, it's a wrap. Otherwise it's a genuine tc reset.
            if [ "$wrap_delta" -lt $(( rate_down * 125 * ACCT_INTERVAL_SEC * 2 )) ]; then
                delta_bytes=$wrap_delta
            else
                delta_bytes=$curr_bytes
            fi
        fi

        local new_cumulative_bytes=$(( cumulative + delta_bytes ))

        # 1. Anomaly Detection
        local max_bytes=$(( rate_down * 125 * ACCT_INTERVAL_SEC ))
        local anomaly_mult
        anomaly_mult=$(printf '%s' "$ANOMALY_MULTIPLIER" | awk '{printf "%d", $1*100}')
        [ -z "$anomaly_mult" ] && anomaly_mult=120
        local threshold_bytes=$(( max_bytes * anomaly_mult / 100 ))

        if [ "$delta_bytes" -gt 0 ] && [ "$threshold_bytes" -gt 0 ] && \
           [ "$delta_bytes" -gt "$threshold_bytes" ]; then
            db_quarantine_mac_sql "$mac" "rate_anomaly" >> "$SQL_OUT"
            db_insert_quarantine_log_sql "$mac" "$voucher" "rate_anomaly" "$delta_bytes" "$threshold_bytes" >> "$SQL_OUT"
            echo "QUARANTINE|${mac}|${ip}|${voucher}" >> "$LOG_OUT"
            continue
        fi

        # 2. Time Expiry (Calculated inherently by the v_acct_target view using integer math)
        if [ "$is_expired" = "1" ]; then
            if [ "$delta_bytes" -gt 0 ]; then
                db_update_usage_season_sql "$voucher" "$curr_bytes" "$delta_bytes" >> "$SQL_OUT"
                db_insert_accounting_log_sql "$voucher" "$mac" "$delta_bytes" "$CYCLE_START_EPOCH" >> "$SQL_OUT"
            fi
            db_expire_session_sql "$voucher" >> "$SQL_OUT"
            echo "DEAUTH|${mac}|${ip}|${voucher}|session_expired|${class_id}" >> "$LOG_OUT"
            continue
        fi

        # 2b. Time Block Enforcement
        if [ "$is_time_blocked" = "1" ]; then
            if [ "$delta_bytes" -gt 0 ]; then
                db_update_usage_season_sql "$voucher" "$curr_bytes" "$delta_bytes" >> "$SQL_OUT"
                db_insert_accounting_log_sql "$voucher" "$mac" "$delta_bytes" "$CYCLE_START_EPOCH" >> "$SQL_OUT"
            fi
            printf "UPDATE session SET status='disconnected', class_id=NULL, last_seen_at=strftime('%%s','now') WHERE voucher_code='%s';\n" "$voucher" >> "$SQL_OUT"
            echo "DEAUTH|${mac}|${ip}|${voucher}|time_blocked|${class_id}" >> "$LOG_OUT"
            continue
        fi

        # 3. Data Expiry
        if [ "${limit:-0}" -gt 0 ] && [ "$new_cumulative_bytes" -ge "$limit" ]; then
            db_update_usage_season_sql "$voucher" "$curr_bytes" "$delta_bytes" >> "$SQL_OUT"
            db_expire_session_sql "$voucher" >> "$SQL_OUT"
            db_insert_accounting_log_sql "$voucher" "$mac" "$delta_bytes" "$CYCLE_START_EPOCH" >> "$SQL_OUT"
            echo "DEAUTH|${mac}|${ip}|${voucher}|quota_exhausted|${class_id}" >> "$LOG_OUT"
            continue
        fi

        # 4. Standard Delta Update
        if [ "$delta_bytes" -gt 0 ]; then
            db_update_usage_season_sql "$voucher" "$curr_bytes" "$delta_bytes" >> "$SQL_OUT"
            db_insert_accounting_log_sql "$voucher" "$mac" "$delta_bytes" "$CYCLE_START_EPOCH" >> "$SQL_OUT"
        fi
    done

    echo "COMMIT;" >> "$SQL_OUT"
    if db_exec_batch "$SQL_OUT"; then
        rm -f "$TC_STATS_FILE"

        if [ -f "$LOG_OUT" ]; then
            while IFS='|' read -r ACTION MAC IP VOUCHER REASON CID; do
                if [ "$ACTION" = "DEAUTH" ]; then
                    sw_fw_deauth "$MAC" "$IP" "$VOUCHER" "$REASON" "$CID"
                    sw_log "INFO" "ACCOUNTING: $MAC deauthed due to $REASON"
                elif [ "$ACTION" = "QUARANTINE" ]; then
                    nft delete element inet superwifi authenticated "{ ${MAC} . ${IP} }" 2>/dev/null || true
                    sw_fw_block_mac "$MAC"
                    sw_tc_remove_by_ip "$IP"
                    sw_log "WARN" "QUARANTINE: mac=$MAC voucher=$VOUCHER rate anomaly"
                fi
            done < "$LOG_OUT"
            rm -f "$LOG_OUT"
        fi
    else
        sw_log "ERROR" "sw-acct: db_exec_batch failed, skipping actions to avoid inconsistency"
        rm -f "$TC_STATS_FILE"
        rm -f "$LOG_OUT"
    fi

    # Trigger periodic maintenance every 10 minutes
    local _minute
    _minute=$(date +%M | sed 's/^0//')
    _minute=${_minute:-0}
    if [ $(( _minute % 10 )) -eq 0 ]; then
        db_maintenance_cleanup
        # Run PASSIVE checkpoint to safely write WAL data to main DB without locking writers
        db_checkpoint
        sw_log "INFO" "Periodic maintenance cleanup & passive WAL checkpoint done."
    fi

    # Cleanup temp files
    rm -f "$TC_STATS_FILE" "$SQL_OUT" "$LOG_OUT"
}
