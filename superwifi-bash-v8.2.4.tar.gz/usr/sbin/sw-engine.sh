#!/bin/sh
# /usr/sbin/sw-engine.sh
# SuperWiFi Unified Engine Daemon v8.2.4
# Orchestrates: Accounting → Sentinel → Cloud Sync
# Single procd instance. All timings from UCI config.

# ==============================================================================
# Load shared libraries once at startup
# ==============================================================================
. /usr/lib/superwifi/core.sh
. /usr/lib/superwifi/db-queries.sh
. /usr/lib/superwifi/tc.sh
. /usr/lib/superwifi/fw.sh
. /usr/sbin/sw-acct.sh
. /usr/sbin/sw-sentinel.sh
. /usr/sbin/sw-sync.sh

# ==============================================================================
# Single process lock — prevent duplicate daemon instances
# ==============================================================================
LOCK_FILE="/tmp/superwifi/sw-engine.lock"
mkdir -p /tmp/superwifi 2>/dev/null
exec 8>"$LOCK_FILE"
if ! flock -n 8; then
    sw_log "WARN" "sw-engine: another instance is already running, exiting."
    exit 0
fi
printf '%s' "$$" > "$LOCK_FILE"

# ==============================================================================
# Graceful shutdown — procd sends SIGTERM on stop/restart/OTA
# ==============================================================================
SHUTDOWN_REQ=0
_cycle_pid=""
cleanup() {
    rm -f "/tmp/superwifi/sync_batch.sql" \
          "/tmp/superwifi/payload."* \
          "/tmp/superwifi/theme_install."* \
          "$LOCK_FILE" 2>/dev/null || true
}
trap 'sw_log "INFO" "sw-engine: received signal, shutting down cleanly"
      SHUTDOWN_REQ=1
      [ -n "$_cycle_pid" ] && kill "$_cycle_pid" 2>/dev/null || true
      cleanup
      exit 0' TERM INT

# [FIX] Hardcoded default credentials removed — credentials must be configured via UCI.
# Use: uci set superwifi.credentials.supabase_url='https://...'
#      uci set superwifi.credentials.supabase_key='eyJ...'
#      uci commit superwifi

sw_log "INFO" "sw-engine daemon started (v$(sw_get_version))"

# ==============================================================================
# _engine_read_config — reads all timings from UCI every cycle (live config)
# ==============================================================================
_engine_read_config() {
    # Accounting interval: read acct_interval (minutes), fallback to check_interval_sec (seconds) for backward compat
    ACCT_INTERVAL_MIN=$(uci get superwifi.core.acct_interval 2>/dev/null)
    if [ -z "$ACCT_INTERVAL_MIN" ] || [ "$ACCT_INTERVAL_MIN" = "0" ]; then
        # Backward compat: check_interval_sec was in seconds, convert to minutes
        local _old_sec
        _old_sec=$(uci get superwifi.core.check_interval_sec 2>/dev/null || echo 60)
        ACCT_INTERVAL_MIN=$(( _old_sec / 60 ))
        [ "$ACCT_INTERVAL_MIN" -lt 1 ] && ACCT_INTERVAL_MIN=1
    fi
    case "$ACCT_INTERVAL_MIN" in
        ''|*[!0-9]*) ACCT_INTERVAL_MIN=1 ;;
    esac
    [ "$ACCT_INTERVAL_MIN" -lt 1 ] && ACCT_INTERVAL_MIN=1
    ACCT_INTERVAL_SEC=$(( ACCT_INTERVAL_MIN * 60 ))

    # Sync interval: in minutes. 0 = disabled.
    SYNC_INTERVAL_MIN=$(uci get superwifi.core.sync_interval 2>/dev/null || echo 0)
    case "$SYNC_INTERVAL_MIN" in
        ''|*[!0-9]*) SYNC_INTERVAL_MIN=0 ;;
    esac

    # Sentinel
    SENTINEL_ENABLED=$(uci get superwifi.core.sentinel_enabled 2>/dev/null || echo 0)

    # [FIX] Credentials must come from UCI only — no hardcoded fallback.
    SP_URL=$(uci get superwifi.credentials.supabase_url 2>/dev/null || echo "")
    SP_KEY=$(uci get superwifi.credentials.supabase_key 2>/dev/null || echo "")
    GW_ID=$(uci get superwifi.gateway.gateway_id 2>/dev/null)
    GW_PASS=$(uci get superwifi.gateway.gateway_password 2>/dev/null)
}

# ==============================================================================
# _run_with_watchdog <timeout_sec> <cycle_function>
# Runs a cycle function in a guarded subshell. Kills if it exceeds timeout.
# ==============================================================================
_run_with_watchdog() {
    local _wdog_timeout="$1"
    local _wdog_fn="$2"

    (
        trap - EXIT INT TERM   # Clear inherited traps inside the subshell
        "$_wdog_fn"
    ) &
    _cycle_pid=$!

    local _elapsed=0
    while [ "$_elapsed" -lt "$_wdog_timeout" ] && [ "$SHUTDOWN_REQ" -eq 0 ]; do
        kill -0 "$_cycle_pid" 2>/dev/null || break
        sleep 1
        _elapsed=$(( _elapsed + 1 ))
    done

    if kill -0 "$_cycle_pid" 2>/dev/null; then
        sw_log "ERROR" "sw-engine: ${_wdog_fn} exceeded ${_wdog_timeout}s watchdog — sending SIGTERM"
        kill -TERM "$_cycle_pid" 2>/dev/null || true
        # [FIX] Give the subprocess 3s to flush files/commits before SIGKILL
        local _grace=0
        while [ "$_grace" -lt 3 ] && kill -0 "$_cycle_pid" 2>/dev/null; do
            sleep 1
            _grace=$(( _grace + 1 ))
        done
        if kill -0 "$_cycle_pid" 2>/dev/null; then
            sw_log "WARN" "sw-engine: ${_wdog_fn} did not exit after SIGTERM — sending SIGKILL"
            kill -9 "$_cycle_pid" 2>/dev/null || true
        fi
    fi
    wait "$_cycle_pid" 2>/dev/null || true
    _cycle_pid=""
}

# ==============================================================================
# MAIN DAEMON LOOP
# ==============================================================================
_sync_cycle_counter=0

while [ "$SHUTDOWN_REQ" -eq 0 ]; do

    # Read config dynamically every cycle (live changes take effect immediately)
    _engine_read_config

    # ① Accounting — always runs every acct_interval
    sw_log "INFO" "sw-engine: acct cycle start"
    _acct_timeout=$(( ACCT_INTERVAL_SEC - 5 ))
    [ "$_acct_timeout" -lt 10 ] && _acct_timeout=10
    _run_with_watchdog "$_acct_timeout" sw_acct_cycle

    # ② Sentinel — runs after accounting if enabled
    if [ "${SENTINEL_ENABLED:-0}" = "1" ] && [ "$SHUTDOWN_REQ" -eq 0 ]; then
        _run_with_watchdog 30 sw_sentinel_reconcile
    fi

    # ③ Cloud Sync — runs every sync_interval minutes (0 = disabled)
    if [ "${SYNC_INTERVAL_MIN:-0}" -gt 0 ] && [ "$SHUTDOWN_REQ" -eq 0 ]; then
        # How many acct cycles fit in sync_interval?
        _sync_every=$(( SYNC_INTERVAL_MIN / ACCT_INTERVAL_MIN ))
        [ "$_sync_every" -lt 1 ] && _sync_every=1

        _sync_cycle_counter=$(( _sync_cycle_counter + 1 ))
        if [ "$_sync_cycle_counter" -ge "$_sync_every" ]; then
            _sync_cycle_counter=0
            sw_log "INFO" "sw-engine: sync cycle start"
            _run_with_watchdog 60 sw_sync_cycle
        fi
    else
        # Reset counter if sync was just disabled live
        _sync_cycle_counter=0
    fi

    # Responsive sleep between cycles (1-second ticks → reacts to SIGTERM instantly)
    _slept=0
    while [ "$_slept" -lt "$ACCT_INTERVAL_SEC" ] && [ "$SHUTDOWN_REQ" -eq 0 ]; do
        sleep 1
        _slept=$(( _slept + 1 ))
    done

done

cleanup
