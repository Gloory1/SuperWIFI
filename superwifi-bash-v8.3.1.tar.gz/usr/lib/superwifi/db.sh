#!/bin/sh
# /usr/lib/superwifi/db.sh
# SuperWiFi Core — Database Abstraction Layer
# Handles connection setup, PRAGMA tuning, and core query helpers.
# All business-logic queries live in db-queries.sh.

. /usr/lib/superwifi/core.sh

# -- Sanitization -----------------------------------------------------------
# Escapes single quotes for safe SQL string interpolation.
# All user-supplied values MUST pass through this before reaching SQL.
db_escape() {
    # Remove null bytes, $, backticks, and backslashes to prevent shell/command injection. Then escape single quotes for SQL.
    printf "%s" "$1" | tr -d '\000$`\\' | sed "s/'/''/g"
}

# ------------------------------------------------------------------------------
# Core Query Function
# ------------------------------------------------------------------------------
# All database interactions MUST go through this function to ensure
# proper pragmas, timeouts, and WAL mode concurrency.
db_query() {
    # WARNING: Do NOT use -cmd "PRAGMA journal_mode=WAL;" here as it prints 'wal' to stdout
    # and corrupts the output of SELECT statements. WAL mode is persistent and is set in sw_db_init.
    # [FIX] Avoid mktemp overhead in hot path — use PID-scoped temp file.
    local _err="/tmp/superwifi/db_err_$$" _rc
    sqlite3 \
        -cmd ".timeout 5000" \
        -cmd "PRAGMA synchronous=NORMAL;" \
        -cmd "PRAGMA foreign_keys=ON;" \
        -cmd "PRAGMA cache_size=-2000;" \
        -cmd "PRAGMA temp_store=MEMORY;" \
        "$DB_PATH" "$1" 2>"$_err" | tr -d '\r'
    _rc=$?
    [ -s "$_err" ] && logger -t superwifi_db -p daemon.err "$(cat "$_err")"
    rm -f "$_err" 2>/dev/null
    return $_rc
}

# Fast Query Function for CGI Web Requests
# Uses 1500ms timeout to prevent CGI process accumulation under uhttpd.
db_query_fast() {
    # [FIX] Avoid mktemp overhead — PID-scoped temp file.
    local _err="/tmp/superwifi/db_err_fast_$$" _rc
    sqlite3 \
        -cmd ".timeout 1500" \
        -cmd "PRAGMA synchronous=NORMAL;" \
        -cmd "PRAGMA foreign_keys=ON;" \
        -cmd "PRAGMA cache_size=-2000;" \
        -cmd "PRAGMA temp_store=MEMORY;" \
        "$DB_PATH" "$1" 2>"$_err" | tr -d '\r'
    _rc=$?
    [ -s "$_err" ] && logger -t superwifi_db -p daemon.err "$(cat "$_err")"
    rm -f "$_err" 2>/dev/null
    return $_rc
}

# Batch execution from a SQL file (used by sw-acct.sh for bulk updates).
# Skips per-query PRAGMAs — the batch file handles its own transaction.
# journal_mode=WAL is persistent (set once, stored in DB header).
db_exec_batch() {
    local file="$1"
    # [FIX] PID-scoped temp file.
    local _err="/tmp/superwifi/db_err_batch_$$" _rc
    sqlite3 \
        -cmd ".timeout 5000" \
        -cmd "PRAGMA synchronous=NORMAL;" \
        -cmd "PRAGMA foreign_keys=ON;" \
        -cmd "PRAGMA cache_size=-2000;" \
        -cmd "PRAGMA temp_store=MEMORY;" \
        "$DB_PATH" <"$file" 2>"$_err"
    _rc=$?
    [ -s "$_err" ] && logger -t superwifi_db -p daemon.err "batch: $(cat "$_err")"
    rm -f "$_err" 2>/dev/null
    return $_rc
}

# -- Database Initialization ------------------------------------------------
sw_db_init() {
    local db_dir
    db_dir=$(dirname "$DB_PATH")
    mkdir -p "$db_dir" || {
        sw_log "FATAL" "cannot create DB dir $db_dir"
        return 1
    }
    mkdir -p /tmp/superwifi 2>/dev/null

    if [ ! -f "$DB_PATH" ]; then
        # First-time initialization: set page_size BEFORE creating tables.
        # page_size can only be set on a new, empty database.
        sqlite3 "$DB_PATH" <<-'EOINIT'
            PRAGMA page_size = 4096;
            PRAGMA journal_mode = WAL;
            PRAGMA auto_vacuum = INCREMENTAL;
EOINIT
        db_query ".read /etc/superwifi/schema.sql" || {
            sw_log "FATAL" "schema init failed for $DB_PATH"
            return 1
        }
        sw_log "INFO" "DB initialized at $DB_PATH"
    fi

    # Ensure WAL mode is active (idempotent — no-op if already set).
    # WAL mode is persistent: stored in the DB header, survives restarts.
    db_query "PRAGMA journal_mode = WAL;" >/dev/null

    # Database Migrations
    db_query "
        CREATE TABLE IF NOT EXISTS system_config (
            key             TEXT PRIMARY KEY,
            value           TEXT NOT NULL,
            updated_at      INTEGER NOT NULL DEFAULT (strftime('%s','now'))
        );
        INSERT OR IGNORE INTO system_config (key, value) VALUES ('firmware_version', '5.6.1');
    " >/dev/null
    
    # Apply schema migrations automatically for existing DBs
    db_query "ALTER TABLE session ADD COLUMN last_sync_at INTEGER;" >/dev/null 2>&1
    db_query "DROP TRIGGER IF EXISTS trg_quota_enforce;" >/dev/null 2>&1

    # [FIX] v_restore now exposes 's.id' so db_get_restore_session_by_mac can
    # deterministically pick the most recent session (ORDER BY id DESC LIMIT 1)
    # when more than one 'active' row exists for the same MAC. Views can't be
    # ALTERed in SQLite, so drop + recreate to match the definition in schema.sql.
    db_query "DROP VIEW IF EXISTS v_restore;" >/dev/null 2>&1
    db_query "
        CREATE VIEW IF NOT EXISTS v_restore AS
            SELECT
                s.id,
                s.bound_mac,
                s.bound_ip,
                s.rate_down_kbps,
                s.rate_up_kbps,
                s.class_id,
                s.expires_at,
                s.data_limit_bytes,
                s.cumulative_usage_bytes
            FROM session s
            WHERE s.status = 'active'
              AND s.bound_mac IS NOT NULL
              AND s.bound_ip IS NOT NULL
              AND s.class_id IS NOT NULL
              AND (s.expires_at = 0 OR s.expires_at > strftime('%s','now'))
              AND (s.data_limit_bytes = 0 OR s.cumulative_usage_bytes < s.data_limit_bytes)
              AND (
                  s.time_block_start IS NULL
                  OR s.time_block_end IS NULL
                  OR s.time_block_start = 0
                  OR s.time_block_end = 0
                  OR (
                      s.time_block_start < s.time_block_end AND
                      CAST(strftime('%H%M', 'now', 'localtime') AS INTEGER) NOT BETWEEN s.time_block_start AND s.time_block_end
                  )
                  OR (
                      s.time_block_start > s.time_block_end AND
                      CAST(strftime('%H%M', 'now', 'localtime') AS INTEGER) NOT BETWEEN s.time_block_start AND 2359 AND
                      CAST(strftime('%H%M', 'now', 'localtime') AS INTEGER) NOT BETWEEN 0 AND s.time_block_end
                  )
              );
    " >/dev/null 2>&1

    # Automatically sync DB system_config with SSOT (/etc/superwifi-version)
    local ssot_ver
    ssot_ver=$(sw_get_version)
    if [ -n "$ssot_ver" ] && [ "$ssot_ver" != "0.0.0" ]; then
        local db_ver
        db_ver=$(db_query "SELECT value FROM system_config WHERE key='firmware_version';" 2>/dev/null)
        if [ "$db_ver" != "$ssot_ver" ]; then
            sw_log "INFO" "Syncing DB firmware_version to $ssot_ver"
            db_query "ALTER TABLE voucher ADD COLUMN batch_id INTEGER DEFAULT NULL;" >/dev/null 2>&1
            
            # Migrate check constraints for unlimited speed (rate >= 0) & CASCADE foreign keys on existing DBs
            db_query "
                PRAGMA foreign_keys = OFF;
                BEGIN TRANSACTION;
                CREATE TABLE IF NOT EXISTS package_new (
                    id              INTEGER PRIMARY KEY,
                    name            TEXT NOT NULL UNIQUE,
                    rate_down_kbps  INTEGER NOT NULL DEFAULT 2048,
                    rate_up_kbps    INTEGER NOT NULL DEFAULT 1024,
                    data_limit_bytes INTEGER NOT NULL DEFAULT 0,
                    duration_min    INTEGER NOT NULL DEFAULT 0,
                    price_cents     INTEGER NOT NULL DEFAULT 0,
                    is_visible      INTEGER NOT NULL DEFAULT 1,
                    time_block_start INTEGER NOT NULL DEFAULT 0,
                    time_block_end  INTEGER NOT NULL DEFAULT 0,
                    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),
                    CHECK (rate_down_kbps >= 0),
                    CHECK (rate_up_kbps >= 0),
                    CHECK (data_limit_bytes >= 0),
                    CHECK (duration_min >= 0),
                    CHECK (price_cents >= 0)
                );
                INSERT OR IGNORE INTO package_new SELECT * FROM package;
                DROP TABLE package;
                ALTER TABLE package_new RENAME TO package;

                CREATE TABLE IF NOT EXISTS voucher_new (
                    code            TEXT PRIMARY KEY,
                    package_id      INTEGER DEFAULT NULL,
                    batch_id        INTEGER DEFAULT NULL,
                    rate_down_kbps  INTEGER NOT NULL DEFAULT 2048,
                    rate_up_kbps    INTEGER NOT NULL DEFAULT 1024,
                    data_limit_bytes INTEGER NOT NULL DEFAULT 0,
                    duration_min    INTEGER NOT NULL DEFAULT 0,
                    valid_until     INTEGER NOT NULL DEFAULT 0,
                    time_block_start INTEGER NOT NULL DEFAULT 0,
                    time_block_end  INTEGER NOT NULL DEFAULT 0,
                    price_cents     INTEGER NOT NULL DEFAULT 0,
                    created_at      INTEGER NOT NULL DEFAULT (strftime('%s','now')),
                    FOREIGN KEY (package_id) REFERENCES package(id) ON DELETE CASCADE,
                    CHECK (rate_down_kbps >= 0),
                    CHECK (rate_up_kbps >= 0),
                    CHECK (data_limit_bytes >= 0),
                    CHECK (duration_min >= 0)
                );
                INSERT OR IGNORE INTO voucher_new (code, package_id, batch_id, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, valid_until, time_block_start, time_block_end, price_cents, created_at)
                SELECT code, package_id, batch_id, rate_down_kbps, rate_up_kbps, data_limit_bytes, duration_min, valid_until, time_block_start, time_block_end, price_cents, created_at FROM voucher;
                DROP TABLE voucher;
                ALTER TABLE voucher_new RENAME TO voucher;

                CREATE INDEX IF NOT EXISTS idx_voucher_package ON voucher(package_id) WHERE package_id IS NOT NULL;
                CREATE INDEX IF NOT EXISTS idx_voucher_batch_id ON voucher(batch_id) WHERE batch_id IS NOT NULL;
                COMMIT;
                PRAGMA foreign_keys = ON;
            " >/dev/null 2>&1 || true

            db_query ".read /etc/superwifi/schema.sql" >/dev/null 2>&1 || true
            db_query "INSERT OR REPLACE INTO system_config (key, value, updated_at) VALUES ('firmware_version', '$ssot_ver', strftime('%s','now'));" >/dev/null 2>&1
        fi
    fi

    return 0
}

# -- Maintenance Helpers ----------------------------------------------------
# Manual WAL checkpoint — called from the 10-minute maintenance cycle.
# PASSIVE mode: checkpoint only pages that don't require blocking writers.
# This is flash-friendly: batches dirty pages into a single write operation.
db_checkpoint() {
    db_query "PRAGMA wal_checkpoint(PASSIVE);" >/dev/null
}

# Full checkpoint + truncate — called on service stop or before backup.
# Writes all WAL pages back to the main DB file and truncates the WAL.
db_checkpoint_full() {
    db_query "PRAGMA wal_checkpoint(TRUNCATE);" >/dev/null
}

# Incremental auto-vacuum — reclaims free pages without full VACUUM.
# Much cheaper than VACUUM on flash storage: rewrites only freed pages.
db_incremental_vacuum() {
    db_query "PRAGMA incremental_vacuum(50);" >/dev/null
}
