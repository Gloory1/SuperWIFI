#!/bin/sh
# /usr/sbin/sw-acct.sh
# SuperWiFi Accounting Library — sw_acct_cycle()
# Called by sw-engine.sh. Does NOT contain a daemon loop.
# Libraries are loaded once by sw-engine.sh at startup.

sw_acct_cycle() {
    sw_db_init || return

    CYCLE_START_EPOCH=$(date +%s)
    # [FIX M2] Use mktemp to prevent predictable symlink attacks
    TC_STATS_FILE=$(mktemp "/tmp/superwifi/tc_stats.XXXXXX")
    local ifb_dev="ifb4${LAN_IFACE}"
    # TODO: report download/upload separately in history when schema supports it
    (
        tc -s class show dev "$LAN_IFACE" 2>/dev/null
        tc -s class show dev "$ifb_dev" 2>/dev/null
    ) | awk '/class htb 1:/ {c=$3; sub(/.*1:/,"",c)} /Sent/ {sum[c]+=$2} END {for (c in sum) print c "|" sum[c]}' > "$TC_STATS_FILE"

    SQL_OUT=$(mktemp "/tmp/superwifi/bulk_update.XXXXXX")
    LOG_OUT=$(mktemp "/tmp/superwifi/actions.XXXXXX")

    echo "BEGIN TRANSACTION;" > "$SQL_OUT"

    # [PERF OPTIMIZATION] Single awk pipeline handles all calculation and SQL generation.
    # Eliminates shell loop iterations and subshell spawns during accounting cycles.
    db_get_accounting_targets | awk -F'|' \
        -v cycle_epoch="$CYCLE_START_EPOCH" \
        -v prev_cycle_epoch="${PREV_CYCLE_EPOCH:-0}" \
        -v acct_interval="${ACCT_INTERVAL_SEC:-60}" \
        -v anomaly_multiplier="${ANOMALY_MULTIPLIER:-1.2}" \
        -v sql_file="$SQL_OUT" \
        -v log_file="$LOG_OUT" \
        -v tc_file="$TC_STATS_FILE" \
        '
        BEGIN {
            while ((getline < tc_file) > 0) {
                split($0, parts, "|")
                if (parts[1] != "") {
                    tc[parts[1]] = parts[2] + 0
                }
            }
            close(tc_file)
            # [FIX RC-2] Compute actual elapsed time between cycles.
            # If prev_cycle_epoch is 0 (first cycle after boot), fall back to acct_interval.
            actual_elapsed = (prev_cycle_epoch > 0 && cycle_epoch > prev_cycle_epoch) \
                ? (cycle_epoch - prev_cycle_epoch) : acct_interval
            # Never use less than acct_interval (guards against clock drift or rapid restarts)
            if (actual_elapsed < acct_interval) actual_elapsed = acct_interval
        }
        {
            mac = $1; ip = $2; voucher = $3;
            rate_down = $4 + 0; rate_up = $5 + 0;
            limit = $6 + 0; cumulative = $7 + 0; season_usage = $8 + 0;
            class_id = $9; is_expired = $10 + 0; is_time_blocked = $11 + 0;

            if (mac == "" || ip == "" || class_id == "" || class_id == "NULL") next;

            curr_bytes = (class_id in tc) ? tc[class_id] : 0;
            delta_bytes = 0;

            if (curr_bytes > season_usage) {
                delta_bytes = curr_bytes - season_usage;
            } else if (curr_bytes < season_usage) {
                # [FIX RC-1] TC class was reset or recreated (e.g. after re-auth or interface flap).
                # Modern kernels use 64-bit counters — 32-bit wrap is essentially impossible.
                # The safe and correct behaviour is: treat curr_bytes as the new baseline,
                # so delta_bytes = 0 for this cycle. The DB season_usage will sync on the next cycle.
                delta_bytes = 0;
            }

            new_cumulative = cumulative + delta_bytes;

            # [FIX RC-2] Use actual_elapsed (real wall-clock time since last cycle) instead of
            # the fixed acct_interval. This prevents false quarantines when cycles are delayed.
            # [FIX LEAK-3] curr_bytes is the SUM of download (LAN_IFACE) + upload
            # (ifb) class counters. The anomaly ceiling must reflect combined
            # capacity — rate_down alone understates it for sessions with real
            # upload activity, causing false-positive rate_anomaly quarantines.
            # Do NOT drop rate_up from this calculation again.
            max_bytes = (rate_down + rate_up) * 125 * actual_elapsed;
            threshold_bytes = int(max_bytes * anomaly_multiplier);

            if (delta_bytes > 0 && threshold_bytes > 0 && delta_bytes > threshold_bytes) {
                print "UPDATE session SET status=\x27quarantined\x27, class_id=NULL, quarantine_reason=\x27rate_anomaly\x27, last_seen_at=strftime(\x27%s\x27,\x27now\x27) WHERE bound_mac=\x27" mac "\x27;" >> sql_file;
                print "INSERT INTO quarantine_event (mac, voucher_code, reason, delta_bytes, threshold_bytes) VALUES (\x27" mac "\x27, \x27" voucher "\x27, \x27rate_anomaly\x27, " delta_bytes ", " threshold_bytes ");" >> sql_file;
                print "QUARANTINE|" mac "|" ip "|" voucher >> log_file;
                next;
            }

            if (is_expired == 1) {
                if (delta_bytes > 0) {
                    print "UPDATE session SET cumulative_usage_bytes = cumulative_usage_bytes + " delta_bytes ", season_usage_bytes = " curr_bytes ", last_seen_at = strftime(\x27%s\x27,\x27now\x27) WHERE voucher_code = \x27" voucher "\x27;" >> sql_file;
                    print "INSERT INTO acct_log (session_id, mac, delta_bytes, logged_at) SELECT id, \x27" mac "\x27, " delta_bytes ", " cycle_epoch " FROM session WHERE voucher_code=\x27" voucher "\x27;" >> sql_file;
                }
                print "UPDATE session SET status=\x27expired\x27, class_id=NULL, last_seen_at=strftime(\x27%s\x27,\x27now\x27) WHERE voucher_code=\x27" voucher "\x27;" >> sql_file;
                print "DEAUTH|" mac "|" ip "|" voucher "|session_expired|" class_id >> log_file;
                next;
            }

            if (is_time_blocked == 1) {
                if (delta_bytes > 0) {
                    print "UPDATE session SET cumulative_usage_bytes = cumulative_usage_bytes + " delta_bytes ", season_usage_bytes = " curr_bytes ", last_seen_at = strftime(\x27%s\x27,\x27now\x27) WHERE voucher_code = \x27" voucher "\x27;" >> sql_file;
                    print "INSERT INTO acct_log (session_id, mac, delta_bytes, logged_at) SELECT id, \x27" mac "\x27, " delta_bytes ", " cycle_epoch " FROM session WHERE voucher_code=\x27" voucher "\x27;" >> sql_file;
                }
                print "UPDATE session SET status=\x27disconnected\x27, class_id=NULL, last_seen_at=strftime(\x27%s\x27,\x27now\x27) WHERE voucher_code=\x27" voucher "\x27;" >> sql_file;
                print "DEAUTH|" mac "|" ip "|" voucher "|time_blocked|" class_id >> log_file;
                next;
            }

            if (limit > 0 && new_cumulative >= limit) {
                print "UPDATE session SET cumulative_usage_bytes = cumulative_usage_bytes + " delta_bytes ", season_usage_bytes = " curr_bytes ", last_seen_at = strftime(\x27%s\x27,\x27now\x27) WHERE voucher_code = \x27" voucher "\x27;" >> sql_file;
                print "UPDATE session SET status=\x27expired\x27, class_id=NULL, last_seen_at=strftime(\x27%s\x27,\x27now\x27) WHERE voucher_code=\x27" voucher "\x27;" >> sql_file;
                print "INSERT INTO acct_log (session_id, mac, delta_bytes, logged_at) SELECT id, \x27" mac "\x27, " delta_bytes ", " cycle_epoch " FROM session WHERE voucher_code=\x27" voucher "\x27;" >> sql_file;
                print "DEAUTH|" mac "|" ip "|" voucher "|quota_exhausted|" class_id >> log_file;
                next;
            }

            if (delta_bytes > 0) {
                print "UPDATE session SET cumulative_usage_bytes = cumulative_usage_bytes + " delta_bytes ", season_usage_bytes = " curr_bytes ", last_seen_at = strftime(\x27%s\x27,\x27now\x27) WHERE voucher_code = \x27" voucher "\x27;" >> sql_file;
                print "INSERT INTO acct_log (session_id, mac, delta_bytes, logged_at) SELECT id, \x27" mac "\x27, " delta_bytes ", " cycle_epoch " FROM session WHERE voucher_code=\x27" voucher "\x27;" >> sql_file;
            }
        }'

    echo "COMMIT;" >> "$SQL_OUT"
    if db_exec_batch "$SQL_OUT"; then
        rm -f "$TC_STATS_FILE"

        if [ -f "$LOG_OUT" ]; then
            while IFS='|' read -r ACTION MAC IP VOUCHER REASON CID; do
                if [ "$ACTION" = "DEAUTH" ]; then
                    sw_fw_deauth "$MAC" "$IP" "$VOUCHER" "$REASON" "$CID"
                    sw_log "INFO" "ACCOUNTING: $MAC deauthed due to $REASON"
                elif [ "$ACTION" = "QUARANTINE" ]; then
                    nft delete element inet superwifi authenticated "{ ${MAC} . ${IP} }" 2>/dev/null || true
                    sw_fw_block_mac "$MAC"
                    sw_tc_remove_by_ip "$IP"
                    sw_log "WARN" "QUARANTINE: mac=$MAC voucher=$VOUCHER rate anomaly"
                fi
            done < "$LOG_OUT"
            rm -f "$LOG_OUT"
        fi
    else
        sw_log "ERROR" "sw-acct: db_exec_batch failed, skipping actions to avoid inconsistency"
        rm -f "$TC_STATS_FILE"
        rm -f "$LOG_OUT"
    fi

    # Trigger periodic maintenance every 10 minutes
    local _minute
    _minute=$(date +%M | sed 's/^0//')
    _minute=${_minute:-0}
    if [ $(( _minute % 10 )) -eq 0 ]; then
        db_maintenance_cleanup
        # Run PASSIVE checkpoint to safely write WAL data to main DB without locking writers
        db_checkpoint
        sw_log "INFO" "Periodic maintenance cleanup & passive WAL checkpoint done."
    fi

    # Cleanup temp files
    rm -f "$TC_STATS_FILE" "$SQL_OUT" "$LOG_OUT"
}
