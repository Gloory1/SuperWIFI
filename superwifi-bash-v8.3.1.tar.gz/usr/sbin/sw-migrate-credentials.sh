#!/bin/sh
# /usr/sbin/sw-migrate-credentials.sh
# Migration and configuration helper for SuperWiFi Supabase Credentials

. /usr/lib/superwifi/core.sh

echo "======================================================"
echo " SuperWiFi Supabase Credentials Configurator"
echo "======================================================"

CURR_URL=$(uci get superwifi.credentials.supabase_url 2>/dev/null)
CURR_KEY=$(uci get superwifi.credentials.supabase_key 2>/dev/null)

if [ -n "$CURR_URL" ] && [ -n "$CURR_KEY" ]; then
    echo "[✓] Supabase credentials already configured in UCI:"
    echo "    URL: $CURR_URL"
    echo "    KEY: ${CURR_KEY:0:20}..."
    echo ""
fi

if [ -n "$1" ] && [ -n "$2" ]; then
    NEW_URL="$1"
    NEW_KEY="$2"
else
    printf "Enter Supabase Project URL (e.g., https://xyz.supabase.co): "
    read -r NEW_URL
    printf "Enter Supabase Anon API Key: "
    read -r NEW_KEY
fi

if [ -z "$NEW_URL" ] || [ -z "$NEW_KEY" ]; then
    echo "ERROR: URL and Key cannot be empty."
    exit 1
fi

uci set superwifi.credentials=credentials 2>/dev/null || uci set superwifi.credentials=section
uci set superwifi.credentials.supabase_url="$NEW_URL"
uci set superwifi.credentials.supabase_key="$NEW_KEY"
uci commit superwifi

echo "[✓] Supabase credentials saved to UCI successfully!"
echo "    Test sync by running: sw sync"
