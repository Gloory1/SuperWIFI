#!/bin/sh
# shellcheck shell=ash
# shellcheck disable=SC2034,SC2155
# /usr/sbin/sw-sentinel.sh
# SuperWiFi Self-Healing Sentinel Library — sw_sentinel_reconcile()
# Called by sw-engine.sh after sw_acct_cycle if sentinel_enabled=1.
# Libraries are loaded once by sw-engine.sh at startup.
# Enforces: nftables authenticated set + TC classes ≡ active_sessions view

sw_sentinel_reconcile() {
    local TMPDIR="/tmp/superwifi"
    local NF="$TMPDIR/sentinel_nft.tmp"
    local DBF="$TMPDIR/sentinel_db.tmp"
    local GHOSTS="$TMPDIR/sentinel_ghosts.tmp"
    local STALE="$TMPDIR/sentinel_stale.tmp"
    local MISSING="$TMPDIR/sentinel_missing.tmp"
    local db_cids="$TMPDIR/sentinel_db_cids.tmp"
    local tc_cids="$TMPDIR/sentinel_tc_cids.tmp"
    local orphan_tmp="$TMPDIR/sentinel_orphan.tmp"

    trap 'rm -f "$NF" "$DBF" "$GHOSTS" "$STALE" "$MISSING" "$db_cids" "$tc_cids" "$orphan_tmp"' EXIT INT TERM

    local start_ms end_ms elapsed
    start_ms=$(date +%s%3N 2>/dev/null)
    if ! echo "$start_ms" | grep -q 'N$'; then
        # Check if %3N was rendered literally (unsupported format)
        [ -n "$start_ms" ] || start_ms=$(($(date +%s) * 1000))
    else
        start_ms=$(($(date +%s) * 1000))
    fi

    # ----------------------------------------------------------------
    # Phase 1: Collect nftables authenticated set → MAC|IP
    # ----------------------------------------------------------------
    nft list set inet superwifi authenticated 2>/dev/null | \
        awk '/elements =/{p=1; sub(/.*\{/,"")} p{gsub(/\}.*/,""); print} /\}/{p=0}' | \
        tr ',' '\n' | \
        sed 's/^[[:space:]]*//; s/[[:space:]]*$//' | \
        while read -r mac dot ip rest; do
            validate_mac "$mac" || continue
            validate_ip "$ip" || continue
            printf '%s|%s\n' "$mac" "$ip"
        done > "$NF"

    # ----------------------------------------------------------------
    # Phase 2: Collect DB active sessions → MAC|IP|rate_down|rate_up|class_id
    # ----------------------------------------------------------------
    db_get_all_active_sessions > "$DBF"

    local nft_count db_count
    nft_count=$(wc -l < "$NF")
    db_count=$(wc -l < "$DBF")

    # ----------------------------------------------------------------
    # Phase 3: Ghosts — MAC+IP in nft but not in DB active sessions
    # ----------------------------------------------------------------
    awk -F'|' -v OFS='|' 'NR==FNR{db[$1"|"$2]=1; next} !($1"|"$2 in db){print $1, $2}' "$DBF" "$NF" > "$GHOSTS"

    # ----------------------------------------------------------------
    # Phase 5: Missing — MAC+IP in DB but missing from nft
    # ----------------------------------------------------------------
    if [ -s "$NF" ]; then
        awk -F'|' -v OFS='|' 'NR==FNR{nf[$1"|"$2]=1; next} !($1"|"$2 in nf){print}' "$NF" "$DBF" > "$MISSING"
    else
        cp "$DBF" "$MISSING"
    fi

    # ----------------------------------------------------------------
    # Phase 6: Rate-limited remediation
    # ----------------------------------------------------------------
    local limit=10
    [ "$nft_count" -eq 0 ] && [ "$db_count" -gt 0 ] && limit=$db_count

    local ghost_cnt stale_cnt miss_cnt
    ghost_cnt=$(wc -l < "$GHOSTS")
    stale_cnt=0
    miss_cnt=$(wc -l < "$MISSING")

    # 6a: Ghost removal — nft delete + conntrack flush
    if [ "$ghost_cnt" -gt 0 ]; then
        head -n "$limit" "$GHOSTS" | while IFS='|' read -r mac ip; do
            nft delete element inet superwifi authenticated "{ ${mac} . ${ip} }" 2>/dev/null || true
            conntrack -D -s "$ip" 2>/dev/null || true
            sw_log "SENTINEL" "ghost: mac=$mac ip=$ip"
        done
    fi

    # 6c: Missing session restore — using shared sw_restore_one_session
    if [ "$miss_cnt" -gt 0 ]; then
        db_get_restore_sessions | \
        awk -F'|' 'NR==FNR{m[$1]=1; next} $1 in m' "$MISSING" - | \
        head -n "$limit" | \
        while IFS='|' read -r mac ip rate_down rate_up class_id expires_at data_limit cum_usage; do
            [ -z "$mac" ] || [ -z "$class_id" ] && continue
            sw_restore_one_session "$mac" "$ip" "$rate_down" "$rate_up" "$class_id" "$expires_at"
        done
    fi

    # ----------------------------------------------------------------
    # Phase 7: TC orphan cleanup — delete classes not referenced by any active session
    # ----------------------------------------------------------------
    local db_cids="$TMPDIR/sentinel_db_cids.tmp"
    local tc_cids="$TMPDIR/sentinel_tc_cids.tmp"
    local ifb_dev="ifb4${LAN_IFACE}"
    db_get_all_active_class_ids > "$db_cids"
    (
        tc -s class show dev "$LAN_IFACE" 2>/dev/null
        tc -s class show dev "$ifb_dev" 2>/dev/null
    ) | awk '/class htb 1:/{gsub(/.*1:/,"",$3); print $3}' | sort -u > "$tc_cids"
    local orphan_tmp="$TMPDIR/sentinel_orphan.tmp"
    awk 'NR==FNR{db[$1]=1; next} !($1 in db) && $1 >= 1000' "$db_cids" "$tc_cids" > "$orphan_tmp"
    local orphan_cnt
    orphan_cnt=$(wc -l < "$orphan_tmp")
    while read -r cid; do
        sw_tc_remove "$cid" 2>/dev/null || true
        sw_log "SENTINEL" "tc_orphan: class_id=$cid"
    done < "$orphan_tmp"

    # ----------------------------------------------------------------
    # Phase 7b: Quarantined MAC reconciliation — ensure all DB quarantined MACs exist in nft
    # ----------------------------------------------------------------
    local quar_restored=0
    db_get_all_quarantined_macs 2>/dev/null | \
    while read -r qmac; do
        [ -z "$qmac" ] && continue
        validate_mac "$qmac" || continue
        if ! nft get element inet superwifi quarantined "{ ${qmac} }" >/dev/null 2>&1; then
            nft add element inet superwifi quarantined "{ ${qmac} }" 2>/dev/null || true
            sw_log "SENTINEL" "quarantine_restored: mac=$qmac"
            quar_restored=$(( quar_restored + 1 ))
        fi
    done

    # ----------------------------------------------------------------
    # Phase 8: Summary log
    # ----------------------------------------------------------------
    end_ms=$(date +%s%3N 2>/dev/null)
    if ! echo "$end_ms" | grep -q 'N$'; then
        [ -n "$end_ms" ] || end_ms=$(($(date +%s) * 1000))
    else
        end_ms=$(($(date +%s) * 1000))
    fi
    elapsed=$(( end_ms - start_ms ))
    sw_log "SENTINEL" "done: ghosts=${ghost_cnt} stale=${stale_cnt} restores=${miss_cnt} tc_orphans=${orphan_cnt} duration=${elapsed}ms"

    rm -f "$NF" "$DBF" "$GHOSTS" "$STALE" "$MISSING" "$db_cids" "$tc_cids" "$orphan_tmp"
}

