#!/bin/sh
# shellcheck shell=ash
# SuperWiFi RFC 8908 Captive Portal API endpoint
# /www/cgi-bin/capport-api.sh  —  chmod +x required
# Delegates to auth.sh with action=capport

QUERY_STRING="action=capport"
REQUEST_METHOD="GET"
export QUERY_STRING REQUEST_METHOD
exec /www/cgi-bin/auth.sh
