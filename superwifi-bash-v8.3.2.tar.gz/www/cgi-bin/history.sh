#!/bin/sh
# shellcheck shell=ash
# /www/cgi-bin/history.sh
# Returns JSON of all vouchers used by this MAC address

. /usr/lib/superwifi/core.sh
. /usr/lib/superwifi/db-queries.sh

client_ip="$REMOTE_ADDR"
client_mac=""

if validate_ip "$client_ip"; then
    client_mac=$(get_mac_by_ip_safe "$client_ip")
fi

printf 'Content-Type: application/json\r\n'
printf 'Cache-Control: no-store\r\n\r\n'

if [ -z "$client_mac" ] || ! validate_mac "$client_mac"; then
    printf '{"status":"error","message":"Could not detect MAC address"}\n'
    exit 0
fi

sw_db_init || { printf '{"status":"error","message":"Database error"}\n'; exit 0; }

json=$(db_get_history_by_mac "$client_mac")
[ -z "$json" ] || [ "$json" = "null" ] && json="[]"
printf '{"status":"success","vouchers":%s}\n' "$json"
