#!/bin/sh
# shellcheck shell=ash
# /www/cgi-bin/redirect.sh
# SuperWiFi Captive Portal Redirect Handler
# Triggered by uhttpd error_page 404 to catch Android/iOS captive probes.

# Read cached PORTAL_URL (0ms sub-shell overhead, fallback if file missing)
PORTAL_URL=$(cat /tmp/superwifi/portal_url 2>/dev/null || uci get superwifi.core.portal_url 2>/dev/null || echo "http://10.0.0.1/superwifi/login.html")

# [FIX] Sanitize PORTAL_URL to prevent HTTP header injection via newline/CR characters
PORTAL_URL=$(printf '%s' "$PORTAL_URL" | tr -d '\r\n\t' | sed 's/[^a-zA-Z0-9.:\/\?\=\&_%-]//g')
[ -z "$PORTAL_URL" ] && PORTAL_URL="http://10.0.0.1/superwifi/login.html"

case "$PORTAL_URL" in
    *\?*) PORTAL_URL="${PORTAL_URL}&cp=1" ;;
    *)    PORTAL_URL="${PORTAL_URL}?cp=1" ;;
esac

printf "Status: 302 Found\r\n"
printf "Location: %s\r\n" "$PORTAL_URL"
printf "Content-Type: text/html\r\n"
printf "Content-Length: 0\r\n"
printf "Cache-Control: no-cache, no-store, must-revalidate\r\n"
printf "Pragma: no-cache\r\n"
printf "Expires: 0\r\n"
printf "Connection: close\r\n\r\n"
