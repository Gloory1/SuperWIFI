#!/bin/sh
# shellcheck shell=ash
# /usr/lib/superwifi/tc.sh
# MAC-centric traffic shaping with unique DB-allocated class_id

. /usr/lib/superwifi/core.sh
. /usr/lib/superwifi/db-queries.sh

sw_tc_ensure_ifb() {
    local ifb_dev="ifb4${LAN_IFACE}"
    modprobe ifb 2>/dev/null || {
        sw_log "ERROR" "tc: modprobe ifb failed"
    }
    ip link add "$ifb_dev" type ifb 2>/dev/null || true
    ip link set "$ifb_dev" up 2>/dev/null || true

    tc qdisc show dev "$LAN_IFACE" 2>/dev/null | grep -q "ingress" || \
        tc qdisc add dev "$LAN_IFACE" handle ffff: ingress 2>/dev/null || true

    tc filter show dev "$LAN_IFACE" ingress 2>/dev/null | grep -q "mirred.*${ifb_dev}" || \
        tc filter add dev "$LAN_IFACE" parent ffff: protocol ip u32 \
            match u32 0 0 flowid 1:1 \
            action mirred egress redirect dev "$ifb_dev" 2>/dev/null || true

    tc qdisc show dev "$ifb_dev" 2>/dev/null | grep -q "htb" || \
        tc qdisc add dev "$ifb_dev" root handle 1: htb default 9999 2>/dev/null || true
}

sw_tc_ensure_root() {
    tc qdisc show dev "$LAN_IFACE" 2>/dev/null | grep -q "htb" || \
        tc qdisc add dev "$LAN_IFACE" root handle 1: htb default 9999 2>/dev/null
    sw_tc_ensure_ifb
}

sw_tc_apply() {
    local mac="$1"
    local ip="$2"
    local rate_down="$3"
    local rate_up="$4"
    local class_id="$5"

    validate_mac "$mac" || return 1
    validate_ip "$ip" || return 1
    rate_down=$(printf '%s' "$rate_down" | tr -dc '0-9')
    rate_up=$(printf '%s' "$rate_up" | tr -dc '0-9')
    class_id=$(printf '%s' "$class_id" | tr -dc '0-9')
    [ -z "$rate_down" ] || [ "$rate_down" -eq 0 ] && rate_down=1000000
    [ -z "$rate_up" ] || [ "$rate_up" -eq 0 ] && rate_up=1000000
    [ -z "$class_id" ] && return 1

    local burst_bytes=$(( TC_BURST_KB * 1024 ))
    local sfq_handle
    sfq_handle=$(printf '%x' "$class_id" 2>/dev/null)
    local ifb_dev="ifb4${LAN_IFACE}"

    sw_tc_ensure_root

    # Download class & SFQ on LAN_IFACE
    tc class replace dev "$LAN_IFACE" parent 1: classid "1:${class_id}" \
        htb rate "${rate_down}kbit" ceil "${rate_down}kbit" \
        burst "${burst_bytes}" cburst "${burst_bytes}" 2>/dev/null || {
        sw_log "ERROR" "tc: failed to add LAN class 1:${class_id} for $mac"
        return 1
    }

    tc qdisc replace dev "$LAN_IFACE" parent "1:${class_id}" \
        handle "${sfq_handle}:" sfq perturb 10 2>/dev/null || true

    # Upload class & SFQ on IFB device
    tc class replace dev "$ifb_dev" parent 1: classid "1:${class_id}" \
        htb rate "${rate_up}kbit" ceil "${rate_up}kbit" \
        burst "${burst_bytes}" cburst "${burst_bytes}" 2>/dev/null || {
        sw_log "ERROR" "tc: failed to add IFB class 1:${class_id} for $mac"
        sw_tc_remove "$class_id"
        return 1
    }

    tc qdisc replace dev "$ifb_dev" parent "1:${class_id}" \
        handle "${sfq_handle}:" sfq perturb 10 2>/dev/null || true

    # Filters
    local prio_dst="$class_id"
    local prio_src=$(( class_id + 10000 ))

    # Download filter (dst IP match on LAN_IFACE egress)
    tc filter del dev "$LAN_IFACE" parent 1: protocol ip prio "$prio_dst" 2>/dev/null || true
    tc filter add dev "$LAN_IFACE" parent 1: protocol ip prio "$prio_dst" \
        u32 match ip dst "${ip}/32" flowid "1:${class_id}" 2>/dev/null || {
        sw_log "ERROR" "tc: failed to add LAN filter 1:${class_id} for $mac"
        sw_tc_remove "$class_id"
        return 1
    }

    # Upload filter (src IP match on ifb4${LAN_IFACE} egress)
    tc filter del dev "$ifb_dev" parent 1: protocol ip prio "$prio_src" 2>/dev/null || true
    tc filter add dev "$ifb_dev" parent 1: protocol ip prio "$prio_src" \
        u32 match ip src "${ip}/32" flowid "1:${class_id}" 2>/dev/null || {
        sw_log "ERROR" "tc: failed to add IFB filter 1:${class_id} for $mac"
        sw_tc_remove "$class_id"
        return 1
    }

    # Clean up non-functional src filter from LAN_IFACE if present
    tc filter del dev "$LAN_IFACE" parent 1: protocol ip prio "$prio_src" 2>/dev/null || true
}

sw_tc_remove() {
    local class_id="$1"
    [ -z "$class_id" ] && return 0
    class_id=$(printf '%s' "$class_id" | tr -dc '0-9')
    [ -z "$class_id" ] && return 0

    local ifb_dev="ifb4${LAN_IFACE}"
    local prio_dst="$class_id"
    local prio_src=$(( class_id + 10000 ))

    tc filter del dev "$LAN_IFACE" parent 1: protocol ip prio "$prio_dst" 2>/dev/null || true
    tc filter del dev "$LAN_IFACE" parent 1: protocol ip prio "$prio_src" 2>/dev/null || true
    tc class del dev "$LAN_IFACE" parent 1: classid "1:${class_id}" 2>/dev/null || true

    tc filter del dev "$ifb_dev" parent 1: protocol ip prio "$prio_src" 2>/dev/null || true
    tc class del dev "$ifb_dev" parent 1: classid "1:${class_id}" 2>/dev/null || true
}

sw_tc_remove_by_ip() {
    local ip="$1"
    validate_ip "$ip" || return 0
    local cid
    cid=$(db_get_latest_class_id_by_ip "$ip")
    if [ -n "$cid" ] && [ "$cid" != "NULL" ]; then
        cid=$(printf '%s' "$cid" | tr -dc '0-9')
        if [ -n "$cid" ]; then
            sw_tc_remove "$cid"
            return 0
        fi
    fi
    # Fallback: legacy prio 1/2 delete
    local ifb_dev="ifb4${LAN_IFACE}"
    tc filter del dev "$LAN_IFACE" parent 1: protocol ip prio 1 u32 match ip dst "${ip}/32" 2>/dev/null || true
    tc filter del dev "$LAN_IFACE" parent 1: protocol ip prio 2 u32 match ip src "${ip}/32" 2>/dev/null || true
    tc filter del dev "$ifb_dev" parent 1: protocol ip prio 2 u32 match ip src "${ip}/32" 2>/dev/null || true
}

# sw_tc_flush_final_delta() — capture the final accounting delta for a class
# before it is destroyed by sw_tc_remove / sw_tc_remove_by_ip.
#
# CALL THIS before ANY code path that removes a TC class (logout, re-auth,
# voucher-switch, boot reset).  Without this call, all traffic consumed
# between the last sw_acct_cycle and the TC teardown is permanently lost
# because the kernel byte counters are destroyed with the class.
#
# Args: $1 = voucher_code   $2 = class_id (numeric, ≥1000)
# Returns 0 always (non-critical path — never block the caller).
sw_tc_flush_final_delta() {
    local voucher="$1"
    local class_id="$2"

    # Sanitize inputs — bail silently on bad values.
    [ -z "$voucher" ] && return 0
    [ -z "$class_id" ] || [ "$class_id" = "NULL" ] && return 0
    class_id=$(printf '%s' "$class_id" | tr -dc '0-9')
    [ -z "$class_id" ] && return 0

    local ifb_dev="ifb4${LAN_IFACE}"

    # Read current kernel byte counters: download (LAN_IFACE) + upload (IFB)
    # combined into a single number for this class_id, matching sw_acct_cycle logic.
    local curr_bytes
    curr_bytes=$(
        (
            tc -s class show dev "$LAN_IFACE" 2>/dev/null
            tc -s class show dev "$ifb_dev"  2>/dev/null
        ) | awk -v cid="$class_id" '
            /class htb 1:/ { c=$3; sub(/.*1:/,"",c) }
            /Sent/ { if (c == cid) sum += $2 }
            END { print sum+0 }
        '
    )
    curr_bytes=${curr_bytes:-0}

    # Fetch the last recorded baseline from the DB.
    local season_usage
    season_usage=$(db_query "SELECT season_usage_bytes FROM session WHERE voucher_code='$(db_escape "$voucher")' AND status='active' LIMIT 1;" 2>/dev/null)
    season_usage=${season_usage:-0}

    # Compute delta — only positive deltas are valid.
    local delta=0
    if [ "$curr_bytes" -gt "$season_usage" ] 2>/dev/null; then
        delta=$(( curr_bytes - season_usage ))
    fi

    if [ "$delta" -gt 0 ]; then
        local now_epoch
        now_epoch=$(date +%s)
        db_query "
            UPDATE session
               SET cumulative_usage_bytes = cumulative_usage_bytes + ${delta},
                   season_usage_bytes     = ${curr_bytes},
                   last_seen_at           = ${now_epoch}
             WHERE voucher_code = '$(db_escape "$voucher")'
               AND status = 'active';
            INSERT INTO acct_log (session_id, mac, delta_bytes, logged_at)
            SELECT id, bound_mac, ${delta}, ${now_epoch}
              FROM session WHERE voucher_code = '$(db_escape "$voucher")';
        " >/dev/null 2>&1
        sw_log "INFO" "tc_flush: voucher=${voucher} class_id=${class_id} final_delta=${delta}B (pre-teardown)"
    fi

    return 0
}

sw_tc_rebuild_filters() {
    local ifb_dev="ifb4${LAN_IFACE}"
    tc filter del dev "$LAN_IFACE" parent 1: 2>/dev/null || true
    tc filter del dev "$ifb_dev" parent 1: 2>/dev/null || true
    sw_tc_ensure_root
    db_get_all_active_sessions | \
    while IFS='|' read -r s_mac s_ip s_rate_down s_rate_up s_class_id; do
        [ -z "$s_mac" ] || [ -z "$s_ip" ] && continue
        [ -z "$s_class_id" ] && continue
        sw_tc_apply "$s_mac" "$s_ip" "${s_rate_down:-2048}" "${s_rate_up:-1024}" "$s_class_id" 2>/dev/null || true
    done
}
