#!/bin/sh
# shellcheck shell=ash
# shellcheck disable=SC2034
# /usr/lib/superwifi/sw-patches.sh
# SuperWiFi Stability Patches — Centralized non-destructive runtime guards
# Sourced by sw-engine.sh at startup alongside other libraries.
# Each patch is a self-contained, idempotent function with ZERO DELETE queries.
#
# PATCH INDEX:
#   PATCH-001  patch_repair_wrongly_expired_sessions — reactivates valid sessions
#              marked expired by mistake (e.g. legacy triggers) IF remaining quota/time exists.
#   PATCH-002  patch_reset_orphaned_season_usage     — zeros season_usage_bytes for active
#              sessions whose TC class was dropped, preventing counter-wrap false quota exhaustion.
#   sw_apply_patches                                 — runs all patches; called by sw-acct.sh
#              during the periodic maintenance window (every 10 minutes).

# ==============================================================================
# PATCH-001: Repair sessions falsely marked expired (NON-DESTRUCTIVE)
# ==============================================================================
# Safely restores status='active' for sessions marked expired if:
#   1. Remaining data quota exists (or data_limit_bytes == 0)
#   2. Remaining time exists (or expires_at == 0)
#   3. The MAC has no other currently active session
# ==============================================================================
patch_repair_wrongly_expired_sessions() {
    local tmp_repaired
    tmp_repaired=$(mktemp "/tmp/superwifi/patch001.XXXXXX" 2>/dev/null || mktemp)

    db_get_wrongly_expired_sessions > "$tmp_repaired"

    local fixed=0
    while IFS='|' read -r vcode mac ip rate_down rate_up cid; do
        [ -z "$vcode" ] && continue
        if [ -z "$cid" ] || [ "$cid" = "NULL" ] || [ "$cid" = "0" ]; then
            cid=$(db_assign_class_id "$vcode")
        fi
        db_reactivate_session_with_class "$vcode" "$cid"
        if [ -n "$mac" ] && [ -n "$ip" ] && [ -n "$cid" ]; then
            sw_tc_apply "$mac" "$ip" "${rate_down:-2048}" "${rate_up:-1024}" "$cid" 2>/dev/null || true
            nft add element inet superwifi authenticated "{ ${mac} . ${ip} }" 2>/dev/null || true
        fi
        fixed=$((fixed + 1))
    done < "$tmp_repaired"

    rm -f "$tmp_repaired"

    [ "$fixed" -gt 0 ] && sw_log "INFO" "PATCH-001: repaired ${fixed} wrongly expired session(s) to active status with class allocation"
    return 0
}

# ==============================================================================
# PATCH-002: Reset orphaned season_usage_bytes for TC-less active sessions
# ==============================================================================
# Root cause (RC-1):
#   After a re-auth or TC class recreation, the TC byte counter resets to 0 but
#   season_usage_bytes in DB still holds the old value (e.g. 50 MB).
#   On the next accounting cycle: curr_bytes=0 < season_usage=50MB → wrap logic
#   fires → potentially inflated delta_bytes → false quota exhaustion.
#
# Fix: For active sessions whose class_id has NO corresponding TC class on the
#   interface, zero out season_usage_bytes so the next accounting cycle starts
#   fresh from curr_bytes (which will equal 0 or a small number).
#   Cumulative_usage_bytes (the real quota counter) is NOT touched.
# ==============================================================================
patch_reset_orphaned_season_usage() {
    local tc_cids_file ifb_dev
    tc_cids_file=$(mktemp "/tmp/superwifi/patch_tc_cids.XXXXXX" 2>/dev/null || mktemp)
    ifb_dev="ifb4${LAN_IFACE}"

    # Collect all active TC class IDs from both interfaces
    (
        tc -s class show dev "$LAN_IFACE" 2>/dev/null
        tc -s class show dev "$ifb_dev" 2>/dev/null
    ) | awk '/class htb 1:/{gsub(/.*1:/,"",$3); print $3}' | sort -u > "$tc_cids_file"

    # Get active sessions that have a class_id assigned
    local session_file
    session_file=$(mktemp "/tmp/superwifi/patch_sessions.XXXXXX" 2>/dev/null || mktemp)
    db_get_active_sessions_with_season_usage > "$session_file"

    local fixed=0
    while IFS='|' read -r vcode cid season; do
        [ -z "$cid" ] || [ "$cid" = "NULL" ] && continue
        # If this class_id is NOT found in the TC output → its counter was reset
        if ! grep -qx "$cid" "$tc_cids_file" 2>/dev/null; then
            db_reset_session_season_usage_by_voucher "$vcode"
            fixed=$((fixed + 1))
        fi
    done < "$session_file"

    rm -f "$tc_cids_file" "$session_file"

    [ "$fixed" -gt 0 ] && sw_log "INFO" "PATCH-002: reset season_usage_bytes for ${fixed} TC-less session(s)"
    return 0
}

# ==============================================================================
# PATCH-003: Unquarantine sessions wrongly quarantined by rate anomaly
# ==============================================================================
patch_repair_wrongly_quarantined_sessions() {
    local tmp_quar
    tmp_quar=$(mktemp "/tmp/superwifi/patch003.XXXXXX" 2>/dev/null || mktemp)

    db_get_wrongly_quarantined_sessions > "$tmp_quar"

    local fixed=0
    while IFS='|' read -r mac vcode; do
        [ -z "$mac" ] && continue
        db_unquarantine_mac "$mac"
        sw_fw_unblock_mac "$mac"
        fixed=$((fixed + 1))
    done < "$tmp_quar"

    rm -f "$tmp_quar"

    [ "$fixed" -gt 0 ] && sw_log "INFO" "PATCH-003: unquarantined ${fixed} session(s) wrongly blocked by rate anomaly"
    return 0
}

# ==============================================================================
# sw_apply_patches — entry point called on-demand via CLI or update scripts
# ==============================================================================
sw_apply_patches() {
    patch_repair_wrongly_expired_sessions
    patch_reset_orphaned_season_usage
    patch_repair_wrongly_quarantined_sessions
}

# Allow running directly as a standalone script (e.g. /usr/lib/superwifi/sw-patches.sh)
if [ "${0##*/}" = "sw-patches.sh" ]; then
    . /usr/lib/superwifi/core.sh
    . /usr/lib/superwifi/db-queries.sh
    . /usr/lib/superwifi/tc.sh
    sw_db_init || exit 1
    printf 'Applying SuperWiFi stability patches on demand...\n'
    sw_apply_patches
    printf 'Done.\n'
fi
